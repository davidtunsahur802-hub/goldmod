// GoldCheat - оверлей (D3D11 + ImGui), хуки и UI. Игровая логика в game.h.
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <cstdarg>
#include <cstdio>
#include <string>
#include <algorithm>
#include <cctype>
#include <atomic>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "MinHook.h"
#include "game.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

// ------------------------------------------------------------------ лог
static HMODULE g_self; static CRITICAL_SECTION g_logCs; static char g_logPath[MAX_PATH];
void Log(const char* fmt, ...) {
    char buf[1024]; va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    EnterCriticalSection(&g_logCs);
    if (FILE* f = fopen(g_logPath, "ab")) { SYSTEMTIME t; GetLocalTime(&t); fprintf(f, "[%02d:%02d:%02d] %s\r\n", t.wHour, t.wMinute, t.wSecond, buf); fclose(f); }
    LeaveCriticalSection(&g_logCs);
}

// ------------------------------------------------------------------ хуки игры
typedef void(__cdecl* tUpd)(void*, const MethodInfo*);
typedef void(__cdecl* tHit)(void*, float, int, void*, const MethodInfo*);
typedef void(__cdecl* tTrig)(void*, void*, const MethodInfo*);
static tUpd oUpd; static tHit oHit; static tTrig oTrig;
static int g_tickErrors = 0;
static std::atomic<bool> g_unload{ false }, g_gameClean{ false }, g_overlayDown{ false };

static void SafeTick() {
    __try { G::Tick(); }
    __except (EXCEPTION_EXECUTE_HANDLER) { g_tickErrors++; Log("Tick exception #%d", g_tickErrors); }
}
static void SafeCleanup() {
    __try { G::Cleanup(); }
    __except (EXCEPTION_EXECUTE_HANDLER) { Log("Cleanup exception"); }
}
static void __cdecl hkUpd(void* self, const MethodInfo* mi) {
    oUpd(self, mi);
    if (g_unload) { if (!g_gameClean) { SafeCleanup(); g_gameClean = true; } return; } // выгрузка: возвращаем игру как было
    if (g_ready && g_tickErrors < 50) SafeTick();
}
static void __cdecl hkHit(void* self, float dmg, int part, void* enemy, const MethodInfo* mi) {
    if (g_cfg.bossAny && enemy && enemy == G::Sf(G::fPolyEnemy)) dmg = std::max(dmg, (float)g_cfg.bossMinDmg);
    G::OnHit();
    oHit(self, dmg, part, enemy, mi);
}
static void __cdecl hkTrig(void* self, void* col, const MethodInfo* mi) {
    if (g_cfg.god && !g_unload) return; // бессмертие: триггер поражения не срабатывает
    oTrig(self, col, mi);
}
static bool HookMethod(const MethodInfo* m, void* detour, void** orig, const char* name) {
    if (!m) { Log("hook %s: метод не найден", name); return false; }
    void* target = *(void**)m; // methodPointer - первое поле MethodInfo
    bool ok = MH_CreateHook(target, detour, orig) == MH_OK && MH_EnableHook(target) == MH_OK;
    Log("hook %s @ %p: %s", name, target, ok ? "ok" : "FAIL");
    return ok;
}

// ------------------------------------------------------------------ выгрузка
static DWORD WINAPI UnloadThread(LPVOID) {
    Log("unload: старт");
    for (int i = 0; i < 80 && !(g_gameClean && g_overlayDown); i++) Sleep(50); // ждём, пока игровой и рендер-потоки всё вернут
    MH_DisableHook(MH_ALL_HOOKS);
    Sleep(500);                       // даём доработать потокам, которые ещё внутри наших хуков
    MH_Uninitialize();
    Log("unload: готово");
    FreeLibraryAndExitThread(g_self, 0);
    return 0;
}
static void RequestUnload() {
    if (g_unload.exchange(true)) return;
    g_menuOpen = false; g_ready = false;
    CreateThread(nullptr, 0, UnloadThread, nullptr, 0, nullptr);
}

// ------------------------------------------------------------------ UI
static void Style() {
    ImGui::StyleColorsDark();
    auto& s = ImGui::GetStyle(); auto* c = s.Colors;
    s.WindowRounding = 4; s.FrameRounding = 2; s.GrabRounding = 2; s.TabRounding = 2;
    c[ImGuiCol_WindowBg] = ImVec4(0.04f, 0.05f, 0.08f, 0.96f);
    c[ImGuiCol_TitleBg] = c[ImGuiCol_TitleBgActive] = ImVec4(0.14f, 0.27f, 0.50f, 1);
    c[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.16f, 0.30f, 1);
    c[ImGuiCol_Button] = ImVec4(0.14f, 0.27f, 0.50f, 1);
    c[ImGuiCol_ButtonHovered] = ImVec4(0.20f, 0.36f, 0.65f, 1);
    c[ImGuiCol_Tab] = ImVec4(0.14f, 0.27f, 0.50f, 1);
    c[ImGuiCol_TabHovered] = ImVec4(0.22f, 0.40f, 0.72f, 1);
    c[ImGuiCol_TabActive] = ImVec4(0.20f, 0.36f, 0.65f, 1);
    c[ImGuiCol_CheckMark] = c[ImGuiCol_SliderGrab] = ImVec4(0.26f, 0.55f, 0.98f, 1);
}

static char g_filter[64] = ""; static char g_key[96] = "GoldCount"; static char g_strVal[128] = ""; static int g_keyVal = 0;
static int g_sel = -1; static uint32_t g_selH = 0; static std::string g_selName; static V3 g_selPos{}; static V3 g_tgt{ 0, 0, 0 };
static bool g_wipeOk = false;

static void* Tgt(uint32_t h) { return il2::il2cpp_gchandle_get_target(h); }

static void TabCurrency() {
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Голда", &g_cfg.goldSet, 0, 0);
    if (ImGui::Button("Установить")) { int v = g_cfg.goldSet; Enqueue([v] { G::SetGold(v); }); }
    { std::lock_guard<std::mutex> l(g_mx); ImGui::Text("Сейчас: %s", g_goldNow.c_str()); }
    ImGui::Separator();
    ImGui::TextUnformatted("Награда за убийство (режим полигона) — голова и тело:");
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Голда за килл", &g_cfg.rewGold, 100, 1000);
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Опыт за килл", &g_cfg.rewExp, 100, 1000);
    if (ImGui::Button("Применить")) { g_cfg.rewHold = true; Enqueue([] { G::ApplyRewardFields(); Say("Награда применена и будет удерживаться"); }); }
    ImGui::Checkbox("Дозачислять, если игра не дала награду (ограничения, например 999 опыта)", &g_cfg.topUp);
    ImGui::Separator();
    ImGui::TextUnformatted("Опыт:");
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Добавить опыт", &g_cfg.expAdd, 1000, 10000);
    ImGui::SameLine(); if (ImGui::Button("Накрутить")) { int v = g_cfg.expAdd; Enqueue([v] { G::AddExp(v); }); }
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Уровень", &g_cfg.levelSet, 1, 10);
    ImGui::SameLine(); if (ImGui::Button("Задать уровень")) { int v = g_cfg.levelSet; Enqueue([v] { G::SetLevel(v); }); }
    { std::lock_guard<std::mutex> l(g_mx); ImGui::Text("Опыт (LevelProgress): %s   Уровень (LevelCount): %s", g_expNow.c_str(), g_lvlNow.c_str()); }
    ImGui::Separator();
    ImGui::TextUnformatted("Достижения (открой экран достижений в игре):");
    if (ImGui::Button("Выполнить текущий уровень всех")) Enqueue([] { G::DoAchievements(1); });
    ImGui::SameLine(); if (ImGui::Button("Пройти все уровни до конца")) Enqueue([] { G::DoAchievements(1000); });
}
static void TabPlayer() {
    { std::lock_guard<std::mutex> l(g_mx); ImGui::TextColored(g_playerFound ? ImVec4(0.4f, 1, 0.4f, 1) : ImVec4(1, 0.5f, 0.4f, 1), g_playerFound ? "PlayerController найден" : "PlayerController не найден (зайди в игровую сцену)"); }
    ImGui::Checkbox("Быстрый бхоп (держи пробел)", &g_cfg.bhop);
    ImGui::Checkbox("Ускоренная ходьба", &g_cfg.fastWalk); ImGui::SameLine(); ImGui::SetNextItemWidth(200); ImGui::SliderFloat("Скорость (x)", &g_cfg.walkMul, 1.f, 6.f);
    ImGui::Checkbox("Высокий прыжок", &g_cfg.highJump); ImGui::SameLine(); ImGui::SetNextItemWidth(200); ImGui::SliderFloat("Высота прыжка (x)", &g_cfg.jumpMul, 1.f, 6.f);
    ImGui::Checkbox("Бессмертие (босс/поражение не убивает)", &g_cfg.god);
    ImGui::Checkbox("Ноуклип / полёт (WASD, Пробел вверх, Ctrl вниз, Shift быстрее)", &g_cfg.noclip);
    ImGui::SetNextItemWidth(260); ImGui::SliderFloat("Скорость полёта (м/с)", &g_cfg.flySpeed, 2.f, 60.f);
}
static void TabEnemies() {
    ImGui::Checkbox("Босса Шурика можно убить любым оружием", &g_cfg.bossAny);
    ImGui::SetNextItemWidth(300); ImGui::SliderInt("Мин. урон по боссу", &g_cfg.bossMinDmg, 100, 1000000);
    if (ImGui::Button("Вызвать босса (F6) — на любой карте")) Enqueue([] { G::SpawnBoss(); });
    ImGui::SameLine(); if (ImGui::Button("Убрать всех ботов")) Enqueue([] { G::RemoveBots(); });
    ImGui::Checkbox("Снять лимит ботов", &g_cfg.noLimit);
    { std::lock_guard<std::mutex> l(g_mx); ImGui::Text("Врагов на сцене: %d", g_enemyCount); }
}
static void TabEsp() {
    ImGui::Checkbox("WallHack", &g_cfg.wh);
    ImGui::RadioButton("Чамсы", &g_cfg.whMode, 0); ImGui::SameLine(); ImGui::RadioButton("Боксы", &g_cfg.whMode, 1); ImGui::SameLine(); ImGui::RadioButton("Оба", &g_cfg.whMode, 2);
    ImGui::Checkbox("Здоровье", &g_cfg.espHealth); ImGui::SameLine(); ImGui::Checkbox("Линии", &g_cfg.espLines);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Высота врага (боксы/аим)", &g_cfg.enemyH, 1.0f, 3.0f);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Поправка по голове (м)", &g_cfg.headFix, 0.0f, 0.5f);
    { std::lock_guard<std::mutex> l(g_mx); ImGui::Text("Врагов на сцене: %d", g_enemyCount); }
    ImGui::Separator();
    ImGui::Checkbox("Аим", &g_cfg.aim);
    ImGui::RadioButton("Голова", &g_cfg.aimPart, 0); ImGui::SameLine(); ImGui::RadioButton("Тело", &g_cfg.aimPart, 1); ImGui::SameLine(); ImGui::RadioButton("Ноги", &g_cfg.aimPart, 2);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Плавность", &g_cfg.aimSmooth, 0.0f, 0.95f);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Угол захвата", &g_cfg.aimFov, 5.f, 180.f);
}
static void TabItems() {
    ImGui::TextWrapped("Скинченджер (экспериментально): добавить в инвентарь предметы из каталога игры. Открой инвентарь в меню игры.");
    if (ImGui::Button("Выдать все предметы")) Enqueue([] { G::DoGiveItems(); });
}
static void TabScene() {
    V3 me; { std::lock_guard<std::mutex> l(g_mx); me = g_playerPos; }
    ImGui::Text("Игрок: %.2f  %.2f  %.2f", me.x, me.y, me.z);
    ImGui::SetNextItemWidth(330); ImGui::DragFloat3("XYZ", &g_tgt.x, 0.1f);
    ImGui::SameLine(); if (ImGui::Button("Моя позиция")) g_tgt = me;
    if (ImGui::Button("Телепорт игрока в XYZ")) { V3 p = g_tgt; Enqueue([p] { G::Teleport(p); Say("Телепорт в заданные координаты"); }); }
    ImGui::SameLine(); if (ImGui::Button("Обновить список объектов")) Enqueue([] { G::SceneRefresh(); g_sel = -1; Say("Объектов в списке: " + std::to_string(g_scene.size())); });
    ImGui::SetNextItemWidth(250); ImGui::InputText("Фильтр", g_filter, sizeof g_filter);
    ImGui::SameLine(); ImGui::Checkbox("Только включённые", &g_cfg.sceneOnlyActive);
    std::string flt = g_filter; std::transform(flt.begin(), flt.end(), flt.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    { std::lock_guard<std::mutex> l(g_mx); g_labelFilter = flt; }
    ImGui::Checkbox("Показывать названия возле объектов", &g_cfg.sceneLabels);
    if (g_cfg.sceneLabels) {
        ImGui::SameLine(); ImGui::SetNextItemWidth(130); ImGui::SliderFloat("Радиус (м)", &g_cfg.labelDist, 5.f, 200.f);
        ImGui::SameLine(); ImGui::SetNextItemWidth(110); ImGui::SliderInt("Макс.", &g_cfg.labelMax, 10, 300);
        ImGui::TextDisabled("Подписи берутся из списка (нажми «Обновить список объектов»). Фильтр выше сужает подписи.");
    }
    ImGui::BeginChild("objs", ImVec2(0, 190), true);
    {
        std::lock_guard<std::mutex> l(g_mx); int shown = 0;
        for (int i = 0; i < (int)g_scene.size() && shown < 500; i++) {
            auto& e = g_scene[i];
            if (g_cfg.sceneOnlyActive && !e.active) continue;
            if (!flt.empty()) { std::string n = e.name; std::transform(n.begin(), n.end(), n.begin(), [](unsigned char c) { return (char)std::tolower(c); }); if (n.find(flt) == std::string::npos) continue; }
            shown++; char lab[256]; snprintf(lab, sizeof lab, "%s%s  (%.1f, %.1f, %.1f)###o%d", e.active ? "" : "[выкл] ", e.name.c_str(), e.pos.x, e.pos.y, e.pos.z, i);
            if (ImGui::Selectable(lab, g_sel == i)) { g_sel = i; g_selH = e.h; g_selName = e.name; g_selPos = e.pos; }
        }
    }
    ImGui::EndChild();
    if (g_sel >= 0) {
        ImGui::Text("Выбран: %s", g_selName.c_str());
        ImGui::SetNextItemWidth(330); ImGui::DragFloat3("Позиция объекта", &g_selPos.x, 0.1f);
        uint32_t h = g_selH; V3 sp = g_selPos;
        if (ImGui::Button("ТП к объекту")) Enqueue([h] { void* t = Tgt(h); V3 p; if (t && G::PosOf(t, p)) { G::Teleport({ p.x, p.y + 1.2f, p.z }); Say("Телепорт к объекту"); } else Say("Объект уже недоступен"); });
        ImGui::SameLine(); if (ImGui::Button("Объект ко мне")) Enqueue([h] { void* t = Tgt(h); V3 p = g_playerPos; p.y += 1; if (t && G::TrOf(t)) { G::Call(G::mSetPos, G::TrOf(t), { &p }); Say("Объект перемещён к игроку"); } });
        ImGui::SameLine(); if (ImGui::Button("Применить позицию")) Enqueue([h, sp] { void* t = Tgt(h); V3 p = sp; if (t && G::TrOf(t)) { G::Call(G::mSetPos, G::TrOf(t), { &p }); Say("Позиция объекта изменена"); } });
        if (ImGui::Button("Вкл/выкл объект")) Enqueue([h] { void* t = Tgt(h); auto go = t ? G::Call(G::mGetGO, t) : nullptr; if (go) { bool a = il2::Unbox<bool>(G::Call(G::mActiveSelf, go), true); bool n = !a; G::Call(G::mSetActive, go, { &n }); Say(n ? "Объект включён" : "Объект выключен"); } });
        ImGui::SameLine(); if (ImGui::Button("Удалить объект")) Enqueue([h] { void* t = Tgt(h); auto go = t ? G::Call(G::mGetGO, t) : nullptr; if (go) { G::Call(G::mDestroy, nullptr, { go }); Say("Объект удалён"); } });
        ImGui::SameLine(); if (ImGui::Button("Скопировать в XYZ")) g_tgt = g_selPos;
    }
}
static void TabKey() {
    ImGui::InputText("Ключ", g_key, sizeof g_key);
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Значение", &g_keyVal, 1, 1000);
    ImGui::InputText("Строка", g_strVal, sizeof g_strVal);
    std::string k = g_key; int v = g_keyVal; std::string sv = g_strVal;
    if (ImGui::Button("Прочитать (защищённое)")) Enqueue([k] { Say(k + " = " + std::to_string(G::PsGet(k.c_str()))); });
    ImGui::SameLine(); if (ImGui::Button("Записать число (защищённое)")) Enqueue([k, v] { G::PsSet(k.c_str(), v); G::PrefsSave(); G::RefreshMoney(); Say("Записано: " + k + " = " + std::to_string(v)); });
    if (ImGui::Button("Записать число (обычное)")) Enqueue([k, v] { auto ks = il2::Str(k.c_str()); int vv = v; G::Call(G::mPrefsSetInt, nullptr, { ks, &vv }); G::PrefsSave(); Say("Записано (обычное): " + k); });
    ImGui::SameLine(); if (ImGui::Button("Записать строку")) Enqueue([k, sv] { G::Call(G::mPrefsSetStr, nullptr, { il2::Str(k.c_str()), il2::Str(sv.c_str()) }); G::PrefsSave(); Say("Строка записана: " + k); });
}
static void TabOptions() {
    ImGui::Checkbox("Блокировать управление, пока меню открыто", &g_cfg.blockInput);
    ImGui::Checkbox("Показывать надпись GoldCheat", &g_cfg.watermark);
    ImGui::TextUnformatted("Клавиша меню: Home");
    ImGui::Separator();
    if (ImGui::Button("Выгрузить чит из игры")) RequestUnload();
    ImGui::SameLine(); ImGui::TextDisabled("(вернёт настройки игры и отключит все хуки)");
    ImGui::Separator();
    ImGui::TextUnformatted("Жёсткая очистка: удаляет ВСЕ сохранения игры (PlayerPrefs)");
    ImGui::Checkbox("Я понимаю, что прогресс пропадёт", &g_wipeOk);
    if (g_wipeOk && ImGui::Button("Очистить всё")) { g_wipeOk = false; Enqueue([] { G::Call(G::mPrefsDelAll, nullptr); G::PrefsSave(); Say("Все сохранения PlayerPrefs удалены. Перезапусти игру."); }); }
}

static void DrawUi() {
    ImGuiIO& io = ImGui::GetIO();
    // ESP
    std::vector<EspEnt> esp; float sw, sh;
    { std::lock_guard<std::mutex> l(g_mx); esp = g_esp; sw = g_scrW; sh = g_scrH; }
    if (g_cfg.wh && g_cfg.whMode != 0) {
        auto* dl = ImGui::GetBackgroundDrawList(); float kx = io.DisplaySize.x / sw, ky = io.DisplaySize.y / sh;
        for (auto& e : esp) {
            ImVec2 a(e.x1 * kx, e.y1 * ky), b(e.x2 * kx, e.y2 * ky);
            dl->AddRect(ImVec2(a.x - 1, a.y - 1), ImVec2(b.x + 1, b.y + 1), IM_COL32(0, 0, 0, 255));
            dl->AddRect(a, b, IM_COL32(255, 60, 60, 255), 0, 0, 1.6f);
            if (e.hasHp) { char t[16]; snprintf(t, sizeof t, "%d", e.hp); dl->AddText(ImVec2(a.x, a.y - 14), IM_COL32(120, 255, 120, 255), t); }
            if (g_cfg.espLines) dl->AddLine(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y), ImVec2(e.sx * kx, e.sy * ky), IM_COL32(255, 220, 60, 160));
        }
    }
    // названия объектов рядом с ними
    if (g_cfg.sceneLabels) {
        std::vector<LabelEnt> labs; float lw, lh;
        { std::lock_guard<std::mutex> l(g_mx); labs = g_labels; lw = g_labW; lh = g_labH; }
        auto* dl = ImGui::GetBackgroundDrawList(); float kx = io.DisplaySize.x / lw, ky = io.DisplaySize.y / lh;
        for (auto& e : labs) {
            char t[200]; snprintf(t, sizeof t, "%s [%.0fм]", e.name.c_str(), e.dist);
            ImVec2 p(e.x * kx, e.y * ky);
            dl->AddText(ImVec2(p.x + 1, p.y + 1), IM_COL32(0, 0, 0, 255), t);
            dl->AddText(p, IM_COL32(120, 220, 255, 255), t);
        }
    }
    // надпись (жёлтая, снизу слева)
    if (g_cfg.watermark) {
        auto* dl = ImGui::GetForegroundDrawList(); ImFont* f = ImGui::GetFont(); float sz = 44.f; ImVec2 p(18, io.DisplaySize.y - 70);
        dl->AddText(f, sz, ImVec2(p.x + 2, p.y + 2), IM_COL32(0, 0, 0, 220), "GoldCheat");
        dl->AddText(f, sz, p, IM_COL32(255, 205, 20, 255), "GoldCheat");
    }
    if (!g_menuOpen) return;
    ImGui::SetNextWindowSize(ImVec2(620, 520), ImGuiCond_FirstUseEver); ImGui::SetNextWindowPos(ImVec2(30, 40), ImGuiCond_FirstUseEver);
    bool open = true;
    if (ImGui::Begin("GoldCheat  [Home]", &open)) {
        if (ImGui::BeginTabBar("tabs")) {
            if (ImGui::BeginTabItem("Валюта")) { TabCurrency(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Игрок")) { TabPlayer(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Враги")) { TabEnemies(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("ESP")) { TabEsp(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Предметы")) { TabItems(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Сцена")) { TabScene(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Ключ")) { TabKey(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Опции")) { TabOptions(); ImGui::EndTabItem(); }
            ImGui::EndTabBar();
        }
        ImGui::Separator();
        std::lock_guard<std::mutex> l(g_mx);
        ImGui::TextWrapped("%s", g_status.c_str());
    }
    ImGui::End();
    if (!open) g_menuOpen = false;
}

// ------------------------------------------------------------------ D3D11 Present hook
typedef HRESULT(__stdcall* tPresent)(IDXGISwapChain*, UINT, UINT);
static tPresent oPresent; static WNDPROC oWndProc; static HWND g_hwnd;
static ID3D11Device* g_dev; static ID3D11DeviceContext* g_ctx; static bool g_imInit = false;

static LRESULT CALLBACK hkWndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (g_unload) return CallWindowProcW(oWndProc, h, m, w, l);
    if (m == WM_KEYDOWN && w == VK_HOME && !(l & (1 << 30))) g_menuOpen = !g_menuOpen;
    if (g_menuOpen) {
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
        ImGuiIO& io = ImGui::GetIO();
        // WM_SETCURSOR и отпускание клавиш НЕ глушим: игра сама рисует свой курсор и не "залипает" на клавишах
        bool mouse = (m >= WM_MOUSEFIRST && m <= WM_MOUSELAST) || m == WM_INPUT;
        bool key = m == WM_KEYDOWN || m == WM_CHAR || m == WM_SYSKEYDOWN;
        if (g_cfg.blockInput ? (mouse || key) : ((mouse && io.WantCaptureMouse) || (key && io.WantCaptureKeyboard))) return TRUE;
    }
    return CallWindowProcW(oWndProc, h, m, w, l);
}
static HRESULT __stdcall hkPresent(IDXGISwapChain* sc, UINT si, UINT fl) {
    if (!g_imInit && !g_unload) {
        if (SUCCEEDED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_dev))) {
            g_dev->GetImmediateContext(&g_ctx);
            DXGI_SWAP_CHAIN_DESC d; sc->GetDesc(&d); g_hwnd = d.OutputWindow;
            ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO(); io.IniFilename = nullptr; io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange; // не подменяем системный курсор
            const char* fonts[] = { "C:\\Windows\\Fonts\\segoeui.ttf", "C:\\Windows\\Fonts\\arial.ttf", "C:\\Windows\\Fonts\\tahoma.ttf" };
            for (auto f : fonts) if (GetFileAttributesA(f) != INVALID_FILE_ATTRIBUTES) { io.Fonts->AddFontFromFileTTF(f, 16.f, nullptr, io.Fonts->GetGlyphRangesCyrillic()); break; }
            Style();
            ImGui_ImplWin32_Init(g_hwnd); ImGui_ImplDX11_Init(g_dev, g_ctx);
            oWndProc = (WNDPROC)SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)hkWndProc);
            g_imInit = true; Log("overlay: D3D11 ready (hwnd=%p)", g_hwnd);
        }
    }
    if (g_unload && g_imInit) { // выгрузка: гасим оверлей в рендер-потоке
        if (oWndProc && GetWindowLongPtrW(g_hwnd, GWLP_WNDPROC) == (LONG_PTR)hkWndProc) SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)oWndProc);
        ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
        if (g_ctx) { g_ctx->Release(); g_ctx = nullptr; } if (g_dev) { g_dev->Release(); g_dev = nullptr; }
        g_imInit = false; g_overlayDown = true; Log("overlay: выключен");
    }
    if (g_unload && !g_imInit) { g_overlayDown = true; return oPresent(sc, si, fl); }
    if (g_imInit) {
        ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
        ImGui::GetIO().MouseDrawCursor = false; // курсор рисует сама игра (свой кастомный), ImGui его не дублирует
        DrawUi();
        ImGui::Render();
        ID3D11Texture2D* bb = nullptr; ID3D11RenderTargetView* rtv = nullptr;
        if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb))) {
            g_dev->CreateRenderTargetView(bb, nullptr, &rtv); bb->Release();
            g_ctx->OMSetRenderTargets(1, &rtv, nullptr);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
            rtv->Release();
        }
    }
    return oPresent(sc, si, fl);
}
static bool HookPresent() {
    WNDCLASSEXA wc = { sizeof wc, CS_CLASSDC, DefWindowProcA, 0, 0, GetModuleHandleA(nullptr), 0, 0, 0, 0, "GoldModDummy", 0 };
    RegisterClassExA(&wc);
    HWND w = CreateWindowA("GoldModDummy", "d", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, 0, 0, wc.hInstance, 0);
    DXGI_SWAP_CHAIN_DESC sd = {}; sd.BufferCount = 1; sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = w; sd.SampleDesc.Count = 1; sd.Windowed = TRUE; sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    IDXGISwapChain* sc = nullptr; ID3D11Device* dev = nullptr; ID3D11DeviceContext* ctx = nullptr; D3D_FEATURE_LEVEL fl;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &sd, &sc, &dev, &fl, &ctx);
    if (FAILED(hr)) { Log("D3D11 dummy failed: 0x%08lx", hr); DestroyWindow(w); UnregisterClassA("GoldModDummy", wc.hInstance); return false; }
    void* present = (*(void***)sc)[8];
    bool ok = MH_CreateHook(present, (void*)hkPresent, (void**)&oPresent) == MH_OK && MH_EnableHook(present) == MH_OK;
    Log("D3D11 Present hook @ %p: %s", present, ok ? "ok" : "FAIL");
    sc->Release(); dev->Release(); ctx->Release(); DestroyWindow(w); UnregisterClassA("GoldModDummy", wc.hInstance);
    return ok;
}

// ------------------------------------------------------------------ инициализация
static DWORD WINAPI InitThread(LPVOID) {
    Log("GoldCheat start");
    while (!GetModuleHandleA("GameAssembly.dll")) Sleep(300);
    bool exportsOk = il2::Init();
    if (!exportsOk) { Say("il2cpp exports not available - abort"); return 0; }
    for (int i = 0; i < 240; i++) { // ждём домен и Assembly-CSharp (до ~2 минут)
        if (il2::il2cpp_domain_get() && il2::il2cpp_domain_get()) {
            il2::Attach();
            if (il2::FindClassIn("Assembly-CSharp.dll", "", "PlayerController")) break;
        }
        Sleep(500);
    }
    il2::Attach();
    if (!G::Bind()) { Say("Привязка к игре не выполнена (см. GoldCheat.log). Игра обновилась? Пришли GoldCheat.log и новый dump.cs"); }
    MH_Initialize();
    HookPresent();
    HookMethod(il2::Method(il2::FindClass("FMODUnity", "RuntimeManager"), "Update", 0), (void*)hkUpd, (void**)&oUpd, "RuntimeManager.Update");
    HookMethod(il2::Method(G::kPlayer, "HitEnemy", 3), (void*)hkHit, (void**)&oHit, "PlayerController.HitEnemy");
    HookMethod(il2::Method(il2::FindClassIn("Assembly-CSharp.dll", "", "TriggerLose"), "OnTriggerEnter", 1), (void*)hkTrig, (void**)&oTrig, "TriggerLose.OnTriggerEnter");
    g_ready = true; Say("GoldCheat загружен. Home - меню");
    return 0;
}

BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h; DisableThreadLibraryCalls(h); InitializeCriticalSection(&g_logCs);
        GetModuleFileNameA(h, g_logPath, MAX_PATH); char* s = strrchr(g_logPath, '\\'); if (s) *(s + 1) = 0; strcat(g_logPath, "GoldCheat.log");
        CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
    }
    return TRUE;
}
