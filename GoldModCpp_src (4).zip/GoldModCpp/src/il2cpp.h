#pragma once
// Тонкая обёртка над экспортами il2cpp из GameAssembly.dll.
// Всё ищется ПО ИМЕНАМ/СИГНАТУРАМ через метаданные, а не по жёстким адресам,
// поэтому мод переживает обновления игры, если имена классов не поменялись.
#include <cstdint>
#include <cstddef>
#include <initializer_list>

namespace il2 {

struct Domain; struct Assembly; struct Image; struct Klass; struct Method;
struct Field; struct Type; struct Object; struct String; struct Thread;

#define IL2_FUNCS(X) \
    X(Domain*,  il2cpp_domain_get,                 ()) \
    X(Thread*,  il2cpp_thread_attach,              (Domain*)) \
    X(Assembly**, il2cpp_domain_get_assemblies,    (const Domain*, size_t*)) \
    X(Image*,   il2cpp_assembly_get_image,         (const Assembly*)) \
    X(const char*, il2cpp_image_get_name,          (const Image*)) \
    X(Klass*,   il2cpp_class_from_name,            (const Image*, const char*, const char*)) \
    X(Method*,  il2cpp_class_get_methods,          (Klass*, void**)) \
    X(const char*, il2cpp_method_get_name,         (const Method*)) \
    X(uint32_t, il2cpp_method_get_param_count,     (const Method*)) \
    X(Type*,    il2cpp_method_get_param,           (const Method*, uint32_t)) \
    X(Type*,    il2cpp_method_get_return_type,     (const Method*)) \
    X(uint32_t, il2cpp_method_get_flags,           (const Method*, uint32_t*)) \
    X(char*,    il2cpp_type_get_name,              (const Type*)) \
    X(Field*,   il2cpp_class_get_field_from_name,  (Klass*, const char*)) \
    X(size_t,   il2cpp_field_get_offset,           (Field*)) \
    X(void,     il2cpp_field_static_get_value,     (Field*, void*)) \
    X(void,     il2cpp_field_static_set_value,     (Field*, void*)) \
    X(Object*,  il2cpp_runtime_invoke,             (const Method*, void*, void**, Object**)) \
    X(String*,  il2cpp_string_new,                 (const char*)) \
    X(Type*,    il2cpp_class_get_type,             (Klass*)) \
    X(Object*,  il2cpp_type_get_object,            (const Type*)) \
    X(void*,    il2cpp_object_unbox,               (Object*)) \
    X(void,     il2cpp_runtime_class_init,         (Klass*))

#define X(ret, name, args) extern ret (*name) args;
IL2_FUNCS(X)
#undef X

bool Load();                                   // GetProcAddress всех функций
bool AttachThread();                           // il2cpp_thread_attach для текущего потока
Klass*  FindClass(const char* ns, const char* name);

// staticMode: -1 любой, 0 только instance, 1 только static.
// params: имена типов параметров ("System.String", "System.Int32"...), "*" = любой.
// name == nullptr  -> имя не проверяется (нужно для обфусцированных методов).
// ret == nullptr   -> возвращаемый тип не проверяется.
Method* FindMethod(Klass* k, const char* name, std::initializer_list<const char*> params,
                   const char* ret = nullptr, int staticMode = -1);

int     FieldOffset(Klass* k, const char* name);       // -1 если нет
Field*  FindField(Klass* k, const char* name);

void*   MethodPointer(Method* m);                      // MethodInfo->methodPointer
Object* Invoke(Method* m, void* obj, void** args);     // nullptr при исключении (ok=false)
extern bool g_lastInvokeFailed;

Object* TypeObject(Klass* k);                          // System.Type объект класса
template <class T> inline T UnboxAs(Object* o, T def) { return o ? *(T*)il2cpp_object_unbox(o) : def; }

// Il2CppArray: [object header 8][bounds 4][max_length 4][elements...] на x86
inline int   ArrayLen(void* arr)            { return arr ? *(int*)((char*)arr + 12) : 0; }
inline void* ArrayAt(void* arr, int i)      { return ((void**)((char*)arr + 16))[i]; }

} // namespace il2
