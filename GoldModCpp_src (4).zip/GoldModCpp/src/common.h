#pragma once
#include <windows.h>

// Лог пишется в GoldMod.log рядом с папкой игры (рядом с exe)
void Log(const char* fmt, ...);

extern HMODULE g_self;   // наш dll
