#pragma once
namespace overlay {
// Ставит хуки на Present (D3D11) и Present/Reset (D3D9). Какой API реально используется —
// определяется тем, чей Present вызовется первым.
bool Init();
}
