#include "game.h"
#include "il2cpp.h"
#include "common.h"
#include "MinHook.h"

#include <cstring>
#include <mutex>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <unordered_set>

using namespace il2;

namespace game {

Settings S;

// ----------------------------------------------------------------------------------------
// состояние
// ----------------------------------------------------------------------------------------
static std::mutex            g_mx;          // снимок + статус
static Snapshot              g_snap;
static std::mutex            g_qmx;         // очередь команд
static std::vector<std::function<void()>> g_queue;

static void SetStatus(const std::string& s) { std::lock_guard<std::mutex> l(g_mx); g_snap.status = s; }

Snapshot Snap() { std::lock_guard<std::mutex> l(g_mx); return g_snap; }
void Post(std::function<void()> fn) { std::lock_guard<std::mutex> l(g_qmx); g_queue.push_back(std::move(fn)); }

// ----------------------------------------------------------------------------------------
// привязки к игре
// ----------------------------------------------------------------------------------------
static struct Bind {
    Klass *cController = nullptr, *cInventory = nullptr, *cPolygon = nullptr, *cEnemy = nullptr,
          *cPlayer = nullptr, *cPrefsSafe = nullptr, *cInt = nullptr, *cFloat = nullptr,
          *cPlayerPrefs = nullptr, *cBehaviour = nullptr, *cObject = nullptr, *cCursor = nullptr,
          *cRuntimeMgr = nullptr, *cComponent = nullptr, *cTransform = nullptr, *cOutline = nullptr,
          *cAchCtl = nullptr, *cAchive = nullptr, *cItemShop = nullptr, *cCamera = nullptr, *cScreen = nullptr, *cGameObject = nullptr;

    Method *prefGet = nullptr, *prefSet = nullptr, *prefsSave = nullptr, *loadMoney = nullptr,
           *intTo = nullptr, *intFrom = nullptr, *floatTo = nullptr, *floatFrom = nullptr,
           *findOne = nullptr, *findAll = nullptr, *setEnabled = nullptr,
           *getLock = nullptr, *setLock = nullptr, *setVisible = nullptr, *rmUpdate = nullptr,
           *getTransform = nullptr, *getPos = nullptr, *w2s = nullptr, *getGO = nullptr, *goGetTransform = nullptr, *instantiate = nullptr, *goSetActive = nullptr, *objDestroy = nullptr, *scrW = nullptr, *scrH = nullptr,
           *olMode = nullptr, *olWidth = nullptr, *olColor = nullptr,
           *ppSetInt = nullptr, *ppSetStr = nullptr, *ppDeleteAll = nullptr;

    Field *fCountEnemy = nullptr, *fCountEnemyMax = nullptr, *fPolygonObj = nullptr,
          *fMoneyHeadS = nullptr, *fMoneyBodyS = nullptr, *fAchObj = nullptr, *fInvObj = nullptr, *fExpHeadS = nullptr, *fExpBodyS = nullptr, *fPolyEnemy = nullptr;

    int oWallHack = -1, oHealth = -1, oMoneyHead = -1, oMoneyBody = -1, oControl = -1;
    int oWalk = -1, oAccel = -1, oAccelMax = -1, oJump = -1;
    int oWalkF = -1, oNewWalkF = -1, oOldWalkF = -1, oAccelF = -1, oAccelMaxF = -1, oJumpF = -1;
    int oCamera = -1, oCharRot = -1, oCamRot = -1, oMinX = -1, oMaxX = -1, oClampV = -1, oJumpPeremes = -1;
    int oAchives = -1, oAchCountMain = -1, oAchNumber = -1, oAchFinish = -1, oAchLevel = -1;
    int oAllItems = -1, oItemNumber = -1, oHealthAll = -1, oExpHead = -1, oExpBody = -1, oCharCtl = -1, oEnemy2Prefab = -1, oSpawners = -1;

    Object *typePlayer = nullptr, *typeEnemy = nullptr;
    bool ok = false;
} B;

// ----------------------------------------------------------------------------------------
// мелкие помощники (главный поток)
// ----------------------------------------------------------------------------------------
static int PrefGet(const char* key, int def)
{
    void* a[2] = { il2cpp_string_new(key), &def };
    return UnboxAs<int>(Invoke(B.prefGet, nullptr, a), def);
}

static void PrefSet(const char* key, int v)
{
    void* a[2] = { il2cpp_string_new(key), &v };
    Invoke(B.prefSet, nullptr, a);
}

// Защищённый Int игры = { int value; int salt; } — кодируем/декодируем ЕГО ЖЕ методами
static void EncodeInt(int v, uint8_t out[8])
{
    void* a[1] = { &v };
    Object* r = Invoke(B.intTo, nullptr, a);
    if (r) std::memcpy(out, il2cpp_object_unbox(r), 8); else std::memset(out, 0, 8);
}

static int DecodeInt(const uint8_t in[8])
{
    uint8_t tmp[8]; std::memcpy(tmp, in, 8);
    void* a[1] = { tmp };
    return UnboxAs<int>(Invoke(B.intFrom, nullptr, a), 0);
}

static void EncodeFloat(float v, uint8_t out[8])
{
    void* a[1] = { &v };
    Object* r = Invoke(B.floatTo, nullptr, a);
    if (r) std::memcpy(out, il2cpp_object_unbox(r), 8); else std::memset(out, 0, 8);
}

static float DecodeFloat(const uint8_t in[8], float def)
{
    if (!B.floatFrom) return def;
    uint8_t tmp[8]; std::memcpy(tmp, in, 8);
    void* a[1] = { tmp };
    return UnboxAs<float>(Invoke(B.floatFrom, nullptr, a), def);
}

static bool StaticIntGet(Field* f, int& out)
{
    if (!f) return false;
    uint8_t buf[8] = {};
    il2cpp_field_static_get_value(f, buf);
    out = DecodeInt(buf);
    return true;
}

static void StaticIntSet(Field* f, int v)
{
    if (!f) return;
    uint8_t buf[8];
    EncodeInt(v, buf);
    il2cpp_field_static_set_value(f, buf);
}

template <class T> static T& At(void* obj, int off) { return *(T*)((char*)obj + off); }

static void* FindOne(Object* type)
{
    bool inactive = false;
    void* a[2] = { type, &inactive };
    return Invoke(B.findOne, nullptr, a);
}

static void* FindAll(Object* type)
{
    void* a[1] = { type };
    return Invoke(B.findAll, nullptr, a);
}

static void SetEnabled(void* behaviour, bool on)
{
    if (!behaviour) return;
    void* a[1] = { &on };
    Invoke(B.setEnabled, behaviour, a);
}

// ----------------------------------------------------------------------------------------
// привязка (поток инициализации)
// ----------------------------------------------------------------------------------------
static bool BindAll()
{
    B.cController  = FindClass("", "Controller");
    B.cInventory   = FindClass("", "ControllerInventory");
    B.cPolygon     = FindClass("", "ControllerPolygon");
    B.cEnemy       = FindClass("", "EnemyController");
    B.cPlayer      = FindClass("", "PlayerController");
    B.cPrefsSafe   = FindClass("", "PlayerPrefsSafe");
    B.cInt         = FindClass("", "Int");
    B.cFloat       = FindClass("", "Float");
    B.cPlayerPrefs = FindClass("UnityEngine", "PlayerPrefs");
    B.cBehaviour   = FindClass("UnityEngine", "Behaviour");
    B.cObject      = FindClass("UnityEngine", "Object");
    B.cCursor      = FindClass("UnityEngine", "Cursor");
    B.cRuntimeMgr  = FindClass("FMODUnity", "RuntimeManager");

    if (!B.cController || !B.cInventory || !B.cPolygon || !B.cEnemy || !B.cPlayer || !B.cPrefsSafe ||
        !B.cInt || !B.cFloat || !B.cPlayerPrefs || !B.cBehaviour || !B.cObject || !B.cRuntimeMgr)
    {
        Log("BindAll: не найден один из классов (Controller=%p Inventory=%p Polygon=%p Enemy=%p Player=%p "
            "PrefsSafe=%p Int=%p Float=%p PlayerPrefs=%p Behaviour=%p Object=%p RuntimeManager=%p)",
            B.cController, B.cInventory, B.cPolygon, B.cEnemy, B.cPlayer, B.cPrefsSafe, B.cInt, B.cFloat,
            B.cPlayerPrefs, B.cBehaviour, B.cObject, B.cRuntimeMgr);
        return false;
    }

    // PlayerPrefsSafe: имена обфусцированы, ищем по сигнатуре (string,int)->int / ->void
    B.prefGet = FindMethod(B.cPrefsSafe, nullptr, { "System.String", "System.Int32" }, "System.Int32", 1);
    B.prefSet = FindMethod(B.cPrefsSafe, nullptr, { "System.String", "System.Int32" }, "System.Void", 1);
    B.prefsSave = FindMethod(B.cPlayerPrefs, "Save", {}, nullptr, 1);
    B.loadMoney = FindMethod(B.cInventory, "LoadMoney", {}, nullptr, 1);

    // защищённые типы Int / Float: static Int(int) и static int(Int); static Float(float)
    B.intTo   = FindMethod(B.cInt, nullptr, { "System.Int32" }, "Int", 1);
    B.intFrom = FindMethod(B.cInt, nullptr, { "Int" }, "System.Int32", 1);
    B.floatTo = FindMethod(B.cFloat, nullptr, { "System.Single" }, "Float", 1);

    B.findOne    = FindMethod(B.cObject, "FindObjectOfType", { "System.Type", "System.Boolean" }, nullptr, 1);
    B.findAll    = FindMethod(B.cObject, "FindObjectsOfType", { "System.Type" }, nullptr, 1);
    B.setEnabled = FindMethod(B.cBehaviour, "set_enabled", { "System.Boolean" }, nullptr, 0);
    if (B.cCursor)
    {
        B.getLock    = FindMethod(B.cCursor, "get_lockState", {}, nullptr, 1);
        B.setLock    = FindMethod(B.cCursor, "set_lockState", { "*" }, nullptr, 1);
        B.setVisible = FindMethod(B.cCursor, "set_visible", { "System.Boolean" }, nullptr, 1);
    }
    B.rmUpdate = FindMethod(B.cRuntimeMgr, "Update", {}, "System.Void", 0);

    il2cpp_runtime_class_init(B.cController);
    il2cpp_runtime_class_init(B.cPolygon);

    B.fCountEnemy    = FindField(B.cController, "_countEnemy");
    B.fCountEnemyMax = FindField(B.cController, "_countEnemyMax");
    B.fPolygonObj    = FindField(B.cPolygon, "_obj");
    B.fMoneyHeadS    = FindField(B.cPolygon, "MoneyKill_Head");
    B.fMoneyBodyS    = FindField(B.cPolygon, "MoneyKill_Body");

    B.oWallHack  = FieldOffset(B.cEnemy, "WallHack");
    B.oHealth    = FieldOffset(B.cEnemy, "_health");
    B.oHealthAll = FieldOffset(B.cEnemy, "_healthAll");
    B.oMoneyHead = FieldOffset(B.cPolygon, "_moneyKill_Head");
    B.oMoneyBody = FieldOffset(B.cPolygon, "_moneyKill_Body");

    B.oControl   = FieldOffset(B.cPlayer, "m_controllPlayer");
    B.oWalk      = FieldOffset(B.cPlayer, "m_WalkSpeed");
    B.oAccel     = FieldOffset(B.cPlayer, "m_AccelSpeed");
    B.oAccelMax  = FieldOffset(B.cPlayer, "m_AccelSpeedMax");
    B.oJump      = FieldOffset(B.cPlayer, "m_JumpSpeed");
    B.oWalkF     = FieldOffset(B.cPlayer, "m_walkSpeed");
    B.oAccelF    = FieldOffset(B.cPlayer, "m_accelSpeed");
    B.oAccelMaxF = FieldOffset(B.cPlayer, "m_accelSpeedMax");
    B.oJumpF     = FieldOffset(B.cPlayer, "m_jumpSpeed");

    B.typePlayer = TypeObject(B.cPlayer);
    B.typeEnemy  = TypeObject(B.cEnemy);


    B.cComponent = FindClass("UnityEngine", "Component");
    B.cTransform = FindClass("UnityEngine", "Transform");
    B.cOutline   = FindClass("", "Outline");
    B.cAchCtl    = FindClass("", "AchiveController");
    B.cAchive    = FindClass("", "Achive");
    B.cItemShop  = FindClass("", "ItemShop");

    B.cGameObject = FindClass("UnityEngine", "GameObject");
    if (B.cComponent)  B.getGO = FindMethod(B.cComponent, "get_gameObject", {}, nullptr, 0);
    if (B.cGameObject) B.goSetActive = FindMethod(B.cGameObject, "SetActive", { "System.Boolean" }, nullptr, 0);
    B.objDestroy = FindMethod(B.cObject, "Destroy", { "UnityEngine.Object" }, nullptr, 1);
    Log("bind4: getGO=%p setActive=%p destroy=%p", B.getGO, B.goSetActive, B.objDestroy);
    B.cCollider = FindClass("UnityEngine", "Collider");
    if (B.cComponent) B.getGO = FindMethod(B.cComponent, "get_gameObject", {}, nullptr, 0);
    B.destroyObj = FindMethod(B.cObject, "Destroy", { "UnityEngine.Object" }, nullptr, 1);
    if (B.cTransform) B.setPos = FindMethod(B.cTransform, "set_position", { "UnityEngine.Vector3" }, nullptr, 0);
    if (B.cCollider) B.setColEnabled = FindMethod(B.cCollider, "set_enabled", { "System.Boolean" }, nullptr, 0);
    B.fExpHeadS = FindField(B.cPolygon, "ExpKill_Head");
    B.fExpBodyS = FindField(B.cPolygon, "ExpKill_Body");
    B.oExpHead  = FieldOffset(B.cPolygon, "_expKill_Head");
    B.oExpBody  = FieldOffset(B.cPolygon, "_expKill_Body");
    B.oCharCtl  = FieldOffset(B.cPlayer, "m_CharacterController");
    Log("bind4: getGO=%p destroy=%p setPos=%p colEnabled=%p exp@%d/%d charCtl@%d", B.getGO, B.destroyObj,
        B.setPos, B.setColEnabled, B.oExpHead, B.oExpBody, B.oCharCtl);
    B.cGameObject = FindClass("UnityEngine", "GameObject");
    if (B.cGameObject) B.goGetTransform = FindMethod(B.cGameObject, "get_transform", {}, nullptr, 0);
    B.instantiate = FindMethod(B.cObject, "Instantiate", { "UnityEngine.Object", "UnityEngine.Vector3", "UnityEngine.Quaternion" }, nullptr, 1);
    B.fPolyEnemy = FindField(B.cPolygon, "_enemy");
    B.oEnemy2Prefab = FieldOffset(B.cPolygon, "Enemy2Prefab");
    B.oSpawners = FieldOffset(B.cPolygon, "SpawnersEnemy");
    Log("bind5: goTransform=%p instantiate=%p polyEnemy=%p enemy2@%d spawners@%d", B.goGetTransform, B.instantiate,
        B.fPolyEnemy, B.oEnemy2Prefab, B.oSpawners);
    B.cCamera = FindClass("UnityEngine", "Camera");
    B.cScreen = FindClass("UnityEngine", "Screen");
    if (B.cCamera) B.w2s = FindMethod(B.cCamera, "WorldToScreenPoint", { "UnityEngine.Vector3" }, nullptr, 0);
    if (B.cScreen) { B.scrW = FindMethod(B.cScreen, "get_width", {}, nullptr, 1); B.scrH = FindMethod(B.cScreen, "get_height", {}, nullptr, 1); }
    Log("bind3: camera=%p w2s=%p screen=%p w=%p h=%p", B.cCamera, B.w2s, B.cScreen, B.scrW, B.scrH);

    B.floatFrom = FindMethod(B.cFloat, nullptr, { "Float" }, "System.Single", 1);
    if (B.cComponent) B.getTransform = FindMethod(B.cComponent, "get_transform", {}, nullptr, 0);
    if (B.cTransform) B.getPos = FindMethod(B.cTransform, "get_position", {}, nullptr, 0);
    if (B.cOutline)
    {
        B.olMode  = FindMethod(B.cOutline, "set_OutlineMode", { "*" }, nullptr, 0);
        B.olWidth = FindMethod(B.cOutline, "set_OutlineWidth", { "System.Single" }, nullptr, 0);
        B.olColor = FindMethod(B.cOutline, "set_OutlineColor", { "*" }, nullptr, 0);
    }
    B.ppSetInt    = FindMethod(B.cPlayerPrefs, "SetInt", { "System.String", "System.Int32" }, nullptr, 1);
    B.ppSetStr    = FindMethod(B.cPlayerPrefs, "SetString", { "System.String", "System.String" }, nullptr, 1);
    B.ppDeleteAll = FindMethod(B.cPlayerPrefs, "DeleteAll", {}, nullptr, 1);

    B.oNewWalkF  = FieldOffset(B.cPlayer, "m_newWalkSpeed");
    B.oOldWalkF  = FieldOffset(B.cPlayer, "m_oldWalkSpeed");
    B.oCamera    = FieldOffset(B.cPlayer, "Camera");
    B.oCharRot   = FieldOffset(B.cPlayer, "m_CharacterTargetRot");
    B.oCamRot    = FieldOffset(B.cPlayer, "m_CameraTargetRot");
    B.oMinX      = FieldOffset(B.cPlayer, "MinimumX");
    B.oMaxX      = FieldOffset(B.cPlayer, "MaximumX");
    B.oClampV    = FieldOffset(B.cPlayer, "clampVerticalRotation");
    B.oJumpPeremes = FieldOffset(B.cPlayer, "m_JumpPeremes");

    if (B.cAchCtl)
    {
        B.fAchObj  = FindField(B.cAchCtl, "_obj");
        B.oAchives = FieldOffset(B.cAchCtl, "Achives");
    }
    if (B.cAchive)
    {
        B.oAchCountMain = FieldOffset(B.cAchive, "_countMain");
        B.oAchNumber    = FieldOffset(B.cAchive, "_numberAchive");
        B.oAchFinish    = FieldOffset(B.cAchive, "_numberFinish");
        B.oAchLevel     = FieldOffset(B.cAchive, "_levelAchive");
    }
    B.fInvObj = FindField(B.cInventory, "_obj");
    B.oAllItems = FieldOffset(B.cInventory, "AllItems");
    if (B.cItemShop) B.oItemNumber = FieldOffset(B.cItemShop, "_numberItem");
    Log("bind2: outline=%p(m=%p w=%p c=%p) pos=%p tr=%p cam@%d charRot@%d camRot@%d jumpFlag@%d ach=%p/%p items@%d",
        B.cOutline, B.olMode, B.olWidth, B.olColor, B.getPos, B.getTransform, B.oCamera, B.oCharRot,
        B.oCamRot, B.oJumpPeremes, B.cAchCtl, B.cAchive, B.oAllItems);

    Log("bind: prefGet=%p prefSet=%p save=%p loadMoney=%p intTo=%p intFrom=%p floatTo=%p findOne=%p findAll=%p "
        "setEnabled=%p rmUpdate=%p", B.prefGet, B.prefSet, B.prefsSave, B.loadMoney, B.intTo, B.intFrom,
        B.floatTo, B.findOne, B.findAll, B.setEnabled, B.rmUpdate);
    Log("bind: countEnemy=%p countEnemyMax=%p polygonObj=%p wallHack@%d health@%d control@%d walk@%d walkF@%d",
        B.fCountEnemy, B.fCountEnemyMax, B.fPolygonObj, B.oWallHack, B.oHealth, B.oControl, B.oWalk, B.oWalkF);

    if (!B.prefGet || !B.prefSet || !B.intTo || !B.intFrom || !B.findOne || !B.findAll ||
        !B.setEnabled || !B.rmUpdate)
    {
        Log("BindAll: не найден критичный метод");
        return false;
    }

    // проверка кодирования Int: должно вернуть то же число
    uint8_t t[8];
    EncodeInt(12345, t);
    int back = DecodeInt(t);
    Log("Int roundtrip: %d (ожидалось 12345)", back);
    if (back != 12345) return false;

    B.ok = true;
    return true;
}

// ----------------------------------------------------------------------------------------
// действия (главный поток)
// ----------------------------------------------------------------------------------------
static void PrefsSaveNow() { if (B.prefsSave) Invoke(B.prefsSave, nullptr, nullptr); }

static void DoGoldSet(long long v)
{
    if (!B.prefGet || !B.prefSet) { SetStatus("PlayerPrefsSafe не найден"); return; }
    v = std::max(0ll, std::min<long long>(v, 2147483647ll));
    PrefSet("GoldCount", (int)v);
    PrefsSaveNow();
    if (B.loadMoney) Invoke(B.loadMoney, nullptr, nullptr);
    std::lock_guard<std::mutex> l(g_mx);
    g_snap.gold = v;
    g_snap.status = "Установлено: " + std::to_string(v);
}

static void DoGoldRead()
{
    if (!B.prefGet) return;
    int cur = PrefGet("GoldCount", 0);
    std::lock_guard<std::mutex> l(g_mx);
    g_snap.gold = cur;
    g_snap.status = "Сейчас: " + std::to_string(cur);
}

static bool g_rewardOn = false;
static int  g_rewardMoney = 0, g_rewardExp = 0;

// пишет значения во все места, где игра может их читать; возвращает, сколько мест нашлось
static int ApplyReward(void* obj, int money, int exp)
{
    int hit = 0;
    if (obj)
    {
        if (B.oMoneyHead >= 0) { At<int>(obj, B.oMoneyHead) = money; hit++; }
        if (B.oMoneyBody >= 0) { At<int>(obj, B.oMoneyBody) = money; hit++; }
        if (B.oExpHead >= 0)   { At<int>(obj, B.oExpHead) = exp; hit++; }
        if (B.oExpBody >= 0)   { At<int>(obj, B.oExpBody) = exp; hit++; }
    }
    if (B.fMoneyHeadS) { StaticIntSet(B.fMoneyHeadS, money); hit++; }
    if (B.fMoneyBodyS) { StaticIntSet(B.fMoneyBodyS, money); hit++; }
    if (B.fExpHeadS)   { StaticIntSet(B.fExpHeadS, exp); hit++; }
    if (B.fExpBodyS)   { StaticIntSet(B.fExpBodyS, exp); hit++; }
    return hit;
}

static void DoKillReward(int money, int exp)
{
    void* obj = nullptr;
    if (B.fPolygonObj) il2cpp_field_static_get_value(B.fPolygonObj, &obj);
    g_rewardMoney = money; g_rewardExp = exp; g_rewardOn = true;
    int hit = ApplyReward(obj, money, exp);
    Log("reward: obj=%p hit=%d (fields: money@%d/%d exp@%d/%d static: %p %p %p %p)", obj, hit,
        B.oMoneyHead, B.oMoneyBody, B.oExpHead, B.oExpBody,
        B.fMoneyHeadS, B.fMoneyBodyS, B.fExpHeadS, B.fExpBodyS);
    if (hit == 0) { SetStatus("Поля награды не найдены — игра обновилась, пришли GoldMod.log и новый dump.cs"); return; }
    SetStatus("Награда держится: голда " + std::to_string(money) + ", опыт " + std::to_string(exp) +
              (obj ? "" : "  (режим полигона не запущен — применится при старте)"));
}

static void RewardTick()
{
    if (!g_rewardOn) return;
    void* obj = nullptr;
    if (B.fPolygonObj) il2cpp_field_static_get_value(B.fPolygonObj, &obj);
    ApplyReward(obj, g_rewardMoney, g_rewardExp);
}

// ---- Unity helpers ----
static bool GetPos(void* comp, float out[3])
{
    if (!comp || !B.getTransform || !B.getPos) return false;
    Object* t = Invoke(B.getTransform, comp, nullptr);
    if (!t) return false;
    Object* p = Invoke(B.getPos, t, nullptr);
    if (!p) return false;
    std::memcpy(out, il2cpp_object_unbox(p), 12);
    return true;
}

static bool IsAlive(void* en)
{
    void* boss = nullptr;
    if (B.fPolyEnemy) il2cpp_field_static_get_value(B.fPolyEnemy, &boss);
    if (en == boss) return true;                       // у босса здоровье может храниться отдельно
    return B.oHealth < 0 || At<int>(en, B.oHealth) > 0;
}

// ---- игрок ----
struct PF { int plain, prot; float base; uint8_t enc[8]; float lastV; bool encOk; };
static PF pfWalk{}, pfNewWalk{}, pfOldWalk{}, pfAccel{}, pfAccelMax{}, pfJump{};
static void* g_player = nullptr;
static bool  g_speedApplied = false, g_jumpApplied = false;

static void SetupPF()
{
    pfWalk    = { B.oWalk,    B.oWalkF,    0, {}, 0, false };
    pfNewWalk = { -1,         B.oNewWalkF, 0, {}, 0, false };
    pfOldWalk = { -1,         B.oOldWalkF, 0, {}, 0, false };
    pfAccel   = { B.oAccel,   B.oAccelF,   0, {}, 0, false };
    pfAccelMax= { B.oAccelMax,B.oAccelMaxF,0, {}, 0, false };
    pfJump    = { B.oJump,    B.oJumpF,    0, {}, 0, false };
}

static void CapturePF(PF& p)
{
    p.encOk = false;
    if (p.plain >= 0) p.base = At<float>(g_player, p.plain);
    else if (p.prot >= 0) p.base = DecodeFloat((uint8_t*)g_player + p.prot, 0.f);
}

static void ApplyPF(PF& p, float mul)
{
    float v = p.base * mul;
    if (p.plain >= 0) At<float>(g_player, p.plain) = v;
    if (p.prot >= 0 && B.floatTo)
    {
        if (!p.encOk || p.lastV != v) { EncodeFloat(v, p.enc); p.lastV = v; p.encOk = true; }
        std::memcpy((char*)g_player + p.prot, p.enc, 8);
    }
}

static void RefreshPlayer()
{
    void* np = FindOne(B.typePlayer);
    if (np != g_player)
    {
        g_player = np;
        g_speedApplied = g_jumpApplied = false;
        if (g_player)
        {
            CapturePF(pfWalk); CapturePF(pfNewWalk); CapturePF(pfOldWalk);
            CapturePF(pfAccel); CapturePF(pfAccelMax); CapturePF(pfJump);
            Log("player %p: walk=%.2f jump=%.2f accel=%.2f", g_player, pfWalk.base, pfJump.base, pfAccel.base);
        }
    }
    std::lock_guard<std::mutex> l(g_mx);
    g_snap.playerFound = g_player != nullptr;
}

static void DoRestorePlayer()
{
    if (!g_player) return;
    ApplyPF(pfWalk, 1); ApplyPF(pfNewWalk, 1); ApplyPF(pfOldWalk, 1); ApplyPF(pfAccel, 1); ApplyPF(pfAccelMax, 1);
    ApplyPF(pfJump, 1);
    g_speedApplied = g_jumpApplied = false;
}

static void PlayerTick(bool menuOpen)
{
    if (!g_player) return;

    if (S.speedOn)
    {
        float m = S.speedMul;
        ApplyPF(pfWalk, m); ApplyPF(pfNewWalk, m); ApplyPF(pfOldWalk, m);
        ApplyPF(pfAccel, m); ApplyPF(pfAccelMax, m);
        g_speedApplied = true;
    }
    else if (g_speedApplied)
    {
        ApplyPF(pfWalk, 1); ApplyPF(pfNewWalk, 1); ApplyPF(pfOldWalk, 1); ApplyPF(pfAccel, 1); ApplyPF(pfAccelMax, 1);
        g_speedApplied = false;
    }

    if (S.jumpOn) { ApplyPF(pfJump, S.jumpMul); g_jumpApplied = true; }
    else if (g_jumpApplied) { ApplyPF(pfJump, 1); g_jumpApplied = false; }

    // бхоп: пока зажат пробел — каждый кадр просим прыжок (игра сама проверяет, на земле ли мы)
    if (S.bhop && !menuOpen && B.oJumpPeremes >= 0 && (GetAsyncKeyState(VK_SPACE) & 0x8000))
        At<bool>(g_player, B.oJumpPeremes) = true;
}

// ---- враги: кэш ----
static std::mutex g_espMx;
static std::vector<EspBox> g_esp;
static int g_lastEspMode = -1;
static std::vector<void*> g_enemies;
static std::unordered_set<void*> g_whInit;

static void RefreshEnemies()
{
    g_enemies.clear();
    void* arr = FindAll(B.typeEnemy);
    int n = ArrayLen(arr);
    for (int i = 0; i < n; i++)
    {
        void* en = ArrayAt(arr, i);
        if (en) g_enemies.push_back(en);
    }
    if (g_whInit.size() > 1024) g_whInit.clear();
    std::lock_guard<std::mutex> l(g_mx);
    g_snap.enemies = n;
}

static void DoWallhackOff()
{
    { std::lock_guard<std::mutex> l(g_espMx); g_esp.clear(); }
    g_lastEspMode = -1;
    RefreshEnemies();
    for (void* en : g_enemies)
        if (B.oWallHack >= 0) SetEnabled(At<void*>(en, B.oWallHack), false);
    g_whInit.clear();
}

static bool W2S(void* cam, const float w[3], int sw, int sh, float out[2])
{
    if (!cam || !B.w2s) return false;
    float v[3] = { w[0], w[1], w[2] };
    void* a[1] = { v };
    Object* r = Invoke(B.w2s, cam, a);
    if (!r) return false;
    float* o = (float*)il2cpp_object_unbox(r);
    if (o[2] <= 0.05f) return false;          // позади камеры
    out[0] = o[0];
    out[1] = (float)sh - o[1];                // Unity: y снизу
    (void)sw;
    return true;
}

static void EspTick()
{
    std::vector<EspBox> out;
    void* cam = (g_player && B.oCamera >= 0) ? At<void*>(g_player, B.oCamera) : nullptr;
    int sw = B.scrW ? UnboxAs<int>(Invoke(B.scrW, nullptr, nullptr), 0) : 0;
    int sh = B.scrH ? UnboxAs<int>(Invoke(B.scrH, nullptr, nullptr), 0) : 0;
    if (cam && sw > 0 && sh > 0)
    {
        float H = S.enemyHeight;
        for (void* en : g_enemies)
        {
            if (!IsAlive(en)) continue;
            int hp = (B.oHealth >= 0) ? At<int>(en, B.oHealth) : 1;
            float t[3];
            if (!GetPos(en, t)) continue;
            float top[3] = { t[0], t[1] + H, t[2] };
            float f2[2], t2[2];
            if (!W2S(cam, t, sw, sh, f2) || !W2S(cam, top, sw, sh, t2)) continue;
            float h = f2[1] - t2[1];
            if (h < 4.f || h > sh * 3.f) continue;
            float w = h * 0.5f;
            float hf = 1.0f;
            if (B.oHealth >= 0) {
                float all = (B.oHealthAll >= 0) ? At<float>(en, B.oHealthAll) : 0.f;
                if (all > 1.f) hf = std::max(0.f, std::min(1.f, hp / all));
            }
            out.push_back({ f2[0] - w * 0.5f, t2[1], w, h, hf });
        }
    }
    std::lock_guard<std::mutex> l(g_espMx);
    g_esp.swap(out);
}

std::vector<EspBox> Esp() { std::lock_guard<std::mutex> l(g_espMx); return g_esp; }
bool EspWanted() { int m = S.espMode; return S.wallhack && (m == 1 || m == 2); }

static void WallhackTick()
{
    int mode = S.espMode;
    bool chams = (mode == 0 || mode == 2);
    if (B.oWallHack >= 0 && g_lastEspMode != mode)
    {
        if (!chams)   // переключились на боксы — гасим контуры
            for (void* en : g_enemies) SetEnabled(At<void*>(en, B.oWallHack), false);
        g_lastEspMode = mode;
    }
    if (chams && B.oWallHack >= 0)
    {
        for (void* en : g_enemies)
        {
            void* ol = At<void*>(en, B.oWallHack);
            if (!ol) continue;
            if (g_whInit.insert(ol).second)
            {
                if (B.olMode)  { int m = 0; void* a[1] = { &m }; Invoke(B.olMode, ol, a); }
                if (B.olWidth) { float w = 4.0f; void* a[1] = { &w }; Invoke(B.olWidth, ol, a); }
                if (B.olColor) { float c[4] = { 1.f, 0.15f, 0.15f, 1.f }; void* a[1] = { c }; Invoke(B.olColor, ol, a); }
            }
            SetEnabled(ol, true);
        }
    }
    if (mode == 1 || mode == 2) EspTick();
    else { std::lock_guard<std::mutex> l(g_espMx); g_esp.clear(); }
}

// ---- убрать всех ботов ----
static int RemoveBots()
{
    if (!B.getGO) return 0;
    RefreshEnemies();
    int n = 0;
    for (void* en : g_enemies)
    {
        Object* go = Invoke(B.getGO, en, nullptr);
        if (!go) continue;
        if (B.objDestroy) { void* a[1] = { go }; Invoke(B.objDestroy, nullptr, a); n++; }
        else if (B.goSetActive) { bool off = false; void* a[1] = { &off }; Invoke(B.goSetActive, go, a); n++; }
    }
    g_enemies.clear();
    { std::lock_guard<std::mutex> l(g_espMx); g_esp.clear(); }
    if (B.fCountEnemy)
    {
        uint8_t zero[8]; EncodeInt(0, zero);
        il2cpp_field_static_set_value(B.fCountEnemy, zero);
    }
    return n;
}

static void DoRemoveBots()
{
    int n = RemoveBots();
    SetStatus("Ботов убрано: " + std::to_string(n));
}

// ---- убрать ботов / телепорт ----
static void DoKillAllBots()
{
    RefreshEnemies();
    int n = 0;
    for (void* en : g_enemies)
    {
        if (B.oHealth >= 0) At<int>(en, B.oHealth) = 0;
        if (B.getGO && B.destroyObj)
        {
            Object* go = Invoke(B.getGO, en, nullptr);
            if (go) { void* a[1] = { go }; Invoke(B.destroyObj, nullptr, a); n++; }
        }
    }
    if (B.fCountEnemy) { uint8_t z[8]; EncodeInt(0, z); il2cpp_field_static_set_value(B.fCountEnemy, z); }
    g_enemies.clear(); g_whInit.clear();
    { std::lock_guard<std::mutex> l(g_espMx); g_esp.clear(); }
    SetStatus("Ботов убрано: " + std::to_string(n));
}

static void DoTeleportToBot()
{
    if (!g_player) RefreshPlayer();
    if (!g_player || !B.getTransform || !B.setPos) { SetStatus("Игрок не найден (зайди в игровую сцену)"); return; }
    RefreshEnemies();
    std::vector<void*> alive;
    for (void* en : g_enemies)
        if (IsAlive(en)) alive.push_back(en);
    if (alive.empty()) { SetStatus("Ботов на карте нет"); return; }

    void* en = alive[rand() % alive.size()];
    float e[3], p[3];
    if (!GetPos(en, e) || !GetPos(g_player, p)) { SetStatus("Не удалось получить позицию"); return; }

    // встаём в 2 м от бота со стороны, откуда пришли
    float dx = p[0] - e[0], dz = p[2] - e[2];
    float len = std::sqrt(dx * dx + dz * dz);
    if (len < 0.01f) { dx = 1; dz = 0; len = 1; }
    float dest[3] = { e[0] + dx / len * 2.0f, e[1] + 0.2f, e[2] + dz / len * 2.0f };

    Object* tr = Invoke(B.getTransform, g_player, nullptr);
    if (!tr) { SetStatus("Transform не найден"); return; }
    void* cc = (B.oCharCtl >= 0) ? At<void*>(g_player, B.oCharCtl) : nullptr;
    if (cc && B.setColEnabled) { bool f = false; void* a[1] = { &f }; Invoke(B.setColEnabled, cc, a); }   // CharacterController перебивает позицию
    void* a[1] = { dest };
    Invoke(B.setPos, tr, a);
    if (cc && B.setColEnabled) { bool t = true; void* b2[1] = { &t }; Invoke(B.setColEnabled, cc, b2); }
    SetStatus("Телепорт к боту (из " + std::to_string((int)alive.size()) + ")");
}

// ---- босс (Enemy2Prefab полигона) ----
static void DoSpawnBoss()
{
    void* poly = nullptr;
    if (B.fPolygonObj) il2cpp_field_static_get_value(B.fPolygonObj, &poly);
    if (!poly) { SetStatus("Босс: нужен режим полигона (запусти игру на полигоне)"); return; }
    void* prefab = (B.oEnemy2Prefab >= 0) ? At<void*>(poly, B.oEnemy2Prefab) : nullptr;
    if (!prefab || !B.instantiate) { SetStatus("Босс: префаб не найден (см. GoldMod.log, строка bind5)"); return; }

    // точка спавна: случайный спавнер полигона, иначе рядом с игроком
    float pos[3] = { 0, 0, 0 };
    bool havePos = false;
    void* arr = (B.oSpawners >= 0) ? At<void*>(poly, B.oSpawners) : nullptr;
    int n = ArrayLen(arr);
    if (n > 0 && B.goGetTransform && B.getPos)
    {
        void* sp = ArrayAt(arr, rand() % n);
        Object* tr = sp ? Invoke(B.goGetTransform, sp, nullptr) : nullptr;
        Object* pv = tr ? Invoke(B.getPos, tr, nullptr) : nullptr;
        if (pv) { std::memcpy(pos, il2cpp_object_unbox(pv), 12); havePos = true; }
    }
    if (!havePos)
    {
        if (!g_player) RefreshPlayer();
        float p[3];
        if (!g_player || !GetPos(g_player, p)) { SetStatus("Босс: не удалось определить место спавна"); return; }
        pos[0] = p[0] + 6.f; pos[1] = p[1]; pos[2] = p[2];
    }
    float rot[4] = { 0, 0, 0, 1 };
    void* a[3] = { prefab, pos, rot };
    Object* obj = Invoke(B.instantiate, nullptr, a);
    Log("boss spawn: prefab=%p pos=%.1f,%.1f,%.1f -> %p", prefab, pos[0], pos[1], pos[2], obj);
    if (!obj) { SetStatus("Босс: Instantiate не удался"); return; }
    SetStatus("Босс вызван");
}

// ---- аим ----
static const float kRad2Deg = 57.2957795f, kDeg2Rad = 0.0174532925f;
static float WrapDeg(float a) { while (a > 180.f) a -= 360.f; while (a < -180.f) a += 360.f; return a; }

static void AimTick()
{
    if (!g_player || B.oCamera < 0 || B.oCharRot < 0 || B.oCamRot < 0 || B.oHealth < 0) return;
    if (!S.aimAlways && !(GetAsyncKeyState(VK_RBUTTON) & 0x8000)) return;

    void* cam = At<void*>(g_player, B.oCamera);
    float p[3];
    if (!GetPos(cam, p)) return;

    float* qc = (float*)((char*)g_player + B.oCharRot);   // x y z w
    float* qp = (float*)((char*)g_player + B.oCamRot);
    float yawCur   = 2.f * std::atan2(qc[1], qc[3]) * kRad2Deg;
    float pitchCur = 2.f * std::atan2(qp[0], qp[3]) * kRad2Deg;

    float bestScore = 1e9f, bestDy = 0, bestDp = 0;
    bool found = false;
    float fov = S.aimFov;
    static const float kPart[3] = { 0.92f, 0.60f, 0.12f };   // голова / тело / ноги (доля высоты)
    int part = S.aimPart; if (part < 0 || part > 2) part = 0;
    float hgt = kPart[part] * (float)S.enemyHeight;
    for (void* en : g_enemies)
    {
        if (!IsAlive(en)) continue;
        float t[3];
        if (!GetPos(en, t)) continue;
        float dx = t[0] - p[0], dy = t[1] + hgt - p[1], dz = t[2] - p[2];
        float hd = std::sqrt(dx * dx + dz * dz), len = std::sqrt(hd * hd + dy * dy);
        if (len < 0.2f) continue;
        float yawT = std::atan2(dx, dz) * kRad2Deg;
        float pitchT = -std::atan2(dy, hd) * kRad2Deg;     // в Unity +X = вниз
        float dY = WrapDeg(yawT - yawCur), dP = pitchT - pitchCur;
        float score = std::sqrt(dY * dY + dP * dP);
        if (score > fov || score >= bestScore) continue;
        bestScore = score; bestDy = dY; bestDp = dP; found = true;
    }
    if (!found) return;

    float s = std::max(0.02f, std::min(1.0f, (float)S.aimSmooth));
    float yaw = yawCur + bestDy * s, pitch = pitchCur + bestDp * s;
    float mn = -89.f, mx = 89.f;
    if (B.oClampV >= 0 && At<bool>(g_player, B.oClampV) && B.oMinX >= 0 && B.oMaxX >= 0)
    { mn = At<float>(g_player, B.oMinX); mx = At<float>(g_player, B.oMaxX); }
    pitch = std::max(mn, std::min(mx, pitch));

    qc[0] = 0; qc[1] = std::sin(yaw * kDeg2Rad * 0.5f); qc[2] = 0; qc[3] = std::cos(yaw * kDeg2Rad * 0.5f);
    qp[0] = std::sin(pitch * kDeg2Rad * 0.5f); qp[1] = 0; qp[2] = 0; qp[3] = std::cos(pitch * kDeg2Rad * 0.5f);
}

// ---- достижения ----
static void DoUnlockAchievements()
{
    void* ctl = nullptr;
    if (B.fAchObj) il2cpp_field_static_get_value(B.fAchObj, &ctl);
    if (!ctl || B.oAchives < 0) { SetStatus("Открой экран достижений в игре и нажми ещё раз"); return; }
    void* arr = At<void*>(ctl, B.oAchives);
    int n = ArrayLen(arr), done = 0;
    for (int i = 0; i < n; i++)
    {
        void* a = ArrayAt(arr, i);
        if (!a) continue;
        void* counts = (B.oAchCountMain >= 0) ? At<void*>(a, B.oAchCountMain) : nullptr;
        int levels = ArrayLen(counts);
        if (levels <= 0) continue;
        int last = *(int*)((char*)counts + 16 + 4 * (levels - 1));
        int num = (B.oAchNumber >= 0) ? At<int>(a, B.oAchNumber) : i;
        if (B.oAchFinish >= 0) At<int>(a, B.oAchFinish) = last;
        if (B.oAchLevel >= 0)  At<int>(a, B.oAchLevel)  = levels - 1;
        PrefSet(("AchiveSaveLevel_" + std::to_string(num)).c_str(), levels - 1);
        Log("achive #%d (idx %d): levels=%d last=%d", num, i, levels, last);
        done++;
    }
    PrefsSaveNow();
    SetStatus("Достижения: обработано " + std::to_string(done) + ". Перезайди в экран достижений (см. GoldMod.log).");
}

// ---- все предметы ----
static void DoGiveAllItems()
{
    void* inv = nullptr;
    if (B.fInvObj) il2cpp_field_static_get_value(B.fInvObj, &inv);
    if (!inv || B.oAllItems < 0 || B.oItemNumber < 0) { SetStatus("Открой инвентарь в меню игры и нажми ещё раз"); return; }
    void* arr = At<void*>(inv, B.oAllItems);
    int n = ArrayLen(arr);
    if (n <= 0) { SetStatus("Каталог предметов пуст"); return; }

    std::set<int> have;
    int cnt = PrefGet("ItemSaveCount", 0);
    for (int k = 0; k < cnt; k++) have.insert(PrefGet(("ItemId_" + std::to_string(k)).c_str(), -1));

    int added = 0;
    for (int i = 0; i < n; i++)
    {
        void* it = ArrayAt(arr, i);
        if (!it) continue;
        int id = At<int>(it, B.oItemNumber);
        if (have.count(id)) continue;
        have.insert(id);
        PrefSet(("ItemId_" + std::to_string(cnt)).c_str(), id);
        PrefSet(("ItemIsNewInt_" + std::to_string(cnt)).c_str(), 0);
        cnt++; added++;
    }
    PrefSet("ItemSaveCount", cnt);
    PrefsSaveNow();
    Log("give items: catalog=%d added=%d total=%d", n, added, cnt);
    SetStatus("Предметов добавлено: " + std::to_string(added) + " (всего " + std::to_string(cnt) + "). Перезайди в игру.");
}

// ---- ключ ----
static void DoWriteKey(std::string key, std::string value, int type)
{
    if (key.empty()) { SetStatus("Пустой ключ"); return; }
    if (type == 2)
    {
        if (!B.ppSetStr) { SetStatus("PlayerPrefs.SetString не найден"); return; }
        void* a[2] = { il2cpp_string_new(key.c_str()), il2cpp_string_new(value.c_str()) };
        Invoke(B.ppSetStr, nullptr, a);
    }
    else
    {
        long long v = std::max(-2147483648ll, std::min(2147483647ll, _strtoi64(value.c_str(), nullptr, 10)));
        if (type == 0) PrefSet(key.c_str(), (int)v);
        else if (B.ppSetInt) { int iv = (int)v; void* a[2] = { il2cpp_string_new(key.c_str()), &iv }; Invoke(B.ppSetInt, nullptr, a); }
        else { SetStatus("PlayerPrefs.SetInt не найден"); return; }
    }
    PrefsSaveNow();
    if (B.loadMoney) Invoke(B.loadMoney, nullptr, nullptr);
    SetStatus("Записано: " + key + " = " + value);
}

static void DoHardClean()
{
    if (!B.ppDeleteAll) { SetStatus("PlayerPrefs.DeleteAll не найден"); return; }
    Invoke(B.ppDeleteAll, nullptr, nullptr);
    PrefsSaveNow();
    SetStatus("Все сохранения PlayerPrefs удалены. Перезапусти игру.");
}

// ---- меню: курсор + блокировка управления ----
static bool g_menuOpen = false;
static int  g_prevLock = 1;
static bool g_prevControl = true;
static void* g_ctlPlayer = nullptr;

static void SetCursor(int lockState, bool visible)
{
    if (B.setLock)    { void* a[1] = { &lockState }; Invoke(B.setLock, nullptr, a); }
    if (B.setVisible) { void* a[1] = { &visible };   Invoke(B.setVisible, nullptr, a); }
}

static void DoMenuOpen(bool open)
{
    if (open == g_menuOpen) return;
    g_menuOpen = open;
    if (open)
    {
        g_prevLock = B.getLock ? UnboxAs<int>(Invoke(B.getLock, nullptr, nullptr), 1) : 1;
        g_ctlPlayer = (B.oControl >= 0) ? FindOne(B.typePlayer) : nullptr;
        if (g_ctlPlayer && S.lockControls)
        {
            g_prevControl = At<bool>(g_ctlPlayer, B.oControl);
            At<bool>(g_ctlPlayer, B.oControl) = false;
        }
        SetCursor(0, true);
        DoGoldRead();
    }
    else
    {
        if (g_ctlPlayer && S.lockControls) At<bool>(g_ctlPlayer, B.oControl) = g_prevControl;
        g_ctlPlayer = nullptr;
        SetCursor(g_prevLock, g_prevLock == 0);
    }
}

// ---- каждый кадр ----
static uint8_t g_encMax[8];
static bool    g_encMaxInit = false;

static void FrameTick()
{
    std::vector<std::function<void()>> q;
    { std::lock_guard<std::mutex> l(g_qmx); q.swap(g_queue); }
    for (auto& f : q) { try { f(); } catch (...) { Log("exception in command"); } }

    if (g_menuOpen) SetCursor(0, true);

    static ULONGLONG nextPlayer = 0, nextEnemies = 0;
    ULONGLONG now = GetTickCount64();

    static bool f6Prev = false;
    bool f6 = (GetAsyncKeyState(VK_F6) & 0x8000) != 0;
    if (f6 && !f6Prev) DoSpawnBoss();
    f6Prev = f6;

    static ULONGLONG nextReward = 0;
    if (now >= nextReward) { nextReward = now + 200; RewardTick(); }
    if (now >= nextPlayer) { nextPlayer = now + 250; RefreshPlayer(); }
    PlayerTick(g_menuOpen);

    if (S.wallhack || S.aim)
    {
        if (now >= nextEnemies) { nextEnemies = now + 200; RefreshEnemies(); }
        if (S.wallhack) WallhackTick();
        if (S.aim && !g_menuOpen) AimTick();
    }

    if (S.autoKillBots)
    {
        static ULONGLONG nextKill = 0;
        if (now >= nextKill) { nextKill = now + 300; RemoveBots(); }
    }

    if (S.raiseBotMax && B.fCountEnemyMax)
    {
        if (!g_encMaxInit) { EncodeInt(999, g_encMax); g_encMaxInit = true; }
        il2cpp_field_static_set_value(B.fCountEnemyMax, g_encMax);
    }
}

// ----------------------------------------------------------------------------------------
// хук RuntimeManager.Update (singleton FMOD, живёт всю игру, вызывается в главном потоке)
// ----------------------------------------------------------------------------------------
typedef void(__cdecl* UpdateFn)(void* self, void* mi);
static UpdateFn g_origUpdate = nullptr;

static void __cdecl hkUpdate(void* self, void* mi)
{
    g_origUpdate(self, mi);
    static bool inTick = false;
    if (inTick) return;
    inTick = true;
    try { FrameTick(); } catch (...) { Log("exception in FrameTick"); }
    inTick = false;
}

bool Init()
{
    if (!BindAll()) return false;
    SetupPF();

    void* target = MethodPointer(B.rmUpdate);
    if (!target) { Log("RuntimeManager.Update pointer is null"); return false; }

    if (MH_CreateHook(target, (void*)&hkUpdate, (void**)&g_origUpdate) != MH_OK ||
        MH_EnableHook(target) != MH_OK)
    {
        Log("MH hook RuntimeManager.Update failed");
        return false;
    }
    { std::lock_guard<std::mutex> l(g_mx); g_snap.bound = true; g_snap.status = "Готово."; }
    Log("game hooks installed (Update @ %p)", target);
    return true;
}

// ----------------------------------------------------------------------------------------
// команды для UI
// ----------------------------------------------------------------------------------------
void CmdGoldSet(long long v)      { Post([=] { DoGoldSet(v); }); }
void CmdKillReward(int m, int e)  { Post([=] { DoKillReward(m, e); }); }
void CmdKillAllBots()             { Post([] { DoKillAllBots(); }); }
void CmdTeleportToBot()           { Post([] { DoTeleportToBot(); }); }
void CmdSpawnBoss()               { Post([] { DoSpawnBoss(); }); }
void CmdWallhackOff()             { Post([] { DoWallhackOff(); }); }
void CmdRemoveBots()              { Post([] { DoRemoveBots(); }); }
void CmdRestorePlayer()           { Post([] { DoRestorePlayer(); }); }
void CmdMenuOpen(bool open)       { Post([=] { DoMenuOpen(open); }); }
void CmdUnlockAchievements()      { Post([] { DoUnlockAchievements(); }); }
void CmdGiveAllItems()            { Post([] { DoGiveAllItems(); }); }
void CmdWriteKey(const std::string& k, const std::string& v, int t) { Post([=] { DoWriteKey(k, v, t); }); }
void CmdHardClean()               { Post([] { DoHardClean(); }); }

} // namespace game
