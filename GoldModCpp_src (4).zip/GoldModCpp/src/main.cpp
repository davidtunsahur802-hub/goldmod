#include <windows.h>
#include <cstdarg>
#include <cstdio>
#include "common.h"
#include "il2cpp.h"
#include "game.h"
#include "overlay.h"
#include "MinHook.h"

HMODULE g_self = nullptr;

static CRITICAL_SECTION g_logCs;
static char g_logPath[MAX_PATH];

void Log(const char* fmt, ...)
{
    EnterCriticalSection(&g_logCs);
    FILE* f = fopen(g_logPath, "ab");
    if (f)
    {
        SYSTEMTIME t; GetLocalTime(&t);
        fprintf(f, "[%02d:%02d:%02d.%03d] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
        va_list ap; va_start(ap, fmt);
        vfprintf(f, fmt, ap);
        va_end(ap);
        fputc('\n', f);
        fclose(f);
    }
    LeaveCriticalSection(&g_logCs);
}

static DWORD WINAPI InitThread(LPVOID)
{
    Log("GoldMod (C++) started, pid=%lu", GetCurrentProcessId());

    // 1. ждём GameAssembly.dll и инициализацию il2cpp
    for (int i = 0; i < 600 && !GetModuleHandleA("GameAssembly.dll"); i++) Sleep(100);
    if (!il2::Load()) { Log("il2cpp exports not available - abort"); return 1; }

    // 2. ждём, пока домен поднимется и появятся нужные сборки
    bool ready = false;
    for (int i = 0; i < 600; i++)
    {
        if (il2::il2cpp_domain_get() && il2::AttachThread() && il2::FindClass("FMODUnity", "RuntimeManager") &&
            il2::FindClass("", "Controller")) { ready = true; break; }
        Sleep(100);
    }
    if (!ready) { Log("il2cpp domain/classes not ready - abort"); return 1; }

    if (MH_Initialize() != MH_OK) { Log("MH_Initialize failed"); return 1; }

    // 3. привязка к игре + хук главного потока
    if (!game::Init()) { Log("game::Init failed"); return 1; }

    // 4. оверлей
    if (!overlay::Init()) { Log("overlay::Init failed"); return 1; }

    Log("ready. Home = menu");
    return 0;
}

BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        g_self = h;
        DisableThreadLibraryCalls(h);
        InitializeCriticalSection(&g_logCs);
        GetModuleFileNameA(h, g_logPath, MAX_PATH);
        char* slash = strrchr(g_logPath, '\\');
        if (slash) *(slash + 1) = 0;
        strcat(g_logPath, "GoldMod.log");
        CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
    }
    return TRUE;
}
