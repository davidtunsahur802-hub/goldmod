#include "il2cpp.h"
#include "common.h"
#include <cstring>
#include <string>

namespace il2 {

#define X(ret, name, args) ret (*name) args = nullptr;
IL2_FUNCS(X)
#undef X

bool g_lastInvokeFailed = false;

bool Load()
{
    HMODULE ga = GetModuleHandleA("GameAssembly.dll");
    if (!ga) return false;
    bool ok = true;
#define X(ret, name, args) \
    name = reinterpret_cast<ret (*) args>(GetProcAddress(ga, #name)); \
    if (!name) { Log("il2cpp export not found: %s", #name); ok = false; }
    IL2_FUNCS(X)
#undef X
    return ok;
}

bool AttachThread()
{
    if (!il2cpp_domain_get || !il2cpp_thread_attach) return false;
    Domain* d = il2cpp_domain_get();
    if (!d) return false;
    il2cpp_thread_attach(d);
    return true;
}

Klass* FindClass(const char* ns, const char* name)
{
    Domain* d = il2cpp_domain_get();
    if (!d) return nullptr;
    size_t n = 0;
    Assembly** asms = il2cpp_domain_get_assemblies(d, &n);
    for (size_t i = 0; i < n; i++)
    {
        Image* img = il2cpp_assembly_get_image(asms[i]);
        if (!img) continue;
        Klass* k = il2cpp_class_from_name(img, ns, name);
        if (k) return k;
    }
    return nullptr;
}

static bool TypeNameIs(const Type* t, const char* want)
{
    if (!want || (want[0] == '*' && want[1] == 0)) return true;
    char* n = il2cpp_type_get_name(t);
    return n && std::strcmp(n, want) == 0;   // строка маленькая; утечка единичная
}

Method* FindMethod(Klass* k, const char* name, std::initializer_list<const char*> params,
                   const char* ret, int staticMode)
{
    if (!k) return nullptr;
    void* it = nullptr;
    while (Method* m = il2cpp_class_get_methods(k, &it))
    {
        if (name && std::strcmp(il2cpp_method_get_name(m), name) != 0) continue;
        if (il2cpp_method_get_param_count(m) != params.size()) continue;
        uint32_t iflags = 0;
        bool isStatic = (il2cpp_method_get_flags(m, &iflags) & 0x10) != 0;   // METHOD_ATTRIBUTE_STATIC
        if (staticMode == 0 && isStatic) continue;
        if (staticMode == 1 && !isStatic) continue;
        if (ret && !TypeNameIs(il2cpp_method_get_return_type(m), ret)) continue;
        bool match = true;
        uint32_t i = 0;
        for (const char* p : params)
        {
            if (!TypeNameIs(il2cpp_method_get_param(m, i++), p)) { match = false; break; }
        }
        if (match) return m;
    }
    return nullptr;
}

Field* FindField(Klass* k, const char* name)
{
    return k ? il2cpp_class_get_field_from_name(k, name) : nullptr;
}

int FieldOffset(Klass* k, const char* name)
{
    Field* f = FindField(k, name);
    return f ? (int)il2cpp_field_get_offset(f) : -1;
}

void* MethodPointer(Method* m) { return m ? *(void**)m : nullptr; }

Object* Invoke(Method* m, void* obj, void** args)
{
    g_lastInvokeFailed = false;
    if (!m) { g_lastInvokeFailed = true; return nullptr; }
    Object* exc = nullptr;
    Object* r = il2cpp_runtime_invoke(m, obj, args, &exc);
    if (exc)
    {
        g_lastInvokeFailed = true;
        Log("managed exception in %s", il2cpp_method_get_name(m));
        return nullptr;
    }
    return r;
}

Object* TypeObject(Klass* k)
{
    return k ? il2cpp_type_get_object(il2cpp_class_get_type(k)) : nullptr;
}

} // namespace il2
