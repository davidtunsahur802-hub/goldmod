#include "overlay.h"
#include "game.h"
#include "common.h"
#include "MinHook.h"

#include <d3d11.h>
#include <dxgi.h>
#include <d3d9.h>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <string>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_dx9.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace overlay {

static std::atomic<int>  g_api{ 0 };        // 0 — ещё не определён, 1 — D3D11, 2 — D3D9
static std::atomic<bool> g_open{ false };
static bool    g_imguiReady = false;
static HWND    g_hwnd = nullptr;
static WNDPROC g_oldProc = nullptr;

static const int TOGGLE_VK = VK_HOME;

// ----------------------------------------------------------------------------------------
// WndProc: открытие меню + перехват ввода, пока меню открыто
// ----------------------------------------------------------------------------------------
static void SetOpen(bool o)
{
    if (g_open.exchange(o) != o) game::CmdMenuOpen(o);
}

static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l)
{
    if (m == WM_KEYDOWN && w == TOGGLE_VK && !(l & (1 << 30)))
        SetOpen(!g_open);

    if (g_open)
    {
        if (g_imguiReady) ImGui_ImplWin32_WndProcHandler(h, m, w, l);
        switch (m)
        {
        case WM_MOUSEMOVE: case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_LBUTTONDBLCLK:
        case WM_RBUTTONDOWN: case WM_RBUTTONUP: case WM_RBUTTONDBLCLK:
        case WM_MBUTTONDOWN: case WM_MBUTTONUP: case WM_MBUTTONDBLCLK:
        case WM_XBUTTONDOWN: case WM_XBUTTONUP: case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
        case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP: case WM_CHAR:
        case WM_INPUT:
            return DefWindowProcW(h, m, w, l);   // игре не отдаём
        }
    }
    return CallWindowProcW(g_oldProc, h, m, w, l);
}

// ----------------------------------------------------------------------------------------
// ImGui
// ----------------------------------------------------------------------------------------
static void InitImGuiCommon(HWND hwnd)
{
    g_hwnd = hwnd;
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;

    // шрифт с кириллицей (системный)
    const char* fonts[] = { "C:\\Windows\\Fonts\\segoeui.ttf", "C:\\Windows\\Fonts\\arial.ttf",
                            "C:\\Windows\\Fonts\\tahoma.ttf" };
    for (const char* f : fonts)
    {
        if (GetFileAttributesA(f) == INVALID_FILE_ATTRIBUTES) continue;
        if (io.Fonts->AddFontFromFileTTF(f, 16.0f, nullptr, io.Fonts->GetGlyphRangesCyrillic())) break;
    }
    ImGui::StyleColorsDark();
    ImGui::GetStyle().WindowRounding = 6.0f;

    ImGui_ImplWin32_Init(hwnd);
    g_oldProc = (WNDPROC)SetWindowLongPtrW(hwnd, GWLP_WNDPROC, (LONG_PTR)WndProc);
}

// ---- UI ----
struct UiState {
    char amount[16] = "100000";
    int  kill = 1000;
    int  exp = 100;
    char key[64] = "";
    char value[128] = "";
    int  keyType = 0;
    bool confirmClean = false;
} U;

static void DrawEsp()
{
    if (!game::EspWanted()) return;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    for (const game::EspBox& b : game::Esp())
    {
        ImU32 col = IM_COL32(255, 40, 40, 255), sh = IM_COL32(0, 0, 0, 200);
        ImVec2 p1(b.x, b.y), p2(b.x + b.w, b.y + b.h);
        dl->AddRect(ImVec2(p1.x - 1, p1.y - 1), ImVec2(p2.x + 1, p2.y + 1), sh);
        dl->AddRect(p1, p2, col, 0.f, 0, 1.5f);
        // полоска здоровья слева
        float bx = p1.x - 5.f;
        dl->AddRectFilled(ImVec2(bx - 1, p1.y - 1), ImVec2(bx + 2, p2.y + 1), sh);
        float hy = p2.y - b.h * b.hp;
        dl->AddRectFilled(ImVec2(bx, hy), ImVec2(bx + 1, p2.y), IM_COL32(60, 255, 60, 255));
    }
}

static void DrawUI()
{
    game::Snapshot s = game::Snap();

    ImGui::SetNextWindowSize(ImVec2(500, 430), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(40, 40), ImGuiCond_FirstUseEver);
    bool open = true;
    ImGui::Begin("GoldMod  [Home]", &open);

    if (!s.bound) ImGui::TextColored(ImVec4(1, 0.4f, 0.4f, 1), "Привязка к игре не выполнена (см. GoldMod.log)");

    if (ImGui::BeginTabBar("tabs"))
    {
        // ---------------- Валюта ----------------
        if (ImGui::BeginTabItem("Валюта"))
        {
            ImGui::InputText("Количество", U.amount, sizeof(U.amount), ImGuiInputTextFlags_CharsDecimal);
            if (ImGui::Button("Установить")) game::CmdGoldSet(_strtoi64(U.amount, nullptr, 10));
            if (s.gold >= 0) ImGui::Text("Сейчас: %lld", s.gold);

            ImGui::Separator();
            ImGui::TextWrapped("Награда за убийство (режим полигона) — голова и тело:");
            ImGui::InputInt("Голда за килл", &U.kill);
            ImGui::InputInt("Опыт за килл", &U.exp);
            if (ImGui::Button("Применить")) game::CmdKillReward(U.kill, U.exp);
            ImGui::EndTabItem();
        }

        // ---------------- Игрок ----------------
        if (ImGui::BeginTabItem("Игрок"))
        {
            ImGui::Text(s.playerFound ? "PlayerController найден" : "PlayerController не найден (зайди в игровую сцену)");

            bool bh = game::S.bhop;
            if (ImGui::Checkbox("Быстрый бхоп (держи пробел)", &bh)) game::S.bhop = bh;

            bool sp = game::S.speedOn;
            if (ImGui::Checkbox("Ускоренная ходьба", &sp)) { game::S.speedOn = sp; }
            float sm = game::S.speedMul;
            if (ImGui::SliderFloat("Скорость (x)", &sm, 1.0f, 10.0f, "%.1f")) game::S.speedMul = sm;

            bool jp = game::S.jumpOn;
            if (ImGui::Checkbox("Высокий прыжок", &jp)) { game::S.jumpOn = jp; }
            float jm = game::S.jumpMul;
            if (ImGui::SliderFloat("Высота прыжка (x)", &jm, 1.0f, 10.0f, "%.1f")) game::S.jumpMul = jm;
            ImGui::EndTabItem();
        }

        // ---------------- Враги ----------------
        if (ImGui::BeginTabItem("Враги"))
        {
            bool wall = game::S.wallhack;
            if (ImGui::Checkbox("WallHack", &wall))
            {
                game::S.wallhack = wall;
                if (!wall) game::CmdWallhackOff();
            }
            int em = game::S.espMode;
            bool ch = false;
            ch |= ImGui::RadioButton("Чамсы", &em, 0); ImGui::SameLine();
            ch |= ImGui::RadioButton("Боксы", &em, 1); ImGui::SameLine();
            ch |= ImGui::RadioButton("Оба", &em, 2);
            if (ch) game::S.espMode = em;
            ImGui::Text("Врагов на сцене: %d", s.enemies);
            if (ImGui::Button("Вызвать босса (F6)")) game::CmdSpawnBoss();
            ImGui::SameLine();
            if (ImGui::Button("Убрать всех ботов")) game::CmdKillAllBots();
            ImGui::SameLine();
            if (ImGui::Button("Телепорт к случайному боту")) game::CmdTeleportToBot();
            float eh = game::S.enemyHeight;
            if (ImGui::SliderFloat("Высота врага (боксы/аим)", &eh, 0.5f, 4.0f, "%.2f")) game::S.enemyHeight = eh;

            ImGui::Separator();
            bool aim = game::S.aim;
            if (ImGui::Checkbox("Аим", &aim)) game::S.aim = aim;
            int ap = game::S.aimPart;
            bool pc = false;
            pc |= ImGui::RadioButton("Голова", &ap, 0); ImGui::SameLine();
            pc |= ImGui::RadioButton("Тело", &ap, 1); ImGui::SameLine();
            pc |= ImGui::RadioButton("Ноги", &ap, 2);
            if (pc) game::S.aimPart = ap;
            bool al = game::S.aimAlways;
            if (ImGui::Checkbox("Всегда (иначе только пока зажата ПКМ)", &al)) game::S.aimAlways = al;
            float sm = game::S.aimSmooth;
            if (ImGui::SliderFloat("Плавность", &sm, 0.02f, 1.0f, "%.2f")) game::S.aimSmooth = sm;
            float fov = game::S.aimFov;
            if (ImGui::SliderFloat("Угол захвата", &fov, 5.0f, 180.0f, "%.0f")) game::S.aimFov = fov;

            ImGui::Separator();
            if (ImGui::Button("Убрать всех ботов")) game::CmdRemoveBots();
            bool ak = game::S.autoKillBots;
            if (ImGui::Checkbox("Постоянно убирать ботов", &ak)) game::S.autoKillBots = ak;
            bool raise = game::S.raiseBotMax;
            if (ImGui::Checkbox("Снять лимит ботов", &raise)) game::S.raiseBotMax = raise;
            ImGui::EndTabItem();
        }

        // ---------------- Предметы ----------------
        if (ImGui::BeginTabItem("Предметы"))
        {
            ImGui::TextWrapped("Скинченджер: добавить в инвентарь все предметы из каталога игры (открой инвентарь в меню игры).");
            if (ImGui::Button("Выдать все предметы")) game::CmdGiveAllItems();
            ImGui::Separator();
            ImGui::TextWrapped("Достижения (открой экран достижений в игре).");
            if (ImGui::Button("Разблокировать все достижения")) game::CmdUnlockAchievements();
            ImGui::EndTabItem();
        }

        // ---------------- Ключ ----------------
        if (ImGui::BeginTabItem("Ключ"))
        {
            ImGui::InputText("Ключ", U.key, sizeof(U.key));
            ImGui::InputText("Значение", U.value, sizeof(U.value));
            ImGui::RadioButton("Число (защищённое)", &U.keyType, 0); ImGui::SameLine();
            ImGui::RadioButton("Число (обычное)", &U.keyType, 1); ImGui::SameLine();
            ImGui::RadioButton("Текст", &U.keyType, 2);
            if (ImGui::Button("Записать")) game::CmdWriteKey(U.key, U.value, U.keyType);
            ImGui::EndTabItem();
        }

        // ---------------- Опции ----------------
        if (ImGui::BeginTabItem("Опции"))
        {
            bool lk = game::S.lockControls;
            if (ImGui::Checkbox("Блокировать управление, пока меню открыто", &lk)) game::S.lockControls = lk;
            ImGui::TextDisabled("Клавиша меню: Home");

            ImGui::Separator();
            ImGui::TextColored(ImVec4(1, 0.4f, 0.4f, 1), "Жёсткая очистка: удаляет ВСЕ сохранения игры (PlayerPrefs)");
            ImGui::Checkbox("Я понимаю, что прогресс пропадёт", &U.confirmClean);
            if (U.confirmClean && ImGui::Button("Очистить всё"))
            {
                game::CmdHardClean();
                U.confirmClean = false;
            }
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }

    ImGui::Separator();
    ImGui::TextWrapped("%s", s.status.c_str());
    ImGui::End();

    if (!open) SetOpen(false);
}

// ----------------------------------------------------------------------------------------
// D3D11
// ----------------------------------------------------------------------------------------
typedef HRESULT(__stdcall* Present11_t)(IDXGISwapChain*, UINT, UINT);
static Present11_t g_origPresent11 = nullptr;
static ID3D11Device* g_dev11 = nullptr;
static ID3D11DeviceContext* g_ctx11 = nullptr;

static void Render11(IDXGISwapChain* sc)
{
    if (!g_imguiReady)
    {
        if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_dev11)) || !g_dev11) return;
        g_dev11->GetImmediateContext(&g_ctx11);
        DXGI_SWAP_CHAIN_DESC d{};
        sc->GetDesc(&d);
        InitImGuiCommon(d.OutputWindow);
        ImGui_ImplDX11_Init(g_dev11, g_ctx11);
        g_imguiReady = true;
        Log("overlay: D3D11 ready (hwnd=%p)", d.OutputWindow);
    }
    if (!g_open && !game::EspWanted()) return;

    ID3D11Texture2D* bb = nullptr;
    if (FAILED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb)) || !bb) return;
    ID3D11RenderTargetView* rtv = nullptr;
    g_dev11->CreateRenderTargetView(bb, nullptr, &rtv);
    bb->Release();
    if (!rtv) return;

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    DrawEsp();
    if (g_open) DrawUI();
    ImGui::Render();

    // курсор не должен быть зажат окном игры
    if (g_open) ClipCursor(nullptr);

    g_ctx11->OMSetRenderTargets(1, &rtv, nullptr);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    rtv->Release();
}

static HRESULT __stdcall hkPresent11(IDXGISwapChain* sc, UINT sync, UINT flags)
{
    int expected = 0;
    g_api.compare_exchange_strong(expected, 1);
    if (g_api == 1) Render11(sc);
    return g_origPresent11(sc, sync, flags);
}

// ----------------------------------------------------------------------------------------
// D3D9
// ----------------------------------------------------------------------------------------
typedef HRESULT(__stdcall* Present9_t)(IDirect3DDevice9*, const RECT*, const RECT*, HWND, const RGNDATA*);
typedef HRESULT(__stdcall* Reset9_t)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);
static Present9_t g_origPresent9 = nullptr;
static Reset9_t   g_origReset9 = nullptr;

static void Render9(IDirect3DDevice9* dev)
{
    if (!g_imguiReady)
    {
        D3DDEVICE_CREATION_PARAMETERS cp{};
        dev->GetCreationParameters(&cp);
        InitImGuiCommon(cp.hFocusWindow);
        ImGui_ImplDX9_Init(dev);
        g_imguiReady = true;
        Log("overlay: D3D9 ready (hwnd=%p)", cp.hFocusWindow);
    }
    if (!g_open && !game::EspWanted()) return;

    ImGui_ImplDX9_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    DrawEsp();
    if (g_open) DrawUI();
    ImGui::EndFrame();
    ImGui::Render();
    if (g_open) ClipCursor(nullptr);

    if (SUCCEEDED(dev->BeginScene()))
    {
        ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
        dev->EndScene();
    }
}

static HRESULT __stdcall hkPresent9(IDirect3DDevice9* dev, const RECT* a, const RECT* b, HWND c, const RGNDATA* d)
{
    int expected = 0;
    g_api.compare_exchange_strong(expected, 2);
    if (g_api == 2) Render9(dev);
    return g_origPresent9(dev, a, b, c, d);
}

static HRESULT __stdcall hkReset9(IDirect3DDevice9* dev, D3DPRESENT_PARAMETERS* pp)
{
    if (g_api == 2 && g_imguiReady) ImGui_ImplDX9_InvalidateDeviceObjects();
    HRESULT r = g_origReset9(dev, pp);
    if (g_api == 2 && g_imguiReady && SUCCEEDED(r)) ImGui_ImplDX9_CreateDeviceObjects();
    return r;
}

// ----------------------------------------------------------------------------------------
// поиск адресов через временное окно/устройство
// ----------------------------------------------------------------------------------------
static HWND MakeDummyWindow()
{
    WNDCLASSEXW wc{ sizeof(wc) };
    wc.lpfnWndProc = DefWindowProcW;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"GoldModDummy";
    RegisterClassExW(&wc);
    return CreateWindowExW(0, wc.lpszClassName, L"", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100,
                           nullptr, nullptr, wc.hInstance, nullptr);
}

static bool HookD3D11()
{
    HWND w = MakeDummyWindow();
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = w;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    IDXGISwapChain* sc = nullptr; ID3D11Device* dev = nullptr; ID3D11DeviceContext* ctx = nullptr;
    D3D_FEATURE_LEVEL fl;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
                                               D3D11_SDK_VERSION, &sd, &sc, &dev, &fl, &ctx);
    if (FAILED(hr)) { DestroyWindow(w); Log("D3D11 dummy failed: 0x%08lx", hr); return false; }

    void* present = (*(void***)sc)[8];
    sc->Release(); ctx->Release(); dev->Release(); DestroyWindow(w);

    bool ok = MH_CreateHook(present, (void*)&hkPresent11, (void**)&g_origPresent11) == MH_OK &&
              MH_EnableHook(present) == MH_OK;
    Log("D3D11 Present hook @ %p: %s", present, ok ? "ok" : "FAIL");
    return ok;
}

static bool HookD3D9()
{
    typedef IDirect3D9*(WINAPI * Create9_t)(UINT);
    HMODULE m = LoadLibraryA("d3d9.dll");
    if (!m) return false;
    auto create = (Create9_t)GetProcAddress(m, "Direct3DCreate9");
    if (!create) return false;
    IDirect3D9* d3d = create(D3D_SDK_VERSION);
    if (!d3d) return false;

    HWND w = MakeDummyWindow();
    D3DPRESENT_PARAMETERS pp{};
    pp.Windowed = TRUE;
    pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    pp.BackBufferFormat = D3DFMT_UNKNOWN;
    pp.hDeviceWindow = w;
    IDirect3DDevice9* dev = nullptr;
    HRESULT hr = d3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_NULLREF, w,
                                   D3DCREATE_SOFTWARE_VERTEXPROCESSING, &pp, &dev);
    if (FAILED(hr) || !dev) { d3d->Release(); DestroyWindow(w); Log("D3D9 dummy failed: 0x%08lx", hr); return false; }

    void** vt = *(void***)dev;
    void* present = vt[17];
    void* reset = vt[16];
    dev->Release(); d3d->Release(); DestroyWindow(w);

    bool ok = MH_CreateHook(present, (void*)&hkPresent9, (void**)&g_origPresent9) == MH_OK &&
              MH_CreateHook(reset, (void*)&hkReset9, (void**)&g_origReset9) == MH_OK &&
              MH_EnableHook(present) == MH_OK && MH_EnableHook(reset) == MH_OK;
    Log("D3D9 Present/Reset hook: %s", ok ? "ok" : "FAIL");
    return ok;
}

bool Init()
{
    bool a = false, b = false;
    // D3D11 — по умолчанию в Unity; D3D9 — запасной вариант. Ставим оба, победит тот, чей Present вызовется.
    if (GetModuleHandleA("d3d11.dll") || LoadLibraryA("d3d11.dll")) a = HookD3D11();
    b = HookD3D9();
    return a || b;
}

} // namespace overlay
