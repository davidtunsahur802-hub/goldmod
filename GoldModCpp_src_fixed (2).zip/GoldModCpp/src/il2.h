// il2.h - минимальная обёртка над il2cpp API (x86, Unity IL2CPP). Всё ищется по именам, оффсеты не зашиты.
#pragma once
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <initializer_list>

struct Il2CppDomain; struct Il2CppAssembly; struct Il2CppImage; struct Il2CppClass;
struct FieldInfo; struct MethodInfo; struct Il2CppType; struct Il2CppThread;
struct Il2CppObject { Il2CppClass* klass; void* monitor; };

struct V3 { float x, y, z; };
struct Q4 { float x, y, z, w; };
struct Bnds { V3 center; V3 extents; };
struct Col4 { float r, g, b, a; };

void Log(const char* fmt, ...);

namespace il2 {
inline HMODULE ga = nullptr;
#define IL2FN(ret, name, args) inline ret(__cdecl* name) args = nullptr;
IL2FN(Il2CppDomain*, il2cpp_domain_get, ())
IL2FN(const Il2CppAssembly**, il2cpp_domain_get_assemblies, (const Il2CppDomain*, size_t*))
IL2FN(const Il2CppImage*, il2cpp_assembly_get_image, (const Il2CppAssembly*))
IL2FN(const char*, il2cpp_image_get_name, (const Il2CppImage*))
IL2FN(Il2CppClass*, il2cpp_class_from_name, (const Il2CppImage*, const char*, const char*))
IL2FN(const MethodInfo*, il2cpp_class_get_methods, (Il2CppClass*, void**))
IL2FN(const MethodInfo*, il2cpp_class_get_method_from_name, (Il2CppClass*, const char*, int))
IL2FN(FieldInfo*, il2cpp_class_get_field_from_name, (Il2CppClass*, const char*))
IL2FN(Il2CppClass*, il2cpp_class_get_parent, (Il2CppClass*))
IL2FN(const Il2CppType*, il2cpp_class_get_type, (Il2CppClass*))
IL2FN(void, il2cpp_runtime_class_init, (Il2CppClass*))
IL2FN(size_t, il2cpp_field_get_offset, (FieldInfo*))
IL2FN(void, il2cpp_field_static_get_value, (FieldInfo*, void*))
IL2FN(void, il2cpp_field_static_set_value, (FieldInfo*, void*))
IL2FN(const char*, il2cpp_method_get_name, (const MethodInfo*))
IL2FN(uint32_t, il2cpp_method_get_param_count, (const MethodInfo*))
IL2FN(const Il2CppType*, il2cpp_method_get_param, (const MethodInfo*, uint32_t))
IL2FN(const Il2CppType*, il2cpp_method_get_return_type, (const MethodInfo*))
IL2FN(uint32_t, il2cpp_method_get_flags, (const MethodInfo*, uint32_t*))
IL2FN(char*, il2cpp_type_get_name, (const Il2CppType*))
IL2FN(Il2CppObject*, il2cpp_runtime_invoke, (const MethodInfo*, void*, void**, Il2CppObject**))
IL2FN(void*, il2cpp_object_unbox, (Il2CppObject*))
IL2FN(Il2CppObject*, il2cpp_object_new, (Il2CppClass*))
IL2FN(Il2CppObject*, il2cpp_string_new, (const char*))
IL2FN(Il2CppObject*, il2cpp_type_get_object, (const Il2CppType*))
IL2FN(Il2CppThread*, il2cpp_thread_attach, (Il2CppDomain*))
IL2FN(uint32_t, il2cpp_gchandle_new, (Il2CppObject*, int))
IL2FN(Il2CppObject*, il2cpp_gchandle_get_target, (uint32_t))
IL2FN(void, il2cpp_gchandle_free, (uint32_t))

inline bool Init() {
    ga = GetModuleHandleA("GameAssembly.dll");
    if (!ga) return false;
    bool ok = true;
#define LOADFN(n) n = (decltype(n))GetProcAddress(ga, #n); if (!n) { Log("il2cpp export not found: %s", #n); ok = false; }
    LOADFN(il2cpp_domain_get) LOADFN(il2cpp_domain_get_assemblies) LOADFN(il2cpp_assembly_get_image)
    LOADFN(il2cpp_image_get_name) LOADFN(il2cpp_class_from_name) LOADFN(il2cpp_class_get_methods)
    LOADFN(il2cpp_class_get_method_from_name) LOADFN(il2cpp_class_get_field_from_name)
    LOADFN(il2cpp_class_get_parent) LOADFN(il2cpp_class_get_type) LOADFN(il2cpp_runtime_class_init)
    LOADFN(il2cpp_field_get_offset) LOADFN(il2cpp_field_static_get_value) LOADFN(il2cpp_field_static_set_value)
    LOADFN(il2cpp_method_get_name) LOADFN(il2cpp_method_get_param_count) LOADFN(il2cpp_method_get_param)
    LOADFN(il2cpp_method_get_return_type) LOADFN(il2cpp_method_get_flags) LOADFN(il2cpp_type_get_name)
    LOADFN(il2cpp_runtime_invoke) LOADFN(il2cpp_object_unbox) LOADFN(il2cpp_object_new)
    LOADFN(il2cpp_string_new) LOADFN(il2cpp_type_get_object) LOADFN(il2cpp_thread_attach)
    LOADFN(il2cpp_gchandle_new) LOADFN(il2cpp_gchandle_get_target) LOADFN(il2cpp_gchandle_free)
    return ok;
}

inline void Attach() { il2cpp_thread_attach(il2cpp_domain_get()); }

// Ищет класс во всех сборках. ns может быть "".
inline Il2CppClass* FindClass(const char* ns, const char* name) {
    size_t n = 0;
    auto asms = il2cpp_domain_get_assemblies(il2cpp_domain_get(), &n);
    for (size_t i = 0; i < n; i++) {
        auto img = il2cpp_assembly_get_image(asms[i]);
        auto k = il2cpp_class_from_name(img, ns, name);
        if (k) return k;
    }
    return nullptr;
}
inline Il2CppClass* FindClassIn(const char* image, const char* ns, const char* name) {
    size_t n = 0;
    auto asms = il2cpp_domain_get_assemblies(il2cpp_domain_get(), &n);
    for (size_t i = 0; i < n; i++) {
        auto img = il2cpp_assembly_get_image(asms[i]);
        if (strcmp(il2cpp_image_get_name(img), image) != 0) continue;
        auto k = il2cpp_class_from_name(img, ns, name);
        if (k) return k;
    }
    return nullptr;
}

inline const MethodInfo* Method(Il2CppClass* k, const char* name, int argc) {
    return k ? il2cpp_class_get_method_from_name(k, name, argc) : nullptr;
}
inline std::string TypeName(const Il2CppType* t) {
    char* s = il2cpp_type_get_name(t);
    return s ? std::string(s) : std::string();
}
// Поиск метода по типам параметров (имена вида "System.Int32", "UnityEngine.Vector3"); retType может быть nullptr.
inline const MethodInfo* MethodSig(Il2CppClass* k, const char* name, std::initializer_list<const char*> params, const char* retType = nullptr) {
    for (Il2CppClass* c = k; c; c = il2cpp_class_get_parent(c)) {
        void* it = nullptr;
        while (auto m = il2cpp_class_get_methods(c, &it)) {
            if (strcmp(il2cpp_method_get_name(m), name) != 0) continue;
            if (il2cpp_method_get_param_count(m) != params.size()) continue;
            bool ok = true; uint32_t i = 0;
            for (auto p : params) { if (TypeName(il2cpp_method_get_param(m, i++)) != p) { ok = false; break; } }
            if (ok && retType && TypeName(il2cpp_method_get_return_type(m)) != retType) ok = false;
            if (ok) return m;
        }
    }
    return nullptr;
}
inline bool IsStatic(const MethodInfo* m) { uint32_t f = 0; return (il2cpp_method_get_flags(m, &f) & 0x10) != 0; }

// Вызов. Ссылочные аргументы - сам указатель на объект, значимые - указатель на значение.
inline Il2CppObject* Call(const MethodInfo* m, void* self, std::initializer_list<void*> args = {}) {
    if (!m) return nullptr;
    void* a[8] = {}; int i = 0;
    for (auto p : args) a[i++] = p;
    Il2CppObject* exc = nullptr;
    auto r = il2cpp_runtime_invoke(m, self, a, &exc);
    if (exc) return nullptr;
    return r;
}
template <class T> inline T Unbox(Il2CppObject* o, T def = T()) {
    if (!o) return def;
    return *(T*)il2cpp_object_unbox(o);
}

inline FieldInfo* Field(Il2CppClass* k, const char* name) {
    for (Il2CppClass* c = k; c; c = il2cpp_class_get_parent(c)) {
        auto f = il2cpp_class_get_field_from_name(c, name);
        if (f) return f;
    }
    return nullptr;
}
inline int Off(Il2CppClass* k, const char* name) {
    auto f = Field(k, name);
    return f ? (int)il2cpp_field_get_offset(f) : -1;
}
template <class T> inline T Rd(void* obj, int off, T def = T()) {
    if (!obj || off < 0) return def;
    return *(T*)((char*)obj + off);
}
template <class T> inline void Wr(void* obj, int off, T v) {
    if (!obj || off < 0) return;
    *(T*)((char*)obj + off) = v;
}
inline Il2CppObject* Str(const char* s) { return il2cpp_string_new(s); }
inline std::string ToStd(Il2CppObject* s) {
    if (!s) return "";
    int len = *(int*)((char*)s + 8);
    const wchar_t* w = (const wchar_t*)((char*)s + 12);
    if (len <= 0 || len > 4096) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w, len, nullptr, 0, nullptr, nullptr);
    std::string r(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w, len, &r[0], n, nullptr, nullptr);
    return r;
}
// Массивы: заголовок 8 + bounds 4 + length 4 = данные с 16 (x86)
inline int ArrLen(void* a) { return a ? *(int*)((char*)a + 12) : 0; }
template <class T> inline T ArrAt(void* a, int i) { return *(T*)((char*)a + 16 + i * sizeof(T)); }
inline Il2CppObject* TypeObj(Il2CppClass* k) { return il2cpp_type_get_object(il2cpp_class_get_type(k)); }
} // namespace il2
