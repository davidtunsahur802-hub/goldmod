Сюда кладутся зависимости:
- third_party/imgui    (https://github.com/ocornut/imgui, ветка/тег v1.91.9 или новее; нужны backends/imgui_impl_win32 и imgui_impl_dx11)
- third_party/minhook  (https://github.com/TsudaKageyu/minhook, v1.3.4; нужны include/ и src/)

Если папок нет, GitHub Actions и build.bat скачают их сами. Можно скопировать свои из старого проекта.
