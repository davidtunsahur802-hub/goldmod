@echo off
if not exist third_party\imgui\imgui.cpp git clone --depth 1 --branch v1.91.9 https://github.com/ocornut/imgui.git third_party\imgui
if not exist third_party\minhook\src\hook.c git clone --depth 1 --branch v1.3.4 https://github.com/TsudaKageyu/minhook.git third_party\minhook
cmake -S . -B build -A Win32 || exit /b 1
cmake --build build --config Release || exit /b 1
echo Done: bin\GoldMod.dll
