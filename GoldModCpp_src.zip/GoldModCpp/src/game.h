#pragma once
#include <atomic>
#include <functional>
#include <string>

// Игровая логика. Все обращения к il2cpp/Unity выполняются в ГЛАВНОМ потоке игры
// (через хук RuntimeManager.Update). Поток отрисовки (Present) только ставит команды в очередь
// и читает готовый снимок состояния.
namespace game {

struct Settings {
    std::atomic<bool>  wallhack{false};
    std::atomic<bool>  aim{false};
    std::atomic<bool>  aimAlways{false};      // иначе — только пока зажата ПКМ
    std::atomic<float> aimSmooth{0.35f};      // 0.02..1 (1 = мгновенно)
    std::atomic<float> aimFov{60.0f};         // градусы
    std::atomic<float> aimHeight{1.4f};       // высота точки прицеливания над позицией врага
    std::atomic<bool>  bhop{false};
    std::atomic<bool>  speedOn{false};
    std::atomic<float> speedMul{2.0f};
    std::atomic<bool>  jumpOn{false};
    std::atomic<float> jumpMul{2.0f};
    std::atomic<bool>  raiseBotMax{false};    // снять лимит ботов
    std::atomic<bool>  lockControls{true};
};
extern Settings S;

struct Snapshot {
    bool        bound = false;
    std::string status;
    long long   gold = -1;
    bool        playerFound = false;
    int         enemies = 0;
};

bool     Init();
Snapshot Snap();
void     Post(std::function<void()> fn);

// команды из UI (выполняются в главном потоке)
void CmdGoldSet(long long amount);
void CmdKillReward(int value);
void CmdWallhackOff();
void CmdRestorePlayer();
void CmdMenuOpen(bool open);
void CmdUnlockAchievements();
void CmdGiveAllItems();
void CmdWriteKey(const std::string& key, const std::string& value, int type); // 0 Safe int, 1 PlayerPrefs int, 2 string
void CmdHardClean();

} // namespace game
