#pragma once
#include <atomic>
#include <functional>
#include <string>
#include <vector>

// Игровая логика. Все обращения к il2cpp/Unity выполняются в ГЛАВНОМ потоке игры
// (через хук RuntimeManager.Update). Поток отрисовки (Present) только ставит команды в очередь
// и читает готовый снимок состояния.
namespace game {

struct Settings {
    std::atomic<bool>  wallhack{false};
    std::atomic<bool>  aim{false};
    std::atomic<bool>  aimAlways{false};      // иначе — только пока зажата ПКМ
    std::atomic<float> aimSmooth{0.35f};      // 0.02..1 (1 = мгновенно)
    std::atomic<float> aimFov{60.0f};         // градусы
    std::atomic<int>   aimPart{0};            // 0 голова, 1 тело, 2 ноги
    std::atomic<float> enemyHeight{1.65f};     // высота модели врага (для аима и боксов)
    std::atomic<float> aimHeadOffset{0.07f};  // поправка вверх от кости головы (м)
    std::atomic<bool>  autoTpBot{false};      // телепорт к каждому новому боту, как только он появился
    std::atomic<float> tpDist{2.5f};          // на каком расстоянии от бота встать
    std::atomic<bool>  rewardBackup{true};    // дозачислять голду/опыт, если игра за килл не дала
    std::atomic<int>   espMode{0};            // 0 чамсы, 1 боксы, 2 оба
    std::atomic<bool>  bhop{false};
    std::atomic<bool>  speedOn{false};
    std::atomic<float> speedMul{2.0f};
    std::atomic<bool>  jumpOn{false};
    std::atomic<float> jumpMul{2.0f};
    std::atomic<bool>  autoKillBots{false};   // постоянно убирать появляющихся ботов
    std::atomic<bool>  raiseBotMax{false};    // снять лимит ботов
    std::atomic<bool>  lockControls{true};
};
extern Settings S;

struct EspBox { float x, y, w, h; float hp; };
std::vector<EspBox> Esp();      // боксы для отрисовки (экранные координаты)
bool EspWanted();               // нужно ли рисовать оверлей даже при закрытом меню

struct Snapshot {
    bool        bound = false;
    std::string status;
    long long   gold = -1;
    bool        playerFound = false;
    int         enemies = 0;
};

bool     Init();
Snapshot Snap();
void     Post(std::function<void()> fn);

// команды из UI (выполняются в главном потоке)
void CmdGoldSet(long long amount);
void CmdKillReward(int money, int exp);
void CmdKillAllBots();
void CmdTeleportToBot();
void CmdSpawnBoss();
void CmdWallhackOff();
void CmdRemoveBots();
void CmdRestorePlayer();
void CmdMenuOpen(bool open);
void CmdUnlockAchievements();
void CmdGiveAllItems();
void CmdWriteKey(const std::string& key, const std::string& value, int type); // 0 Safe int, 1 PlayerPrefs int, 2 string
void CmdHardClean();

} // namespace game
