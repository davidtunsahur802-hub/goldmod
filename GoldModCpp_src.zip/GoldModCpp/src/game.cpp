#include "game.h"
#include "il2cpp.h"
#include "common.h"
#include "MinHook.h"

#include <cstring>
#include <mutex>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <set>
#include <unordered_set>
#include <unordered_map>
#include <cctype>

using namespace il2;

namespace game {

Settings S;

// ----------------------------------------------------------------------------------------
// состояние
// ----------------------------------------------------------------------------------------
static std::mutex            g_mx;          // снимок + статус
static Snapshot              g_snap;
static std::mutex            g_qmx;         // очередь команд
static std::vector<std::function<void()>> g_queue;

static void SetStatus(const std::string& s) { std::lock_guard<std::mutex> l(g_mx); g_snap.status = s; }

Snapshot Snap() { std::lock_guard<std::mutex> l(g_mx); return g_snap; }
void Post(std::function<void()> fn) { std::lock_guard<std::mutex> l(g_qmx); g_queue.push_back(std::move(fn)); }

// ----------------------------------------------------------------------------------------
// привязки к игре
// ----------------------------------------------------------------------------------------
static struct Bind {
    Klass *cController = nullptr, *cInventory = nullptr, *cPolygon = nullptr, *cEnemy = nullptr,
          *cPlayer = nullptr, *cPrefsSafe = nullptr, *cInt = nullptr, *cFloat = nullptr,
          *cPlayerPrefs = nullptr, *cBehaviour = nullptr, *cObject = nullptr, *cCursor = nullptr,
          *cRuntimeMgr = nullptr, *cComponent = nullptr, *cTransform = nullptr, *cOutline = nullptr,
          *cAchCtl = nullptr, *cAchive = nullptr, *cItemShop = nullptr, *cCamera = nullptr, *cScreen = nullptr, *cGameObject = nullptr, *cCollider = nullptr;

    Method *prefGet = nullptr, *prefSet = nullptr, *prefsSave = nullptr, *loadMoney = nullptr,
           *intTo = nullptr, *intFrom = nullptr, *floatTo = nullptr, *floatFrom = nullptr,
           *findOne = nullptr, *findAll = nullptr, *setEnabled = nullptr,
           *getLock = nullptr, *setLock = nullptr, *setVisible = nullptr, *rmUpdate = nullptr,
           *getTransform = nullptr, *getPos = nullptr, *w2s = nullptr, *getGO = nullptr, *goGetTransform = nullptr, *instantiate = nullptr, *goSetActive = nullptr, *objDestroy = nullptr, *destroyObj = nullptr, *setPos = nullptr, *setColEnabled = nullptr, *scrW = nullptr, *scrH = nullptr,
           *olMode = nullptr, *olWidth = nullptr, *olColor = nullptr,
           *ppSetInt = nullptr, *ppSetStr = nullptr, *ppDeleteAll = nullptr;

    Field *fCountEnemy = nullptr, *fCountEnemyMax = nullptr, *fPolygonObj = nullptr,
          *fMoneyHeadS = nullptr, *fMoneyBodyS = nullptr, *fAchObj = nullptr, *fInvObj = nullptr, *fExpHeadS = nullptr, *fExpBodyS = nullptr, *fPolyEnemy = nullptr;

    int oWallHack = -1, oHealth = -1, oMoneyHead = -1, oMoneyBody = -1, oControl = -1;
    int oWalk = -1, oAccel = -1, oAccelMax = -1, oJump = -1;
    int oWalkF = -1, oNewWalkF = -1, oOldWalkF = -1, oAccelF = -1, oAccelMaxF = -1, oJumpF = -1;
    int oCamera = -1, oCharRot = -1, oCamRot = -1, oMinX = -1, oMaxX = -1, oClampV = -1, oJumpPeremes = -1;
    int oAchives = -1, oAchCountMain = -1, oAchNumber = -1, oAchFinish = -1, oAchLevel = -1;
    int oAllItems = -1, oItemNumber = -1, oHealthAll = -1, oExpHead = -1, oExpBody = -1, oCharCtl = -1, oEnemy2Prefab = -1, oSpawners = -1;

    Object *typePlayer = nullptr, *typeEnemy = nullptr;
    bool ok = false;
} B;

// ----------------------------------------------------------------------------------------
// мелкие помощники (главный поток)
// ----------------------------------------------------------------------------------------
static int PrefGet(const char* key, int def)
{
    void* a[2] = { il2cpp_string_new(key), &def };
    return UnboxAs<int>(Invoke(B.prefGet, nullptr, a), def);
}

static void PrefSet(const char* key, int v)
{
    void* a[2] = { il2cpp_string_new(key), &v };
    Invoke(B.prefSet, nullptr, a);
}

// Защищённый Int игры = { int value; int salt; } — кодируем/декодируем ЕГО ЖЕ методами
static void EncodeInt(int v, uint8_t out[8])
{
    void* a[1] = { &v };
    Object* r = Invoke(B.intTo, nullptr, a);
    if (r) std::memcpy(out, il2cpp_object_unbox(r), 8); else std::memset(out, 0, 8);
}

static int DecodeInt(const uint8_t in[8])
{
    uint8_t tmp[8]; std::memcpy(tmp, in, 8);
    void* a[1] = { tmp };
    return UnboxAs<int>(Invoke(B.intFrom, nullptr, a), 0);
}

static void EncodeFloat(float v, uint8_t out[8])
{
    void* a[1] = { &v };
    Object* r = Invoke(B.floatTo, nullptr, a);
    if (r) std::memcpy(out, il2cpp_object_unbox(r), 8); else std::memset(out, 0, 8);
}

static float DecodeFloat(const uint8_t in[8], float def)
{
    if (!B.floatFrom) return def;
    uint8_t tmp[8]; std::memcpy(tmp, in, 8);
    void* a[1] = { tmp };
    return UnboxAs<float>(Invoke(B.floatFrom, nullptr, a), def);
}

static bool StaticIntGet(Field* f, int& out)
{
    if (!f) return false;
    uint8_t buf[8] = {};
    il2cpp_field_static_get_value(f, buf);
    out = DecodeInt(buf);
    return true;
}

static void StaticIntSet(Field* f, int v)
{
    if (!f) return;
    uint8_t buf[8];
    EncodeInt(v, buf);
    il2cpp_field_static_set_value(f, buf);
}

template <class T> static T& At(void* obj, int off) { return *(T*)((char*)obj + off); }

static void* FindOne(Object* type)
{
    bool inactive = false;
    void* a[2] = { type, &inactive };
    return Invoke(B.findOne, nullptr, a);
}

static void* FindAll(Object* type)
{
    void* a[1] = { type };
    return Invoke(B.findAll, nullptr, a);
}

static void SetEnabled(void* behaviour, bool on)
{
    if (!behaviour) return;
    void* a[1] = { &on };
    Invoke(B.setEnabled, behaviour, a);
}

// ----------------------------------------------------------------------------------------
// привязка (поток инициализации)
// ----------------------------------------------------------------------------------------

// дополнительные привязки (кости врага, bounds, CharacterController.Move)
static struct Bind2 {
    Klass *cRenderer = nullptr, *cCharCtl = nullptr;
    Method *objGetName = nullptr, *trChildCount = nullptr, *trGetChild = nullptr,
           *getBounds = nullptr, *getCompInChildren = nullptr, *ccMove = nullptr;
    Object *typeRenderer = nullptr;
    Klass *cTriggerLose = nullptr, *cResources = nullptr, *cGO = nullptr;
    Method *hitEnemy = nullptr, *trigEnter = nullptr, *goGetComp = nullptr, *dontDestroy = nullptr,
           *findAllRes = nullptr, *instGO = nullptr, *goSetActive2 = nullptr, *setName = nullptr;
    Object *typeGO = nullptr;
} B2;

static void BindExtra()
{
    B2.cRenderer = FindClass("UnityEngine", "Renderer");
    B2.cCharCtl  = FindClass("UnityEngine", "CharacterController");
    B2.objGetName = FindMethod(B.cObject, "get_name", {}, nullptr, 0);
    if (B.cTransform)
    {
        B2.trChildCount = FindMethod(B.cTransform, "get_childCount", {}, nullptr, 0);
        B2.trGetChild   = FindMethod(B.cTransform, "GetChild", { "System.Int32" }, nullptr, 0);
    }
    if (B2.cRenderer)
    {
        B2.getBounds = FindMethod(B2.cRenderer, "get_bounds", {}, nullptr, 0);
        B2.typeRenderer = TypeObject(B2.cRenderer);
    }
    if (B.cComponent) B2.getCompInChildren = FindMethod(B.cComponent, "GetComponentInChildren", { "System.Type", "System.Boolean" }, nullptr, 0);
    if (B2.cCharCtl)  B2.ccMove = FindMethod(B2.cCharCtl, "Move", { "UnityEngine.Vector3" }, nullptr, 0);
    B2.cTriggerLose = FindClass("", "TriggerLose");
    B2.cResources   = FindClass("UnityEngine", "Resources");
    B2.cGO          = FindClass("UnityEngine", "GameObject");
    B2.hitEnemy = FindMethod(B.cPlayer, "HitEnemy", { "System.Single", "System.Int32", "EnemyController" }, nullptr, 0);
    if (B2.cTriggerLose) B2.trigEnter = FindMethod(B2.cTriggerLose, "OnTriggerEnter", { "UnityEngine.Collider" }, nullptr, 0);
    if (B2.cGO)
    {
        B2.goGetComp = FindMethod(B2.cGO, "GetComponent", { "System.Type" }, nullptr, 0);
        B2.goSetActive2 = FindMethod(B2.cGO, "SetActive", { "System.Boolean" }, nullptr, 0);
        B2.typeGO = TypeObject(B2.cGO);
    }
    B2.dontDestroy = FindMethod(B.cObject, "DontDestroyOnLoad", { "UnityEngine.Object" }, nullptr, 1);
    B2.instGO = FindMethod(B.cObject, "Instantiate", { "UnityEngine.Object", "UnityEngine.Vector3", "UnityEngine.Quaternion" }, nullptr, 1);
    if (B2.cResources) B2.findAllRes = FindMethod(B2.cResources, "FindObjectsOfTypeAll", { "System.Type" }, nullptr, 1);
    Log("bind7: hitEnemy=%p triggerLose.OnTriggerEnter=%p getComp=%p dontDestroy=%p findAllRes=%p",
        B2.hitEnemy, B2.trigEnter, B2.goGetComp, B2.dontDestroy, B2.findAllRes);
    Log("bind6: name=%p childCount=%p getChild=%p bounds=%p getCompInChildren=%p ccMove=%p charCtl@%d",
        B2.objGetName, B2.trChildCount, B2.trGetChild, B2.getBounds, B2.getCompInChildren, B2.ccMove, B.oCharCtl);
}

static bool BindAll()
{
    B.cController  = FindClass("", "Controller");
    B.cInventory   = FindClass("", "ControllerInventory");
    B.cPolygon     = FindClass("", "ControllerPolygon");
    B.cEnemy       = FindClass("", "EnemyController");
    B.cPlayer      = FindClass("", "PlayerController");
    B.cPrefsSafe   = FindClass("", "PlayerPrefsSafe");
    B.cInt         = FindClass("", "Int");
    B.cFloat       = FindClass("", "Float");
    B.cPlayerPrefs = FindClass("UnityEngine", "PlayerPrefs");
    B.cBehaviour   = FindClass("UnityEngine", "Behaviour");
    B.cObject      = FindClass("UnityEngine", "Object");
    B.cCursor      = FindClass("UnityEngine", "Cursor");
    B.cRuntimeMgr  = FindClass("FMODUnity", "RuntimeManager");

    if (!B.cController || !B.cInventory || !B.cPolygon || !B.cEnemy || !B.cPlayer || !B.cPrefsSafe ||
        !B.cInt || !B.cFloat || !B.cPlayerPrefs || !B.cBehaviour || !B.cObject || !B.cRuntimeMgr)
    {
        Log("BindAll: не найден один из классов (Controller=%p Inventory=%p Polygon=%p Enemy=%p Player=%p "
            "PrefsSafe=%p Int=%p Float=%p PlayerPrefs=%p Behaviour=%p Object=%p RuntimeManager=%p)",
            B.cController, B.cInventory, B.cPolygon, B.cEnemy, B.cPlayer, B.cPrefsSafe, B.cInt, B.cFloat,
            B.cPlayerPrefs, B.cBehaviour, B.cObject, B.cRuntimeMgr);
        return false;
    }

    // PlayerPrefsSafe: имена обфусцированы, ищем по сигнатуре (string,int)->int / ->void
    B.prefGet = FindMethod(B.cPrefsSafe, nullptr, { "System.String", "System.Int32" }, "System.Int32", 1);
    B.prefSet = FindMethod(B.cPrefsSafe, nullptr, { "System.String", "System.Int32" }, "System.Void", 1);
    B.prefsSave = FindMethod(B.cPlayerPrefs, "Save", {}, nullptr, 1);
    B.loadMoney = FindMethod(B.cInventory, "LoadMoney", {}, nullptr, 1);

    // защищённые типы Int / Float: static Int(int) и static int(Int); static Float(float)
    B.intTo   = FindMethod(B.cInt, nullptr, { "System.Int32" }, "Int", 1);
    B.intFrom = FindMethod(B.cInt, nullptr, { "Int" }, "System.Int32", 1);
    B.floatTo = FindMethod(B.cFloat, nullptr, { "System.Single" }, "Float", 1);

    B.findOne    = FindMethod(B.cObject, "FindObjectOfType", { "System.Type", "System.Boolean" }, nullptr, 1);
    B.findAll    = FindMethod(B.cObject, "FindObjectsOfType", { "System.Type" }, nullptr, 1);
    B.setEnabled = FindMethod(B.cBehaviour, "set_enabled", { "System.Boolean" }, nullptr, 0);
    if (B.cCursor)
    {
        B.getLock    = FindMethod(B.cCursor, "get_lockState", {}, nullptr, 1);
        B.setLock    = FindMethod(B.cCursor, "set_lockState", { "*" }, nullptr, 1);
        B.setVisible = FindMethod(B.cCursor, "set_visible", { "System.Boolean" }, nullptr, 1);
    }
    B.rmUpdate = FindMethod(B.cRuntimeMgr, "Update", {}, "System.Void", 0);

    il2cpp_runtime_class_init(B.cController);
    il2cpp_runtime_class_init(B.cPolygon);

    B.fCountEnemy    = FindField(B.cController, "_countEnemy");
    B.fCountEnemyMax = FindField(B.cController, "_countEnemyMax");
    B.fPolygonObj    = FindField(B.cPolygon, "_obj");
    B.fMoneyHeadS    = FindField(B.cPolygon, "MoneyKill_Head");
    B.fMoneyBodyS    = FindField(B.cPolygon, "MoneyKill_Body");

    B.oWallHack  = FieldOffset(B.cEnemy, "WallHack");
    B.oHealth    = FieldOffset(B.cEnemy, "_health");
    B.oHealthAll = FieldOffset(B.cEnemy, "_healthAll");
    B.oMoneyHead = FieldOffset(B.cPolygon, "_moneyKill_Head");
    B.oMoneyBody = FieldOffset(B.cPolygon, "_moneyKill_Body");

    B.oControl   = FieldOffset(B.cPlayer, "m_controllPlayer");
    B.oWalk      = FieldOffset(B.cPlayer, "m_WalkSpeed");
    B.oAccel     = FieldOffset(B.cPlayer, "m_AccelSpeed");
    B.oAccelMax  = FieldOffset(B.cPlayer, "m_AccelSpeedMax");
    B.oJump      = FieldOffset(B.cPlayer, "m_JumpSpeed");
    B.oWalkF     = FieldOffset(B.cPlayer, "m_walkSpeed");
    B.oAccelF    = FieldOffset(B.cPlayer, "m_accelSpeed");
    B.oAccelMaxF = FieldOffset(B.cPlayer, "m_accelSpeedMax");
    B.oJumpF     = FieldOffset(B.cPlayer, "m_jumpSpeed");

    B.typePlayer = TypeObject(B.cPlayer);
    B.typeEnemy  = TypeObject(B.cEnemy);


    B.cComponent = FindClass("UnityEngine", "Component");
    B.cTransform = FindClass("UnityEngine", "Transform");
    B.cOutline   = FindClass("", "Outline");
    B.cAchCtl    = FindClass("", "AchiveController");
    B.cAchive    = FindClass("", "Achive");
    B.cItemShop  = FindClass("", "ItemShop");

    B.cGameObject = FindClass("UnityEngine", "GameObject");
    if (B.cComponent)  B.getGO = FindMethod(B.cComponent, "get_gameObject", {}, nullptr, 0);
    if (B.cGameObject) B.goSetActive = FindMethod(B.cGameObject, "SetActive", { "System.Boolean" }, nullptr, 0);
    B.objDestroy = FindMethod(B.cObject, "Destroy", { "UnityEngine.Object" }, nullptr, 1);
    Log("bind4: getGO=%p setActive=%p destroy=%p", B.getGO, B.goSetActive, B.objDestroy);
    B.cCollider = FindClass("UnityEngine", "Collider");
    if (B.cComponent) B.getGO = FindMethod(B.cComponent, "get_gameObject", {}, nullptr, 0);
    B.destroyObj = FindMethod(B.cObject, "Destroy", { "UnityEngine.Object" }, nullptr, 1);
    if (B.cTransform) B.setPos = FindMethod(B.cTransform, "set_position", { "UnityEngine.Vector3" }, nullptr, 0);
    if (B.cCollider) B.setColEnabled = FindMethod(B.cCollider, "set_enabled", { "System.Boolean" }, nullptr, 0);
    B.fExpHeadS = FindField(B.cPolygon, "ExpKill_Head");
    B.fExpBodyS = FindField(B.cPolygon, "ExpKill_Body");
    B.oExpHead  = FieldOffset(B.cPolygon, "_expKill_Head");
    B.oExpBody  = FieldOffset(B.cPolygon, "_expKill_Body");
    B.oCharCtl  = FieldOffset(B.cPlayer, "m_CharacterController");
    Log("bind4: getGO=%p destroy=%p setPos=%p colEnabled=%p exp@%d/%d charCtl@%d", B.getGO, B.destroyObj,
        B.setPos, B.setColEnabled, B.oExpHead, B.oExpBody, B.oCharCtl);
    B.cGameObject = FindClass("UnityEngine", "GameObject");
    if (B.cGameObject) B.goGetTransform = FindMethod(B.cGameObject, "get_transform", {}, nullptr, 0);
    B.instantiate = FindMethod(B.cObject, "Instantiate", { "UnityEngine.Object", "UnityEngine.Vector3", "UnityEngine.Quaternion" }, nullptr, 1);
    B.fPolyEnemy = FindField(B.cPolygon, "_enemy");
    B.oEnemy2Prefab = FieldOffset(B.cPolygon, "Enemy2Prefab");
    B.oSpawners = FieldOffset(B.cPolygon, "SpawnersEnemy");
    Log("bind5: goTransform=%p instantiate=%p polyEnemy=%p enemy2@%d spawners@%d", B.goGetTransform, B.instantiate,
        B.fPolyEnemy, B.oEnemy2Prefab, B.oSpawners);
    B.cCamera = FindClass("UnityEngine", "Camera");
    B.cScreen = FindClass("UnityEngine", "Screen");
    if (B.cCamera) B.w2s = FindMethod(B.cCamera, "WorldToScreenPoint", { "UnityEngine.Vector3" }, nullptr, 0);
    if (B.cScreen) { B.scrW = FindMethod(B.cScreen, "get_width", {}, nullptr, 1); B.scrH = FindMethod(B.cScreen, "get_height", {}, nullptr, 1); }
    Log("bind3: camera=%p w2s=%p screen=%p w=%p h=%p", B.cCamera, B.w2s, B.cScreen, B.scrW, B.scrH);

    B.floatFrom = FindMethod(B.cFloat, nullptr, { "Float" }, "System.Single", 1);
    if (B.cComponent) B.getTransform = FindMethod(B.cComponent, "get_transform", {}, nullptr, 0);
    if (B.cTransform) B.getPos = FindMethod(B.cTransform, "get_position", {}, nullptr, 0);
    if (B.cOutline)
    {
        B.olMode  = FindMethod(B.cOutline, "set_OutlineMode", { "*" }, nullptr, 0);
        B.olWidth = FindMethod(B.cOutline, "set_OutlineWidth", { "System.Single" }, nullptr, 0);
        B.olColor = FindMethod(B.cOutline, "set_OutlineColor", { "*" }, nullptr, 0);
    }
    B.ppSetInt    = FindMethod(B.cPlayerPrefs, "SetInt", { "System.String", "System.Int32" }, nullptr, 1);
    B.ppSetStr    = FindMethod(B.cPlayerPrefs, "SetString", { "System.String", "System.String" }, nullptr, 1);
    B.ppDeleteAll = FindMethod(B.cPlayerPrefs, "DeleteAll", {}, nullptr, 1);

    B.oNewWalkF  = FieldOffset(B.cPlayer, "m_newWalkSpeed");
    B.oOldWalkF  = FieldOffset(B.cPlayer, "m_oldWalkSpeed");
    B.oCamera    = FieldOffset(B.cPlayer, "Camera");
    B.oCharRot   = FieldOffset(B.cPlayer, "m_CharacterTargetRot");
    B.oCamRot    = FieldOffset(B.cPlayer, "m_CameraTargetRot");
    B.oMinX      = FieldOffset(B.cPlayer, "MinimumX");
    B.oMaxX      = FieldOffset(B.cPlayer, "MaximumX");
    B.oClampV    = FieldOffset(B.cPlayer, "clampVerticalRotation");
    B.oJumpPeremes = FieldOffset(B.cPlayer, "m_JumpPeremes");

    if (B.cAchCtl)
    {
        B.fAchObj  = FindField(B.cAchCtl, "_obj");
        B.oAchives = FieldOffset(B.cAchCtl, "Achives");
    }
    if (B.cAchive)
    {
        B.oAchCountMain = FieldOffset(B.cAchive, "_countMain");
        B.oAchNumber    = FieldOffset(B.cAchive, "_numberAchive");
        B.oAchFinish    = FieldOffset(B.cAchive, "_numberFinish");
        B.oAchLevel     = FieldOffset(B.cAchive, "_levelAchive");
    }
    B.fInvObj = FindField(B.cInventory, "_obj");
    B.oAllItems = FieldOffset(B.cInventory, "AllItems");
    if (B.cItemShop) B.oItemNumber = FieldOffset(B.cItemShop, "_numberItem");
    Log("bind2: outline=%p(m=%p w=%p c=%p) pos=%p tr=%p cam@%d charRot@%d camRot@%d jumpFlag@%d ach=%p/%p items@%d",
        B.cOutline, B.olMode, B.olWidth, B.olColor, B.getPos, B.getTransform, B.oCamera, B.oCharRot,
        B.oCamRot, B.oJumpPeremes, B.cAchCtl, B.cAchive, B.oAllItems);

    Log("bind: prefGet=%p prefSet=%p save=%p loadMoney=%p intTo=%p intFrom=%p floatTo=%p findOne=%p findAll=%p "
        "setEnabled=%p rmUpdate=%p", B.prefGet, B.prefSet, B.prefsSave, B.loadMoney, B.intTo, B.intFrom,
        B.floatTo, B.findOne, B.findAll, B.setEnabled, B.rmUpdate);
    Log("bind: countEnemy=%p countEnemyMax=%p polygonObj=%p wallHack@%d health@%d control@%d walk@%d walkF@%d",
        B.fCountEnemy, B.fCountEnemyMax, B.fPolygonObj, B.oWallHack, B.oHealth, B.oControl, B.oWalk, B.oWalkF);

    if (!B.prefGet || !B.prefSet || !B.intTo || !B.intFrom || !B.findOne || !B.findAll ||
        !B.setEnabled || !B.rmUpdate)
    {
        Log("BindAll: не найден критичный метод");
        return false;
    }

    BindExtra();

    // проверка кодирования Int: должно вернуть то же число
    uint8_t t[8];
    EncodeInt(12345, t);
    int back = DecodeInt(t);
    Log("Int roundtrip: %d (ожидалось 12345)", back);
    if (back != 12345) return false;

    B.ok = true;
    return true;
}

// ----------------------------------------------------------------------------------------
// действия (главный поток)
// ----------------------------------------------------------------------------------------
static void PrefsSaveNow() { if (B.prefsSave) Invoke(B.prefsSave, nullptr, nullptr); }

static void DoGoldSet(long long v)
{
    if (!B.prefGet || !B.prefSet) { SetStatus("PlayerPrefsSafe не найден"); return; }
    v = std::max(0ll, std::min<long long>(v, 2147483647ll));
    PrefSet("GoldCount", (int)v);
    PrefsSaveNow();
    if (B.loadMoney) Invoke(B.loadMoney, nullptr, nullptr);
    std::lock_guard<std::mutex> l(g_mx);
    g_snap.gold = v;
    g_snap.status = "Установлено: " + std::to_string(v);
}

static void DoGoldRead()
{
    if (!B.prefGet) return;
    int cur = PrefGet("GoldCount", 0);
    std::lock_guard<std::mutex> l(g_mx);
    g_snap.gold = cur;
    g_snap.status = "Сейчас: " + std::to_string(cur);
}

static bool g_rewardOn = false;
static int  g_rewardMoney = 0, g_rewardExp = 0;

// пишет значения во все места, где игра может их читать; возвращает, сколько мест нашлось
static int ApplyReward(void* obj, int money, int exp)
{
    int hit = 0;
    if (obj)
    {
        if (B.oMoneyHead >= 0) { At<int>(obj, B.oMoneyHead) = money; hit++; }
        if (B.oMoneyBody >= 0) { At<int>(obj, B.oMoneyBody) = money; hit++; }
        if (B.oExpHead >= 0)   { At<int>(obj, B.oExpHead) = exp; hit++; }
        if (B.oExpBody >= 0)   { At<int>(obj, B.oExpBody) = exp; hit++; }
    }
    if (B.fMoneyHeadS) { StaticIntSet(B.fMoneyHeadS, money); hit++; }
    if (B.fMoneyBodyS) { StaticIntSet(B.fMoneyBodyS, money); hit++; }
    if (B.fExpHeadS)   { StaticIntSet(B.fExpHeadS, exp); hit++; }
    if (B.fExpBodyS)   { StaticIntSet(B.fExpBodyS, exp); hit++; }
    return hit;
}

static void DoKillReward(int money, int exp)
{
    void* obj = nullptr;
    if (B.fPolygonObj) il2cpp_field_static_get_value(B.fPolygonObj, &obj);
    g_rewardMoney = money; g_rewardExp = exp; g_rewardOn = true;
    int hit = ApplyReward(obj, money, exp);
    Log("reward: obj=%p hit=%d (fields: money@%d/%d exp@%d/%d static: %p %p %p %p)", obj, hit,
        B.oMoneyHead, B.oMoneyBody, B.oExpHead, B.oExpBody,
        B.fMoneyHeadS, B.fMoneyBodyS, B.fExpHeadS, B.fExpBodyS);
    if (hit == 0) { SetStatus("Поля награды не найдены — игра обновилась, пришли GoldMod.log и новый dump.cs"); return; }
    SetStatus("Награда держится: голда " + std::to_string(money) + ", опыт " + std::to_string(exp) +
              (obj ? "" : "  (режим полигона не запущен — применится при старте)"));
}

static void RewardTick()
{
    if (!g_rewardOn) return;
    void* obj = nullptr;
    if (B.fPolygonObj) il2cpp_field_static_get_value(B.fPolygonObj, &obj);
    ApplyReward(obj, g_rewardMoney, g_rewardExp);
}

// ---- Unity helpers ----
static bool GetPos(void* comp, float out[3])
{
    if (!comp || !B.getTransform || !B.getPos) return false;
    Object* t = Invoke(B.getTransform, comp, nullptr);
    if (!t) return false;
    Object* p = Invoke(B.getPos, t, nullptr);
    if (!p) return false;
    std::memcpy(out, il2cpp_object_unbox(p), 12);
    return true;
}

static bool IsAlive(void* en)
{
    void* boss = nullptr;
    if (B.fPolyEnemy) il2cpp_field_static_get_value(B.fPolyEnemy, &boss);
    if (en == boss) return true;                       // у босса здоровье может храниться отдельно
    return B.oHealth < 0 || At<int>(en, B.oHealth) > 0;
}

// ---- игрок ----
struct PF { int plain, prot; float base; uint8_t enc[8]; float lastV; bool encOk; };
static PF pfWalk{}, pfNewWalk{}, pfOldWalk{}, pfAccel{}, pfAccelMax{}, pfJump{};
static void* g_player = nullptr;
static bool  g_speedApplied = false, g_jumpApplied = false;

static void SetupPF()
{
    pfWalk    = { B.oWalk,    B.oWalkF,    0, {}, 0, false };
    pfNewWalk = { -1,         B.oNewWalkF, 0, {}, 0, false };
    pfOldWalk = { -1,         B.oOldWalkF, 0, {}, 0, false };
    pfAccel   = { B.oAccel,   B.oAccelF,   0, {}, 0, false };
    pfAccelMax= { B.oAccelMax,B.oAccelMaxF,0, {}, 0, false };
    pfJump    = { B.oJump,    B.oJumpF,    0, {}, 0, false };
}

static void CapturePF(PF& p)
{
    p.encOk = false;
    if (p.plain >= 0) p.base = At<float>(g_player, p.plain);
    else if (p.prot >= 0) p.base = DecodeFloat((uint8_t*)g_player + p.prot, 0.f);
}

static void ApplyPF(PF& p, float mul)
{
    float v = p.base * mul;
    if (p.plain >= 0) At<float>(g_player, p.plain) = v;
    if (p.prot >= 0 && B.floatTo)
    {
        if (!p.encOk || p.lastV != v) { EncodeFloat(v, p.enc); p.lastV = v; p.encOk = true; }
        std::memcpy((char*)g_player + p.prot, p.enc, 8);
    }
}

static void RefreshPlayer()
{
    void* np = FindOne(B.typePlayer);
    if (np != g_player)
    {
        g_player = np;
        g_speedApplied = g_jumpApplied = false;
        if (g_player)
        {
            CapturePF(pfWalk); CapturePF(pfNewWalk); CapturePF(pfOldWalk);
            CapturePF(pfAccel); CapturePF(pfAccelMax); CapturePF(pfJump);
            Log("player %p: walk=%.2f jump=%.2f accel=%.2f", g_player, pfWalk.base, pfJump.base, pfAccel.base);
        }
    }
    std::lock_guard<std::mutex> l(g_mx);
    g_snap.playerFound = g_player != nullptr;
}

static void DoRestorePlayer()
{
    if (!g_player) return;
    ApplyPF(pfWalk, 1); ApplyPF(pfNewWalk, 1); ApplyPF(pfOldWalk, 1); ApplyPF(pfAccel, 1); ApplyPF(pfAccelMax, 1);
    ApplyPF(pfJump, 1);
    g_speedApplied = g_jumpApplied = false;
}

// Ускоренная ходьба. Поля скорости игры защищены (Float с солью) и игра пересчитывает их сама,
// поэтому их подмена не срабатывала. Вместо этого смотрим, на сколько игра сдвинула игрока
// за кадр по горизонтали, и добавляем (x-1) от этого сдвига через CharacterController.Move.
static bool  g_lastValid = false;
static float g_lastP[3] = {};
static void* g_lastPlayer = nullptr;

static void SpeedBoostTick(bool menuOpen)
{
    float p[3];
    if (!GetPos(g_player, p)) { g_lastValid = false; return; }
    void* cc = (B.oCharCtl >= 0) ? At<void*>(g_player, B.oCharCtl) : nullptr;
    float m = (float)S.speedMul - 1.0f;
    if (g_lastValid && g_lastPlayer == g_player && !menuOpen && cc && B2.ccMove && m > 0.01f)
    {
        float dx = p[0] - g_lastP[0], dy = p[1] - g_lastP[1], dz = p[2] - g_lastP[2];
        float h = std::sqrt(dx * dx + dz * dz);
        if (h > 1e-4f && h < 1.5f)       // больше — это телепорт/респавн, не ходьба
        {
            // маленький «прижим» к земле, иначе isGrounded у игры будет мигать
            float mv[3] = { dx * m, (std::fabs(dy) < 0.003f) ? -0.01f : 0.0f, dz * m };
            void* a[1] = { mv };
            Invoke(B2.ccMove, cc, a);
            GetPos(g_player, p);
        }
    }
    std::memcpy(g_lastP, p, sizeof(p));
    g_lastValid = true;
    g_lastPlayer = g_player;
}

// ---- ноуклип: отключаем CharacterController и двигаем игрока сами, оставаясь в его теле ----
static bool g_nocActive = false;
static ULONGLONG g_nocLast = 0;

static void SetCharCtl(bool on)
{
    void* cc = (g_player && B.oCharCtl >= 0) ? At<void*>(g_player, B.oCharCtl) : nullptr;
    if (cc && B.setColEnabled) { void* a[1] = { &on }; Invoke(B.setColEnabled, cc, a); }
}

static void NoclipTick(bool menuOpen)
{
    bool want = S.noclip && g_player;
    if (want != g_nocActive)
    {
        g_nocActive = want;
        SetCharCtl(!want);
        g_nocLast = GetTickCount64();
        g_lastValid = false;
        SetStatus(want ? "Ноуклип: WASD, Пробел — вверх, Ctrl — вниз, Shift — быстрее" : "Ноуклип выключен");
    }
    if (!g_nocActive) return;

    ULONGLONG now = GetTickCount64();
    float dt = std::min(0.1f, (now - g_nocLast) / 1000.f);
    g_nocLast = now;
    if (menuOpen || B.oCharRot < 0 || B.oCamRot < 0 || !B.setPos || !B.getTransform) return;

    float* qc = (float*)((char*)g_player + B.oCharRot);
    float* qp = (float*)((char*)g_player + B.oCamRot);
    float yaw = 2.f * std::atan2(qc[1], qc[3]);
    float pitch = 2.f * std::atan2(qp[0], qp[3]);          // + = вниз

    float fx = std::sin(yaw) * std::cos(pitch), fy = -std::sin(pitch), fz = std::cos(yaw) * std::cos(pitch);
    float rx = std::cos(yaw), rz = -std::sin(yaw);
    float mx = 0, my = 0, mz = 0;
    if (GetAsyncKeyState('W') & 0x8000) { mx += fx; my += fy; mz += fz; }
    if (GetAsyncKeyState('S') & 0x8000) { mx -= fx; my -= fy; mz -= fz; }
    if (GetAsyncKeyState('D') & 0x8000) { mx += rx; mz += rz; }
    if (GetAsyncKeyState('A') & 0x8000) { mx -= rx; mz -= rz; }
    if (GetAsyncKeyState(VK_SPACE) & 0x8000) my += 1.f;
    if (GetAsyncKeyState(VK_CONTROL) & 0x8000) my -= 1.f;
    float len = std::sqrt(mx * mx + my * my + mz * mz);
    if (len < 0.001f) return;
    float sp = (float)S.flySpeed * ((GetAsyncKeyState(VK_SHIFT) & 0x8000) ? 3.f : 1.f) * dt / len;

    float p[3];
    if (!GetPos(g_player, p)) return;
    float np[3] = { p[0] + mx * sp, p[1] + my * sp, p[2] + mz * sp };
    Object* tr = Invoke(B.getTransform, g_player, nullptr);
    if (tr) { void* a[1] = { np }; Invoke(B.setPos, tr, a); }
}

static void PlayerTick(bool menuOpen)
{
    if (!g_player) return;

    NoclipTick(menuOpen);
    if (S.speedOn && !g_nocActive) SpeedBoostTick(menuOpen);
    else g_lastValid = false;

    if (S.jumpOn) { ApplyPF(pfJump, S.jumpMul); g_jumpApplied = true; }
    else if (g_jumpApplied) { ApplyPF(pfJump, 1); g_jumpApplied = false; }

    // бхоп: пока зажат пробел — каждый кадр просим прыжок (игра сама проверяет, на земле ли мы)
    if (S.bhop && !menuOpen && B.oJumpPeremes >= 0 && (GetAsyncKeyState(VK_SPACE) & 0x8000))
        At<bool>(g_player, B.oJumpPeremes) = true;
}

// ---- враги: кэш ----
static std::mutex g_espMx;
static std::vector<EspBox> g_esp;
static int g_lastEspMode = -1;
static std::vector<void*> g_enemies;
static std::unordered_set<void*> g_whInit;
static ULONGLONG g_lastEnemyRefresh = 0;

// ---- скелет врага: ищем кости по именам, запасной вариант — bounds рендерера ----
struct Rig { void* head = nullptr; void* chest = nullptr; void* hips = nullptr; bool boundsOk = false; };
static std::unordered_map<void*, Rig> g_rig;
static bool g_rigLogged = false;

static std::string StrOf(Object* s)
{
    std::string r;
    if (!s) return r;
    int len = *(int*)((char*)s + 8);
    const unsigned short* ch = (const unsigned short*)((char*)s + 12);
    for (int i = 0; i < len && i < 80; i++) r.push_back(ch[i] < 128 ? (char)std::tolower(ch[i]) : '?');
    return r;
}

static bool Has(const std::string& s, const char* sub) { return s.find(sub) != std::string::npos; }

static Rig& RigFor(void* en)
{
    auto it = g_rig.find(en);
    if (it != g_rig.end()) return it->second;
    Rig r;
    if (B.getTransform && B2.objGetName && B2.trChildCount && B2.trGetChild)
    {
        Object* root = Invoke(B.getTransform, en, nullptr);
        std::vector<std::pair<void*, int>> q;
        if (root) q.push_back({ root, 0 });
        int chestPrio = 99, logged = 0;
        bool logIt = !g_rigLogged;
        for (size_t qi = 0; qi < q.size() && q.size() < 500; qi++)
        {
            void* t = q[qi].first; int d = q[qi].second;
            std::string nm = StrOf(Invoke(B2.objGetName, t, nullptr));
            if (logIt && logged < 160) { Log("rig d=%d '%s'", d, nm.c_str()); logged++; }
            if (!r.head && Has(nm, "head") && !Has(nm, "top") && !Has(nm, "end") && !Has(nm, "hair") &&
                !Has(nm, "helmet") && !Has(nm, "nub"))
                r.head = t;
            if (!r.hips && (Has(nm, "hips") || Has(nm, "pelvis"))) r.hips = t;
            int prio = Has(nm, "chest") ? 0 : Has(nm, "spine2") ? 1 : Has(nm, "spine1") ? 2 : Has(nm, "spine") ? 3 : 99;
            if (prio < chestPrio) { chestPrio = prio; r.chest = t; }
            if (d < 14)
            {
                int n = UnboxAs<int>(Invoke(B2.trChildCount, t, nullptr), 0);
                for (int i = 0; i < n && i < 40; i++)
                {
                    void* a[1] = { &i };
                    Object* c = Invoke(B2.trGetChild, t, a);
                    if (c) q.push_back({ c, d + 1 });
                }
            }
        }
        if (logIt) { g_rigLogged = true; Log("rig: nodes=%d head=%p chest=%p hips=%p", (int)q.size(), r.head, r.chest, r.hips); }
    }
    return g_rig.emplace(en, r).first->second;
}

static bool GetBoundsTop(void* en, float c[3], float& top, float& bottom)
{
    if (!B2.getCompInChildren || !B2.getBounds || !B2.typeRenderer) return false;
    bool inc = false;
    void* a[2] = { B2.typeRenderer, &inc };
    Object* rend = Invoke(B2.getCompInChildren, en, a);
    if (!rend) return false;
    Object* b = Invoke(B2.getBounds, rend, nullptr);
    if (!b) return false;
    float* f = (float*)il2cpp_object_unbox(b);      // center xyz, extents xyz
    c[0] = f[0]; c[1] = f[1]; c[2] = f[2];
    top = f[1] + f[4]; bottom = f[1] - f[4];
    return true;
}

// точка прицеливания: part 0 голова, 1 тело, 2 ноги
static bool GetAimPoint(void* en, int part, float out[3])
{
    float pos[3];
    if (!GetPos(en, pos)) return false;
    float H = (float)S.enemyHeight;
    Rig& r = RigFor(en);
    if (part == 0)
    {
        if (r.head && GetPos(r.head, out)) { out[1] += (float)S.aimHeadOffset; return true; }
        float c[3], top, bot;
        if (GetBoundsTop(en, c, top, bot)) { out[0] = c[0]; out[1] = top - 0.12f; out[2] = c[2]; return true; }
        out[0] = pos[0]; out[1] = pos[1] + 0.86f * H; out[2] = pos[2];
        return true;
    }
    if (part == 1)
    {
        float a[3], b[3];
        if (r.chest && GetPos(r.chest, out)) return true;
        if (r.head && r.hips && GetPos(r.head, a) && GetPos(r.hips, b))
        { for (int i = 0; i < 3; i++) out[i] = (a[i] + b[i]) * 0.5f; return true; }
        out[0] = pos[0]; out[1] = pos[1] + 0.60f * H; out[2] = pos[2];
        return true;
    }
    out[0] = pos[0]; out[1] = pos[1] + 0.25f; out[2] = pos[2];
    return true;
}

static bool IsAlive(void* en);

// ---- отслеживание убийств: если игра не дала награду, дозачисляем ----
static std::unordered_map<void*, bool> g_wasAlive;
static int       g_pendKills = 0;
static ULONGLONG g_pendDeadline = 0;
static int       g_baseGold = -1, g_baseExp = -1;

static void RewardWatchTick(ULONGLONG now)
{
    if (!g_rewardOn || !S.rewardBackup) { g_wasAlive.clear(); g_pendKills = 0; return; }

    std::unordered_set<void*> cur(g_enemies.begin(), g_enemies.end());
    int kills = 0;
    for (auto it = g_wasAlive.begin(); it != g_wasAlive.end();)
    {
        bool gone = cur.find(it->first) == cur.end();
        bool dead = !gone && B.oHealth >= 0 && At<int>(it->first, B.oHealth) <= 0;
        if (gone || dead) { kills++; it = g_wasAlive.erase(it); } else ++it;
    }
    for (void* en : g_enemies)
        if (IsAlive(en) && B.oHealth >= 0 && At<int>(en, B.oHealth) > 0) g_wasAlive[en] = true;

    if (kills > 0)
    {
        g_pendKills += kills;
        g_pendDeadline = now + 1200;
        Log("kill detected x%d (pending %d), base gold=%d exp=%d", kills, g_pendKills, g_baseGold, g_baseExp);
    }
    if (g_pendKills == 0)
    {
        // база — значения ДО убийства
        g_baseGold = PrefGet("GoldCount", 0);
        g_baseExp  = PrefGet("LevelProgress", -1);
        return;
    }
    if (now < g_pendDeadline) return;

    int curGold = PrefGet("GoldCount", 0), curExp = PrefGet("LevelProgress", -1);
    long long wantG = (long long)g_pendKills * g_rewardMoney, wantE = (long long)g_pendKills * g_rewardExp;
    long long gotG = (long long)curGold - g_baseGold, gotE = (curExp >= 0 && g_baseExp >= 0) ? (long long)curExp - g_baseExp : wantE;
    Log("kill check: kills=%d gold got=%lld want=%lld | exp got=%lld want=%lld", g_pendKills, gotG, wantG, gotE, wantE);
    bool changed = false;
    if (g_baseGold >= 0 && gotG < wantG)
    {
        long long v = std::min<long long>((long long)curGold + (wantG - std::max(0ll, gotG)), 2147483647ll);
        PrefSet("GoldCount", (int)v); changed = true;
    }
    if (g_rewardExp > 0 && curExp >= 0 && g_baseExp >= 0 && gotE < wantE)
    {
        long long v = std::min<long long>((long long)curExp + (wantE - std::max(0ll, gotE)), 2147483647ll);
        PrefSet("LevelProgress", (int)v); changed = true;
    }
    if (changed) { PrefsSaveNow(); if (B.loadMoney) Invoke(B.loadMoney, nullptr, nullptr); Log("kill reward topped up"); }
    g_pendKills = 0;
    g_baseGold = PrefGet("GoldCount", 0);
    g_baseExp  = PrefGet("LevelProgress", -1);
}

static void RefreshEnemies()
{
    g_enemies.clear();
    void* arr = FindAll(B.typeEnemy);
    int n = ArrayLen(arr);
    for (int i = 0; i < n; i++)
    {
        void* en = ArrayAt(arr, i);
        if (en) g_enemies.push_back(en);
    }
    if (g_whInit.size() > 1024) g_whInit.clear();
    // чистим кэш скелетов от исчезнувших врагов
    if (g_rig.size() > 64)
    {
        std::unordered_set<void*> cur(g_enemies.begin(), g_enemies.end());
        for (auto it = g_rig.begin(); it != g_rig.end();) { if (!cur.count(it->first)) it = g_rig.erase(it); else ++it; }
    }
    g_lastEnemyRefresh = GetTickCount64();
    std::lock_guard<std::mutex> l(g_mx);
    g_snap.enemies = n;
}

static void EnsureEnemies(ULONGLONG maxAgeMs)
{
    if (GetTickCount64() - g_lastEnemyRefresh >= maxAgeMs) RefreshEnemies();
}

static void DoWallhackOff()
{
    { std::lock_guard<std::mutex> l(g_espMx); g_esp.clear(); }
    g_lastEspMode = -1;
    RefreshEnemies();
    for (void* en : g_enemies)
        if (B.oWallHack >= 0) SetEnabled(At<void*>(en, B.oWallHack), false);
    g_whInit.clear();
}

static bool W2S(void* cam, const float w[3], int sw, int sh, float out[2])
{
    if (!cam || !B.w2s) return false;
    float v[3] = { w[0], w[1], w[2] };
    void* a[1] = { v };
    Object* r = Invoke(B.w2s, cam, a);
    if (!r) return false;
    float* o = (float*)il2cpp_object_unbox(r);
    if (o[2] <= 0.05f) return false;          // позади камеры
    out[0] = o[0];
    out[1] = (float)sh - o[1];                // Unity: y снизу
    (void)sw;
    return true;
}

static void EspTick()
{
    std::vector<EspBox> out;
    void* cam = (g_player && B.oCamera >= 0) ? At<void*>(g_player, B.oCamera) : nullptr;
    int sw = B.scrW ? UnboxAs<int>(Invoke(B.scrW, nullptr, nullptr), 0) : 0;
    int sh = B.scrH ? UnboxAs<int>(Invoke(B.scrH, nullptr, nullptr), 0) : 0;
    if (cam && sw > 0 && sh > 0)
    {
        float H = S.enemyHeight;
        for (void* en : g_enemies)
        {
            if (!IsAlive(en)) continue;
            int hp = (B.oHealth >= 0) ? At<int>(en, B.oHealth) : 1;
            float t[3];
            if (!GetPos(en, t)) continue;
            float top[3] = { t[0], t[1] + H, t[2] };
            float f2[2], t2[2];
            if (!W2S(cam, t, sw, sh, f2) || !W2S(cam, top, sw, sh, t2)) continue;
            float h = f2[1] - t2[1];
            if (h < 4.f || h > sh * 3.f) continue;
            float w = h * 0.42f;
            float hf = 1.0f;
            if (B.oHealth >= 0) {
                float all = (B.oHealthAll >= 0) ? At<float>(en, B.oHealthAll) : 0.f;
                if (all > 1.f) hf = std::max(0.f, std::min(1.f, hp / all));
            }
            out.push_back({ f2[0] - w * 0.5f, t2[1], w, h, hf });
        }
    }
    std::lock_guard<std::mutex> l(g_espMx);
    g_esp.swap(out);
}

std::vector<EspBox> Esp() { std::lock_guard<std::mutex> l(g_espMx); return g_esp; }
bool EspWanted() { int m = S.espMode; return S.wallhack && (m == 1 || m == 2); }

static void WallhackTick()
{
    int mode = S.espMode;
    bool chams = (mode == 0 || mode == 2);
    if (B.oWallHack >= 0 && g_lastEspMode != mode)
    {
        if (!chams)   // переключились на боксы — гасим контуры
            for (void* en : g_enemies) SetEnabled(At<void*>(en, B.oWallHack), false);
        g_lastEspMode = mode;
    }
    if (chams && B.oWallHack >= 0)
    {
        for (void* en : g_enemies)
        {
            void* ol = At<void*>(en, B.oWallHack);
            if (!ol) continue;
            if (g_whInit.insert(ol).second)
            {
                if (B.olMode)  { int m = 0; void* a[1] = { &m }; Invoke(B.olMode, ol, a); }
                if (B.olWidth) { float w = 4.0f; void* a[1] = { &w }; Invoke(B.olWidth, ol, a); }
                if (B.olColor) { float c[4] = { 1.f, 0.15f, 0.15f, 1.f }; void* a[1] = { c }; Invoke(B.olColor, ol, a); }
            }
            SetEnabled(ol, true);
        }
    }
    if (mode == 1 || mode == 2) EspTick();
    else { std::lock_guard<std::mutex> l(g_espMx); g_esp.clear(); }
}

// ---- убрать всех ботов ----
static int RemoveBots()
{
    if (!B.getGO) return 0;
    RefreshEnemies();
    int n = 0;
    for (void* en : g_enemies)
    {
        Object* go = Invoke(B.getGO, en, nullptr);
        if (!go) continue;
        if (B.objDestroy) { void* a[1] = { go }; Invoke(B.objDestroy, nullptr, a); n++; }
        else if (B.goSetActive) { bool off = false; void* a[1] = { &off }; Invoke(B.goSetActive, go, a); n++; }
    }
    g_enemies.clear(); g_wasAlive.clear(); g_pendKills = 0;
    { std::lock_guard<std::mutex> l(g_espMx); g_esp.clear(); }
    if (B.fCountEnemy)
    {
        uint8_t zero[8]; EncodeInt(0, zero);
        il2cpp_field_static_set_value(B.fCountEnemy, zero);
    }
    return n;
}

static void DoRemoveBots()
{
    int n = RemoveBots();
    SetStatus("Ботов убрано: " + std::to_string(n));
}

// ---- убрать ботов / телепорт ----
static void DoKillAllBots()
{
    RefreshEnemies();
    int n = 0;
    for (void* en : g_enemies)
    {
        if (B.oHealth >= 0) At<int>(en, B.oHealth) = 0;
        if (B.getGO && B.destroyObj)
        {
            Object* go = Invoke(B.getGO, en, nullptr);
            if (go) { void* a[1] = { go }; Invoke(B.destroyObj, nullptr, a); n++; }
        }
    }
    if (B.fCountEnemy) { uint8_t z[8]; EncodeInt(0, z); il2cpp_field_static_set_value(B.fCountEnemy, z); }
    g_enemies.clear(); g_whInit.clear(); g_wasAlive.clear(); g_pendKills = 0;
    { std::lock_guard<std::mutex> l(g_espMx); g_esp.clear(); }
    SetStatus("Ботов убрано: " + std::to_string(n));
}

// встать рядом с ботом (S.tpDist м от него, на линии «бот → игрок») и повернуться к нему лицом
static bool TeleportTo(void* en)
{
    if (!g_player) RefreshPlayer();
    if (!g_player || !B.getTransform || !B.setPos) { SetStatus("Игрок не найден (зайди в игровую сцену)"); return false; }
    float e[3], p[3];
    if (!GetPos(en, e) || !GetPos(g_player, p)) { SetStatus("Не удалось получить позицию"); return false; }

    float dx = p[0] - e[0], dz = p[2] - e[2];
    float len = std::sqrt(dx * dx + dz * dz);
    if (len < 0.01f) { dx = 1; dz = 0; len = 1; }
    float dist = std::max(0.8f, (float)S.tpDist);
    float dest[3] = { e[0] + dx / len * dist, e[1] + 0.2f, e[2] + dz / len * dist };

    Object* tr = Invoke(B.getTransform, g_player, nullptr);
    if (!tr) { SetStatus("Transform не найден"); return false; }
    void* cc = (B.oCharCtl >= 0) ? At<void*>(g_player, B.oCharCtl) : nullptr;
    if (cc && B.setColEnabled) { bool f = false; void* a[1] = { &f }; Invoke(B.setColEnabled, cc, a); }   // CharacterController перебивает позицию
    void* a[1] = { dest };
    Invoke(B.setPos, tr, a);
    if (cc && B.setColEnabled) { bool t = true; void* b2[1] = { &t }; Invoke(B.setColEnabled, cc, b2); }

    // лицом к боту
    if (B.oCharRot >= 0)
    {
        float yaw = std::atan2(-dx, -dz);
        float* qc = (float*)((char*)g_player + B.oCharRot);
        qc[0] = 0; qc[1] = std::sin(yaw * 0.5f); qc[2] = 0; qc[3] = std::cos(yaw * 0.5f);
    }
    g_lastValid = false;      // не считать прыжок позиции «ходьбой» для ускорения
    return true;
}

static void DoTeleportToBot()
{
    RefreshEnemies();
    std::vector<void*> alive;
    for (void* en : g_enemies)
        if (IsAlive(en)) alive.push_back(en);
    if (alive.empty()) { SetStatus("Ботов на карте нет"); return; }
    if (TeleportTo(alive[rand() % alive.size()]))
        SetStatus("Телепорт к боту (из " + std::to_string((int)alive.size()) + ")");
}

// постоянный режим: каждый новый бот -> сразу к нему
static std::unordered_set<void*> g_tpSeen;
static bool g_tpWasOn = false;

static void AutoTpTick()
{
    if (!S.autoTpBot) { g_tpWasOn = false; g_tpSeen.clear(); return; }
    EnsureEnemies(100);
    std::unordered_set<void*> aliveNow;
    void* fresh = nullptr;
    for (void* en : g_enemies)
    {
        if (!IsAlive(en)) continue;
        aliveNow.insert(en);
        if (g_tpWasOn && !g_tpSeen.count(en)) fresh = en;     // последний из новых
    }
    g_tpSeen.swap(aliveNow);          // заодно забываем исчезнувших
    g_tpWasOn = true;
    if (fresh && TeleportTo(fresh)) SetStatus("Авто-телепорт к новому боту");
}

// ---- босс: признаки, хуки урона и «смерти» ----
static std::unordered_set<void*> g_bossGOs;      // GameObject-ы боссов, которых создали мы
static void* g_bossClone = nullptr;              // скрытая копия босса, переживает смену сцены

static bool IsBoss(void* en)
{
    if (!en) return false;
    void* boss = nullptr;
    if (B.fPolyEnemy) il2cpp_field_static_get_value(B.fPolyEnemy, &boss);
    if (en == boss) return true;
    if (!g_bossGOs.empty() && B.getGO)
    {
        Object* go = Invoke(B.getGO, en, nullptr);
        if (go && g_bossGOs.count(go)) return true;
    }
    return false;
}

typedef void(__cdecl* HitEnemyFn)(void* self, float dmg, int type, void* enemy, void* mi);
static HitEnemyFn g_origHit = nullptr;

static void __cdecl hkHitEnemy(void* self, float dmg, int type, void* enemy, void* mi)
{
    if (S.bossAnyWeapon && enemy && IsBoss(enemy))
    {
        int before = (B.oHealth >= 0) ? At<int>(enemy, B.oHealth) : 0;
        float d = std::max(dmg, (float)S.bossMinDmg);
        g_origHit(self, d, type, enemy, mi);
        int after = (B.oHealth >= 0) ? At<int>(enemy, B.oHealth) : 0;
        static int logN = 0;
        if (logN++ < 20) Log("boss hit: dmg %.1f->%.1f type=%d hp %d->%d", dmg, d, type, before, after);
        // игра могла проигнорировать это оружие — тогда снимаем здоровье сами
        if (B.oHealth >= 0 && before > 0 && after >= before)
            At<int>(enemy, B.oHealth) = (d >= (float)before) ? 0 : before - (int)d;
        return;
    }
    g_origHit(self, dmg, type, enemy, mi);
}

typedef void(__cdecl* TrigFn)(void* self, void* collider, void* mi);
static TrigFn g_origTrig = nullptr;

static void __cdecl hkTriggerLose(void* self, void* collider, void* mi)
{
    if (S.god) return;                      // бессмертие: триггер поражения не срабатывает
    g_origTrig(self, collider, mi);
}

static bool InstallGameHooks()
{
    bool ok = true;
    if (B2.hitEnemy)
    {
        void* t = MethodPointer(B2.hitEnemy);
        ok &= (MH_CreateHook(t, (void*)&hkHitEnemy, (void**)&g_origHit) == MH_OK && MH_EnableHook(t) == MH_OK);
    }
    else { Log("HitEnemy не найден — «любое оружие» недоступно"); ok = false; }
    if (B2.trigEnter)
    {
        void* t = MethodPointer(B2.trigEnter);
        ok &= (MH_CreateHook(t, (void*)&hkTriggerLose, (void**)&g_origTrig) == MH_OK && MH_EnableHook(t) == MH_OK);
    }
    else { Log("TriggerLose.OnTriggerEnter не найден — бессмертие частично недоступно"); ok = false; }
    Log("game hooks (HitEnemy/TriggerLose): %s", ok ? "ok" : "partial");
    return ok;
}

// ---- босс (Enemy2Prefab полигона) ----
static void SetGOActive(void* go, bool on)
{
    if (!go || !B2.goSetActive2) return;
    void* a[1] = { &on };
    Invoke(B2.goSetActive2, go, a);
}

// скрытая копия босса: создаём в полигоне и не даём сцене её уничтожить
static void CacheBossClone(void* prefab)
{
    if (g_bossClone || !prefab || !B2.instGO || !B2.dontDestroy) return;
    float pos[3] = { 0, -5000.f, 0 }, rot[4] = { 0, 0, 0, 1 };
    void* a[3] = { prefab, pos, rot };
    Object* c = Invoke(B2.instGO, nullptr, a);
    if (!c) return;
    SetGOActive(c, false);
    void* d[1] = { c };
    Invoke(B2.dontDestroy, nullptr, d);
    g_bossClone = c;
    Log("boss clone cached: %p", c);
}

// запасной путь: ищем в памяти любой GameObject с EnemyController, похожий на босса
static void* FindBossInMemory()
{
    if (!B2.findAllRes || !B2.typeGO || !B2.goGetComp) return nullptr;
    void* a[1] = { B2.typeGO };
    Object* arr = Invoke(B2.findAllRes, nullptr, a);
    int n = ArrayLen(arr);
    void* best = nullptr;
    for (int i = 0; i < n; i++)
    {
        void* go = ArrayAt(arr, i);
        if (!go) continue;
        void* t[1] = { B.typeEnemy };
        Object* ec = Invoke(B2.goGetComp, go, t);
        if (!ec) continue;
        std::string nm = StrOf(Invoke(B2.objGetName, go, nullptr));
        float hp = (B.oHealthAll >= 0) ? At<float>(ec, B.oHealthAll) : 0.f;
        Log("enemy-like GO %p '%s' healthAll=%.0f", go, nm.c_str(), hp);
        if (Has(nm, "enemy2") || Has(nm, "boss") || Has(nm, "shur")) best = go;
    }
    return best;
}

static void DoSpawnBoss()
{
    void* poly = nullptr;
    if (B.fPolygonObj) il2cpp_field_static_get_value(B.fPolygonObj, &poly);
    if (!g_player) RefreshPlayer();

    float pos[3] = { 0, 0, 0 };
    bool havePos = false;
    void* prefab = nullptr;

    if (poly)
    {
        prefab = (B.oEnemy2Prefab >= 0) ? At<void*>(poly, B.oEnemy2Prefab) : nullptr;
        if (prefab) CacheBossClone(prefab);
        void* arr = (B.oSpawners >= 0) ? At<void*>(poly, B.oSpawners) : nullptr;
        int n = ArrayLen(arr);
        if (n > 0 && B.goGetTransform && B.getPos)
        {
            void* sp = ArrayAt(arr, rand() % n);
            Object* tr = sp ? Invoke(B.goGetTransform, sp, nullptr) : nullptr;
            Object* pv = tr ? Invoke(B.getPos, tr, nullptr) : nullptr;
            if (pv) { std::memcpy(pos, il2cpp_object_unbox(pv), 12); havePos = true; }
        }
    }
    else
    {
        // другая карта: берём сохранённую копию, иначе ищем в памяти
        prefab = g_bossClone ? g_bossClone : FindBossInMemory();
        if (!prefab)
        {
            SetStatus("Босс: на этой карте копии нет. Один раз вызови босса в полигоне (копия сохранится), потом выходи на другую карту");
            return;
        }
    }
    if (!prefab || !B.instantiate) { SetStatus("Босс: префаб не найден (см. GoldMod.log, строка bind5)"); return; }

    if (!havePos)
    {
        float p[3];
        if (!g_player || !GetPos(g_player, p)) { SetStatus("Босс: не удалось определить место спавна (нет игрока)"); return; }
        // 8 м перед игроком по направлению взгляда
        float yaw = 0.f;
        if (B.oCharRot >= 0) { float* q = (float*)((char*)g_player + B.oCharRot); yaw = 2.f * std::atan2(q[1], q[3]); }
        pos[0] = p[0] + std::sin(yaw) * 8.f; pos[1] = p[1] + 0.3f; pos[2] = p[2] + std::cos(yaw) * 8.f;
    }

    float rot[4] = { 0, 0, 0, 1 };
    void* a[3] = { prefab, pos, rot };
    Object* obj = Invoke(B.instantiate, nullptr, a);
    Log("boss spawn: poly=%p prefab=%p pos=%.1f,%.1f,%.1f -> %p", poly, prefab, pos[0], pos[1], pos[2], obj);
    if (!obj) { SetStatus("Босс: Instantiate не удался"); return; }
    SetGOActive(obj, true);               // копия хранится выключенной
    g_bossGOs.insert(obj);
    if (g_bossGOs.size() > 32) g_bossGOs.clear(), g_bossGOs.insert(obj);
    SetStatus(poly ? "Босс вызван" : "Босс вызван на этой карте (если он стоит — на карте может не быть NavMesh, см. лог)");
}

// ---- аим ----
static const float kRad2Deg = 57.2957795f, kDeg2Rad = 0.0174532925f;
static float WrapDeg(float a) { while (a > 180.f) a -= 360.f; while (a < -180.f) a += 360.f; return a; }

static void AimTick()
{
    if (!g_player || B.oCamera < 0 || B.oCharRot < 0 || B.oCamRot < 0 || B.oHealth < 0) return;
    if (!S.aimAlways && !(GetAsyncKeyState(VK_RBUTTON) & 0x8000)) return;

    void* cam = At<void*>(g_player, B.oCamera);
    float p[3];
    if (!GetPos(cam, p)) return;

    float* qc = (float*)((char*)g_player + B.oCharRot);   // x y z w
    float* qp = (float*)((char*)g_player + B.oCamRot);
    float yawCur   = 2.f * std::atan2(qc[1], qc[3]) * kRad2Deg;
    float pitchCur = 2.f * std::atan2(qp[0], qp[3]) * kRad2Deg;

    float bestScore = 1e9f, bestDy = 0, bestDp = 0;
    bool found = false;
    float fov = S.aimFov;
    int part = S.aimPart; if (part < 0 || part > 2) part = 0;
    for (void* en : g_enemies)
    {
        if (!IsAlive(en)) continue;
        float t[3];
        if (!GetAimPoint(en, part, t)) continue;
        float dx = t[0] - p[0], dy = t[1] - p[1], dz = t[2] - p[2];
        float hd = std::sqrt(dx * dx + dz * dz), len = std::sqrt(hd * hd + dy * dy);
        if (len < 0.2f) continue;
        float yawT = std::atan2(dx, dz) * kRad2Deg;
        float pitchT = -std::atan2(dy, hd) * kRad2Deg;     // в Unity +X = вниз
        float dY = WrapDeg(yawT - yawCur), dP = pitchT - pitchCur;
        float score = std::sqrt(dY * dY + dP * dP);
        if (score > fov || score >= bestScore) continue;
        bestScore = score; bestDy = dY; bestDp = dP; found = true;
    }
    if (!found) return;

    float s = std::max(0.02f, std::min(1.0f, (float)S.aimSmooth));
    float yaw = yawCur + bestDy * s, pitch = pitchCur + bestDp * s;
    float mn = -89.f, mx = 89.f;
    if (B.oClampV >= 0 && At<bool>(g_player, B.oClampV) && B.oMinX >= 0 && B.oMaxX >= 0)
    { mn = At<float>(g_player, B.oMinX); mx = At<float>(g_player, B.oMaxX); }
    pitch = std::max(mn, std::min(mx, pitch));

    qc[0] = 0; qc[1] = std::sin(yaw * kDeg2Rad * 0.5f); qc[2] = 0; qc[3] = std::cos(yaw * kDeg2Rad * 0.5f);
    qp[0] = std::sin(pitch * kDeg2Rad * 0.5f); qp[1] = 0; qp[2] = 0; qp[3] = std::cos(pitch * kDeg2Rad * 0.5f);
}

// ---- достижения ----
static void DoUnlockAchievements()
{
    void* ctl = nullptr;
    if (B.fAchObj) il2cpp_field_static_get_value(B.fAchObj, &ctl);
    if (!ctl || B.oAchives < 0) { SetStatus("Открой экран достижений в игре и нажми ещё раз"); return; }
    void* arr = At<void*>(ctl, B.oAchives);
    int n = ArrayLen(arr), done = 0;
    for (int i = 0; i < n; i++)
    {
        void* a = ArrayAt(arr, i);
        if (!a) continue;
        void* counts = (B.oAchCountMain >= 0) ? At<void*>(a, B.oAchCountMain) : nullptr;
        int levels = ArrayLen(counts);
        if (levels <= 0) continue;
        int last = *(int*)((char*)counts + 16 + 4 * (levels - 1));
        int num = (B.oAchNumber >= 0) ? At<int>(a, B.oAchNumber) : i;
        if (B.oAchFinish >= 0) At<int>(a, B.oAchFinish) = last;
        if (B.oAchLevel >= 0)  At<int>(a, B.oAchLevel)  = levels - 1;
        PrefSet(("AchiveSaveLevel_" + std::to_string(num)).c_str(), levels - 1);
        Log("achive #%d (idx %d): levels=%d last=%d", num, i, levels, last);
        done++;
    }
    PrefsSaveNow();
    SetStatus("Достижения: обработано " + std::to_string(done) + ". Перезайди в экран достижений (см. GoldMod.log).");
}

// ---- все предметы ----
static void DoGiveAllItems()
{
    void* inv = nullptr;
    if (B.fInvObj) il2cpp_field_static_get_value(B.fInvObj, &inv);
    if (!inv || B.oAllItems < 0 || B.oItemNumber < 0) { SetStatus("Открой инвентарь в меню игры и нажми ещё раз"); return; }
    void* arr = At<void*>(inv, B.oAllItems);
    int n = ArrayLen(arr);
    if (n <= 0) { SetStatus("Каталог предметов пуст"); return; }

    std::set<int> have;
    int cnt = PrefGet("ItemSaveCount", 0);
    for (int k = 0; k < cnt; k++) have.insert(PrefGet(("ItemId_" + std::to_string(k)).c_str(), -1));

    int added = 0;
    for (int i = 0; i < n; i++)
    {
        void* it = ArrayAt(arr, i);
        if (!it) continue;
        int id = At<int>(it, B.oItemNumber);
        if (have.count(id)) continue;
        have.insert(id);
        PrefSet(("ItemId_" + std::to_string(cnt)).c_str(), id);
        PrefSet(("ItemIsNewInt_" + std::to_string(cnt)).c_str(), 0);
        cnt++; added++;
    }
    PrefSet("ItemSaveCount", cnt);
    PrefsSaveNow();
    Log("give items: catalog=%d added=%d total=%d", n, added, cnt);
    SetStatus("Предметов добавлено: " + std::to_string(added) + " (всего " + std::to_string(cnt) + "). Перезайди в игру.");
}

// ---- ключ ----
static void DoWriteKey(std::string key, std::string value, int type)
{
    if (key.empty()) { SetStatus("Пустой ключ"); return; }
    if (type == 2)
    {
        if (!B.ppSetStr) { SetStatus("PlayerPrefs.SetString не найден"); return; }
        void* a[2] = { il2cpp_string_new(key.c_str()), il2cpp_string_new(value.c_str()) };
        Invoke(B.ppSetStr, nullptr, a);
    }
    else
    {
        long long v = std::max(-2147483648ll, std::min(2147483647ll, _strtoi64(value.c_str(), nullptr, 10)));
        if (type == 0) PrefSet(key.c_str(), (int)v);
        else if (B.ppSetInt) { int iv = (int)v; void* a[2] = { il2cpp_string_new(key.c_str()), &iv }; Invoke(B.ppSetInt, nullptr, a); }
        else { SetStatus("PlayerPrefs.SetInt не найден"); return; }
    }
    PrefsSaveNow();
    if (B.loadMoney) Invoke(B.loadMoney, nullptr, nullptr);
    SetStatus("Записано: " + key + " = " + value);
}

static void DoHardClean()
{
    if (!B.ppDeleteAll) { SetStatus("PlayerPrefs.DeleteAll не найден"); return; }
    Invoke(B.ppDeleteAll, nullptr, nullptr);
    PrefsSaveNow();
    SetStatus("Все сохранения PlayerPrefs удалены. Перезапусти игру.");
}

// ---- меню: курсор + блокировка управления ----
static bool g_menuOpen = false;
static int  g_prevLock = 1;
static bool g_prevControl = true;
static void* g_ctlPlayer = nullptr;

static void SetCursor(int lockState, bool visible)
{
    if (B.setLock)    { void* a[1] = { &lockState }; Invoke(B.setLock, nullptr, a); }
    if (B.setVisible) { void* a[1] = { &visible };   Invoke(B.setVisible, nullptr, a); }
}

static void DoMenuOpen(bool open)
{
    if (open == g_menuOpen) return;
    g_menuOpen = open;
    if (open)
    {
        g_prevLock = B.getLock ? UnboxAs<int>(Invoke(B.getLock, nullptr, nullptr), 1) : 1;
        g_ctlPlayer = (B.oControl >= 0) ? FindOne(B.typePlayer) : nullptr;
        if (g_ctlPlayer && S.lockControls)
        {
            g_prevControl = At<bool>(g_ctlPlayer, B.oControl);
            At<bool>(g_ctlPlayer, B.oControl) = false;
        }
        SetCursor(0, true);
        DoGoldRead();
    }
    else
    {
        if (g_ctlPlayer && S.lockControls) At<bool>(g_ctlPlayer, B.oControl) = g_prevControl;
        g_ctlPlayer = nullptr;
        SetCursor(g_prevLock, g_prevLock == 0);
    }
}

// ---- каждый кадр ----
static uint8_t g_encMax[8];
static bool    g_encMaxInit = false;

static void FrameTick()
{
    std::vector<std::function<void()>> q;
    { std::lock_guard<std::mutex> l(g_qmx); q.swap(g_queue); }
    for (auto& f : q) { try { f(); } catch (...) { Log("exception in command"); } }

    if (g_menuOpen) SetCursor(0, true);

    static ULONGLONG nextPlayer = 0;
    ULONGLONG now = GetTickCount64();

    static bool f6Prev = false;
    bool f6 = (GetAsyncKeyState(VK_F6) & 0x8000) != 0;
    if (f6 && !f6Prev) DoSpawnBoss();
    f6Prev = f6;

    static ULONGLONG nextReward = 0;
    if (now >= nextReward) { nextReward = now + 200; RewardTick(); }
    if (now >= nextPlayer) { nextPlayer = now + 250; RefreshPlayer(); }
    PlayerTick(g_menuOpen);

    if (S.wallhack || S.aim)
    {
        EnsureEnemies(200);
        if (S.wallhack) WallhackTick();
        if (S.aim && !g_menuOpen) AimTick();
    }

    if (g_rewardOn && S.rewardBackup)
    {
        static ULONGLONG nextWatch = 0;
        if (now >= nextWatch) { nextWatch = now + 100; EnsureEnemies(100); RewardWatchTick(now); }
    }
    else if (!g_wasAlive.empty()) { g_wasAlive.clear(); g_pendKills = 0; }

    AutoTpTick();

    if (S.autoKillBots)
    {
        static ULONGLONG nextKill = 0;
        if (now >= nextKill) { nextKill = now + 300; RemoveBots(); }
    }

    if (S.raiseBotMax && B.fCountEnemyMax)
    {
        if (!g_encMaxInit) { EncodeInt(999, g_encMax); g_encMaxInit = true; }
        il2cpp_field_static_set_value(B.fCountEnemyMax, g_encMax);
    }
}

// ----------------------------------------------------------------------------------------
// хук RuntimeManager.Update (singleton FMOD, живёт всю игру, вызывается в главном потоке)
// ----------------------------------------------------------------------------------------
typedef void(__cdecl* UpdateFn)(void* self, void* mi);
static UpdateFn g_origUpdate = nullptr;

static void __cdecl hkUpdate(void* self, void* mi)
{
    g_origUpdate(self, mi);
    static bool inTick = false;
    if (inTick) return;
    inTick = true;
    try { FrameTick(); } catch (...) { Log("exception in FrameTick"); }
    inTick = false;
}

bool Init()
{
    if (!BindAll()) return false;
    SetupPF();

    void* target = MethodPointer(B.rmUpdate);
    if (!target) { Log("RuntimeManager.Update pointer is null"); return false; }

    if (MH_CreateHook(target, (void*)&hkUpdate, (void**)&g_origUpdate) != MH_OK ||
        MH_EnableHook(target) != MH_OK)
    {
        Log("MH hook RuntimeManager.Update failed");
        return false;
    }
    InstallGameHooks();
    { std::lock_guard<std::mutex> l(g_mx); g_snap.bound = true; g_snap.status = "Готово."; }
    Log("game hooks installed (Update @ %p)", target);
    return true;
}

// ----------------------------------------------------------------------------------------
// команды для UI
// ----------------------------------------------------------------------------------------
void CmdGoldSet(long long v)      { Post([=] { DoGoldSet(v); }); }
void CmdKillReward(int m, int e)  { Post([=] { DoKillReward(m, e); }); }
void CmdKillAllBots()             { Post([] { DoKillAllBots(); }); }
void CmdTeleportToBot()           { Post([] { DoTeleportToBot(); }); }
void CmdSpawnBoss()               { Post([] { DoSpawnBoss(); }); }
void CmdNoclipChanged()           { }
void CmdWallhackOff()             { Post([] { DoWallhackOff(); }); }
void CmdRemoveBots()              { Post([] { DoRemoveBots(); }); }
void CmdRestorePlayer()           { Post([] { DoRestorePlayer(); }); }
void CmdMenuOpen(bool open)       { Post([=] { DoMenuOpen(open); }); }
void CmdUnlockAchievements()      { Post([] { DoUnlockAchievements(); }); }
void CmdGiveAllItems()            { Post([] { DoGiveAllItems(); }); }
void CmdWriteKey(const std::string& k, const std::string& v, int t) { Post([=] { DoWriteKey(k, v, t); }); }
void CmdHardClean()               { Post([] { DoHardClean(); }); }

} // namespace game
