# GoldCheat (бывший GoldMod) — standknife

Структура: `.github/workflows/build.yml` (сборка в GitHub Actions), `bin/` (сюда падает DLL), `src/` (код), `third_party/` (imgui, minhook), `build.bat` (локальная сборка), `CMakeLists.txt`.

## Сборка
- GitHub: залей папку в репозиторий, вкладка Actions, запуск «Build GoldCheat» (или просто push). DLL будет в артефакте `GoldCheat` (x86).
- Локально: `build.bat` (Visual Studio 2022, x86).

Инжектить как раньше. Меню: **Home**. Лог: `GoldCheat.log` рядом с DLL.

## Код
- `src/il2.h` — обёртка il2cpp (всё ищется по именам, оффсеты не зашиты)
- `src/game.h` — логика: валюта/опыт/награды, достижения, аим, ESP, бхоп, ноклип, босс, инспектор сцены
- `src/main.cpp` — DllMain, хуки (Present, HitEnemy, TriggerLose, RuntimeManager.Update), ImGui UI

## Изменения
- Аим по тегам коллайдеров EnemyHead/Body/Legs (баг «голова → ноги» исправлен), без режима «Всегда»
- Вкладка ESP (WH + Аим), вкладка «Сцена» (инспектор, ТП, координаты)
- «Количество» → «Голда», надпись GoldCheat, накрутка опыта, достижения по уровням, новый бхоп
- Убраны: нижняя «Убрать всех ботов», «Постоянно убирать», авто-ТП, дистанция, ТП к случайному боту

Код не компилировался в среде разработки: если сборка упадёт, пришли лог Actions.
