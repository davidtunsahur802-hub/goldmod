// game.h - привязки к игре standknife и вся логика чита. Выполняется в игровом потоке (хук RuntimeManager.Update),
// UI (поток рендера) общается с ней только через Cfg, снапшоты и очередь команд.
#pragma once
#include "il2.h"
#include <atomic>
#include <cmath>
#include <functional>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <algorithm>

// ---------------------------------------------------------------- конфиг (пишет UI, читает игровой поток)
struct Cfg {
    // валюта
    int goldSet = 100000;
    int expAdd = 10000;
    int levelSet = 10;
    int rewGold = 1000, rewExp = 9999;
    bool topUp = true;      // дозачислять разницу, если игра дала меньше
    bool rewHold = false;   // держать значения награды в игре
    // игрок
    bool bhop = false;
    bool fastWalk = false; float walkMul = 2.0f;
    bool god = false;
    bool noclip = false; float flySpeed = 10.0f;
    bool highJump = false; float jumpMul = 2.0f;
    // враги
    bool bossAny = false; int bossMinDmg = 100000;
    bool noLimit = false;
    // ESP
    bool wh = false; int whMode = 0; // 0 чамсы, 1 боксы, 2 оба
    bool espHealth = true; bool espLines = false;
    float enemyH = 1.65f, headFix = 0.07f;
    // аим (работает всегда, пока включён)
    bool aim = false; int aimPart = 0; // 0 голова, 1 тело, 2 ноги
    float aimSmooth = 0.35f; float aimFov = 60.0f;
    // опции
    bool blockInput = true; bool watermark = true;
    // инспектор
    bool sceneOnlyActive = false;                 // в списке только включённые объекты
    bool sceneLabels = false;                     // писать названия возле объектов в игре
    float labelDist = 40.f; int labelMax = 80;    // радиус и максимум подписей
    // размер ботов
    bool botScaleOn = false; V3 botScale{ 1.f, 1.f, 1.f };
    float headUp = 0.0f;                          // смещение цели аима по голове (вверх, м)
};
inline Cfg g_cfg;
inline std::atomic<bool> g_menuOpen{false};
inline std::atomic<bool> g_ready{false};

// ---------------------------------------------------------------- данные для UI
struct EspEnt { float x1, y1, x2, y2; int hp; bool hasHp; float sx, sy; };
struct SceneEnt { uint32_t h; std::string name; V3 pos; bool active; };
inline std::mutex g_mx;                     // защищает всё ниже
inline std::vector<EspEnt> g_esp;
inline float g_scrW = 1920, g_scrH = 1080;
inline std::string g_status = "Ожидание игры...";
inline std::string g_goldNow = "-", g_expNow = "-", g_lvlNow = "-";
inline int g_enemyCount = 0;
inline bool g_playerFound = false;
inline V3 g_playerPos{0, 0, 0};
inline std::vector<SceneEnt> g_scene;       // инспектор
inline unsigned g_sceneVer = 0;             // растёт при каждом обновлении списка
struct Ray3 { V3 o, d; };
struct BotEnt { uintptr_t id; std::string name; int hp; V3 pos; V3 scale; };
inline std::vector<BotEnt> g_bots;
inline std::atomic<bool> g_wantBots{ false };                 // UI просит обновлять список ботов
inline std::atomic<bool> g_picking{ false }, g_pickReq{ false }, g_gotoScene{ false };
inline std::atomic<float> g_pickFx{ 0.f }, g_pickFy{ 0.f };   // клик (доли окна)
inline std::atomic<uint32_t> g_pickedH{ 0 };                  // выбранный мышкой объект (gc-handle из g_scene)
struct LabelEnt { float x, y, dist; std::string name; };
inline std::vector<LabelEnt> g_labels; inline float g_labW = 1920, g_labH = 1080; inline std::string g_labelFilter;
inline std::vector<std::function<void()>> g_queue;

inline void Say(const std::string& s) { std::lock_guard<std::mutex> l(g_mx); g_status = s; Log("%s", s.c_str()); }
inline void Enqueue(std::function<void()> f) { std::lock_guard<std::mutex> l(g_mx); g_queue.push_back(std::move(f)); }

namespace G {
using namespace il2;
// классы
inline Il2CppClass *kObject, *kComponent, *kTransform, *kGameObject, *kCamera, *kScreen, *kBehaviour, *kCollider,
    *kCC, *kCursor, *kTime, *kPrefs, *kPsafe, *kPoly, *kPlayer, *kLoadPlayer, *kEnemy, *kAchive, *kInv, *kItem,
    *kController, *kOutline, *kInt, *kFloat;
// методы Unity
inline const MethodInfo *mFindAll, *mFindAllInc, *mDestroy, *mInstantiate, *mDontDestroy, *mGetName, *mGetTransform,
    *mGetGO, *mGetTag, *mCompsChild, *mGetPos, *mSetPos, *mSetActive, *mActiveSelf, *mW2S, *mScrW, *mScrH, *mSetEnB, *mSetEnC,
    *mBounds, *mCurGet, *mCurSet, *mCurVis, *mDelta, *mPrefsSave, *mPrefsDelAll, *mPrefsSetInt, *mPrefsSetStr,
    *mGrounded, *mGetComp;
// методы игры
inline const MethodInfo *mPsSetInt, *mPsGetInt, *mLoadMoney, *mTakePriz, *mLoadAchive, *mCreateItem, *mOutMode,
    *mOutColor, *mOutWidth, *mIntCtor, *mFloatCtor;
inline const MethodInfo* mCurVisGet = nullptr;
inline const MethodInfo *mGetScale = nullptr, *mSetScale = nullptr, *mMove = nullptr, *mRaycast = nullptr, *mHitTr = nullptr,
    *mScreenRay = nullptr, *mCamMain = nullptr, *mSyncTr = nullptr;
inline Il2CppClass *kPhysics = nullptr, *kRayHit = nullptr;
// оффсеты
inline int oCam = -1, oCharRot = -1, oCamRot = -1, oJumpFlag = -1, oControl = -1;
inline int oWalk = -1, oAccel = -1, oAccelMax = -1, oJump = -1;
inline int oWalkF = -1, oNewWalkF = -1, oOldWalkF = -1, oAccelF = -1, oAccelMaxF = -1, oJumpF = -1;
inline int oWall = -1, oHealth = -1, oHealthAll = -1;
inline int oPolyEnemy2 = -1, oPExpH = -1, oPExpB = -1, oPMonH = -1, oPMonB = -1;
inline int oAchType = -1, oAchMain = -1, oAchGold = -1, oAchNum = -1, oAchLevel = -1, oAchTake = -1;
inline int oItemNum = -1;
inline int oInvAll = -1;
// статические поля
inline FieldInfo *fPlayerStatic, *fPolyObj, *fPolyEnemy, *fExpH, *fExpB, *fMonH, *fMonB, *fCntEnemy, *fCntMax,
    *fJumpWhile, *fInvObj;

inline void* Sf(FieldInfo* f) { void* v = nullptr; if (f) il2cpp_field_static_get_value(f, &v); return v; }

// ---------------------------------------------------------------- кодек Int/Float (защищённые числа игры)
struct Codec {
    const MethodInfo* ctor = nullptr; Il2CppClass* k = nullptr; int mode = -1; bool isFloat = false;
    static int Dec(int mode, int v, int s) {
        switch (mode) { case 0: return v ^ s; case 1: return v - s; case 2: return v + s; case 3: return s - v; }
        return v;
    }
    // создаёт структуру настоящим конструктором игры
    bool Make(const void* arg, int out[2]) const {
        if (!ctor || !k) return false;
        auto o = il2cpp_object_new(k);
        if (!o) return false;
        Call(ctor, o, { (void*)arg });
        int* p = (int*)il2cpp_object_unbox(o);
        out[0] = p[0]; out[1] = p[1];
        return true;
    }
    void Calibrate() {
        if (!ctor) return;
        for (int m = 0; m < 4; m++) {
            bool ok = true;
            if (!isFloat) {
                int ps[4] = { 0, 1, 12345, 999999 };
                for (int p : ps) { int r[2]; if (!Make(&p, r) || Dec(m, r[0], r[1]) != p) { ok = false; break; } }
            } else {
                float ps[3] = { 1.0f, 2.5f, 12.75f };
                for (float p : ps) {
                    int r[2]; if (!Make(&p, r)) { ok = false; break; }
                    int b = Dec(m, r[0], r[1]); float f; memcpy(&f, &b, 4);
                    if (f != p) { ok = false; break; }
                }
            }
            if (ok) { mode = m; break; }
        }
        Log("codec(%s): mode=%d", isFloat ? "Float" : "Int", mode);
    }
    float DecF(const int* raw) const { int b = Dec(mode, raw[0], raw[1]); float f; memcpy(&f, &b, 4); return f; }
};
inline Codec cInt, cFloat;

inline void SetStaticInt(FieldInfo* f, int v) {
    int r[2]; if (!f || !cInt.Make(&v, r)) return;
    il2cpp_field_static_set_value(f, r);
}
inline void SetFieldFloatEnc(void* obj, int off, float v) {
    if (!obj || off < 0) return;
    int r[2]; if (!cFloat.Make(&v, r)) return;
    memcpy((char*)obj + off, r, 8);
}

// ---------------------------------------------------------------- PlayerPrefs
inline int PsGet(const char* key, int def = 0) {
    if (!mPsGetInt) return def;
    auto r = Call(mPsGetInt, nullptr, { Str(key) });
    return r ? Unbox<int>(r, def) : def;
}
inline void PsSet(const char* key, int v) {
    if (mPsSetInt) Call(mPsSetInt, nullptr, { Str(key), &v });
}
inline void PrefsSave() { if (mPrefsSave) Call(mPrefsSave, nullptr); }
inline void RefreshMoney() { if (mLoadMoney) Call(mLoadMoney, nullptr); }

// Ищет метод класса по форме (без имени): параметры + возвращаемый тип (имена обфусцированы и меняются).
inline const MethodInfo* ByShape(Il2CppClass* k, std::initializer_list<const char*> params, const char* ret) {
    void* it = nullptr;
    while (auto m = il2cpp_class_get_methods(k, &it)) {
        if (!IsStatic(m) || il2cpp_method_get_param_count(m) != params.size()) continue;
        if (TypeName(il2cpp_method_get_return_type(m)) != ret) continue;
        bool ok = true; uint32_t i = 0;
        for (auto p : params) if (TypeName(il2cpp_method_get_param(m, i++)) != p) { ok = false; break; }
        if (ok) return m;
    }
    return nullptr;
}

inline bool Bind() {
    Log("Bind...");
    const char* AC = "Assembly-CSharp.dll";
    kObject = FindClass("UnityEngine", "Object"); kComponent = FindClass("UnityEngine", "Component");
    kTransform = FindClass("UnityEngine", "Transform"); kGameObject = FindClass("UnityEngine", "GameObject");
    kCamera = FindClass("UnityEngine", "Camera"); kScreen = FindClass("UnityEngine", "Screen");
    kBehaviour = FindClass("UnityEngine", "Behaviour"); kCollider = FindClass("UnityEngine", "Collider");
    kCC = FindClass("UnityEngine", "CharacterController"); kCursor = FindClass("UnityEngine", "Cursor");
    kTime = FindClass("UnityEngine", "Time"); kPrefs = FindClass("UnityEngine", "PlayerPrefs");
    kPsafe = FindClassIn(AC, "", "PlayerPrefsSafe"); kPoly = FindClassIn(AC, "", "ControllerPolygon");
    kPlayer = FindClassIn(AC, "", "PlayerController"); kLoadPlayer = FindClassIn(AC, "", "ControllerLoadPlayer");
    kEnemy = FindClassIn(AC, "", "EnemyController"); kAchive = FindClassIn(AC, "", "Achive");
    kInv = FindClassIn(AC, "", "ControllerInventory"); kItem = FindClassIn(AC, "", "ItemShop");
    kController = FindClassIn(AC, "", "Controller"); kOutline = FindClassIn(AC, "", "Outline");
    kInt = FindClassIn(AC, "", "Int"); kFloat = FindClassIn(AC, "", "Float");
    if (!kObject || !kTransform || !kPlayer || !kEnemy || !kPsafe || !kPoly) {
        Log("Bind: не найден критичный класс (obj=%p tr=%p player=%p enemy=%p psafe=%p poly=%p)", kObject, kTransform, kPlayer, kEnemy, kPsafe, kPoly);
        return false;
    }
    for (auto k : { kInt, kFloat, kPoly, kPlayer, kEnemy, kController, kInv, kAchive }) if (k) il2cpp_runtime_class_init(k);

    mFindAll = MethodSig(kObject, "FindObjectsOfType", { "System.Type" });
    mFindAllInc = MethodSig(kObject, "FindObjectsOfType", { "System.Type", "System.Boolean" });
    mDestroy = MethodSig(kObject, "Destroy", { "UnityEngine.Object" });
    mInstantiate = MethodSig(kObject, "Instantiate", { "UnityEngine.Object", "UnityEngine.Vector3", "UnityEngine.Quaternion" });
    mDontDestroy = Method(kObject, "DontDestroyOnLoad", 1);
    mGetName = Method(kObject, "get_name", 0);
    mGetTransform = Method(kComponent, "get_transform", 0); mGetGO = Method(kComponent, "get_gameObject", 0);
    mGetTag = Method(kComponent, "get_tag", 0); mGetComp = MethodSig(kComponent, "GetComponent", { "System.Type" });
    mCompsChild = MethodSig(kComponent, "GetComponentsInChildren", { "System.Type" });
    mGetPos = Method(kTransform, "get_position", 0); mSetPos = Method(kTransform, "set_position", 1);
    mSetActive = Method(kGameObject, "SetActive", 1); mActiveSelf = Method(kGameObject, "get_activeSelf", 0);
    mW2S = MethodSig(kCamera, "WorldToScreenPoint", { "UnityEngine.Vector3" });
    mScrW = Method(kScreen, "get_width", 0); mScrH = Method(kScreen, "get_height", 0);
    mSetEnB = Method(kBehaviour, "set_enabled", 1); mSetEnC = Method(kCollider, "set_enabled", 1);
    mBounds = Method(kCollider, "get_bounds", 0); mGrounded = Method(kCC, "get_isGrounded", 0);
    mCurGet = Method(kCursor, "get_lockState", 0); mCurSet = Method(kCursor, "set_lockState", 1);
    mCurVis = Method(kCursor, "set_visible", 1); mCurVisGet = Method(kCursor, "get_visible", 0); mDelta = Method(kTime, "get_deltaTime", 0);
    mPrefsSave = Method(kPrefs, "Save", 0); mPrefsDelAll = Method(kPrefs, "DeleteAll", 0);
    mPrefsSetInt = Method(kPrefs, "SetInt", 2); mPrefsSetStr = Method(kPrefs, "SetString", 2);
    mGetScale = Method(kTransform, "get_localScale", 0); mSetScale = Method(kTransform, "set_localScale", 1);
    mMove = Method(kCC, "Move", 1); mCamMain = Method(kCamera, "get_main", 0);
    mScreenRay = MethodSig(kCamera, "ScreenPointToRay", { "UnityEngine.Vector3" });
    kPhysics = FindClass("UnityEngine", "Physics"); kRayHit = FindClass("UnityEngine", "RaycastHit");
    if (kPhysics) { mRaycast = MethodSig(kPhysics, "Raycast", { "UnityEngine.Ray", "UnityEngine.RaycastHit&", "System.Single" }); mSyncTr = Method(kPhysics, "SyncTransforms", 0); }
    if (kRayHit) mHitTr = Method(kRayHit, "get_transform", 0);
    Log("bind2: scale=%p/%p move=%p raycast=%p hitTr=%p screenRay=%p syncTr=%p", mGetScale, mSetScale, mMove, mRaycast, mHitTr, mScreenRay, mSyncTr);

    mPsSetInt = ByShape(kPsafe, { "System.String", "System.Int32" }, "System.Void");
    mPsGetInt = ByShape(kPsafe, { "System.String" }, "System.Int32");
    mLoadMoney = Method(kInv, "LoadMoney", 0);
    mTakePriz = Method(kAchive, "TakePrizAchive", 0); mLoadAchive = Method(kAchive, "LoadAchive", 0);
    mCreateItem = Method(kInv, "CreateItem", 1);
    if (kOutline) { mOutMode = Method(kOutline, "set_OutlineMode", 1); mOutColor = Method(kOutline, "set_OutlineColor", 1); mOutWidth = Method(kOutline, "set_OutlineWidth", 1); }
    mIntCtor = kInt ? Method(kInt, ".ctor", 1) : nullptr; mFloatCtor = kFloat ? Method(kFloat, ".ctor", 1) : nullptr;
    cInt.k = kInt; cInt.ctor = mIntCtor; cInt.isFloat = false; cInt.Calibrate();
    cFloat.k = kFloat; cFloat.ctor = mFloatCtor; cFloat.isFloat = true; cFloat.Calibrate();

    oCam = Off(kPlayer, "Camera"); oCharRot = Off(kPlayer, "m_CharacterTargetRot"); oCamRot = Off(kPlayer, "m_CameraTargetRot");
    oJumpFlag = Off(kPlayer, "m_JumpPeremes"); oControl = Off(kPlayer, "m_controllPlayer");
    oWalk = Off(kPlayer, "m_WalkSpeed"); oAccel = Off(kPlayer, "m_AccelSpeed"); oAccelMax = Off(kPlayer, "m_AccelSpeedMax"); oJump = Off(kPlayer, "m_JumpSpeed");
    oWalkF = Off(kPlayer, "m_walkSpeed"); oNewWalkF = Off(kPlayer, "m_newWalkSpeed"); oOldWalkF = Off(kPlayer, "m_oldWalkSpeed");
    oAccelF = Off(kPlayer, "m_accelSpeed"); oAccelMaxF = Off(kPlayer, "m_accelSpeedMax"); oJumpF = Off(kPlayer, "m_jumpSpeed");
    oWall = Off(kEnemy, "WallHack"); oHealth = Off(kEnemy, "_health"); oHealthAll = Off(kEnemy, "_healthAll");
    oPolyEnemy2 = Off(kPoly, "Enemy2Prefab"); oPExpH = Off(kPoly, "_expKill_Head"); oPExpB = Off(kPoly, "_expKill_Body");
    oPMonH = Off(kPoly, "_moneyKill_Head"); oPMonB = Off(kPoly, "_moneyKill_Body");
    if (kAchive) {
        oAchType = Off(kAchive, "modeZad"); oAchMain = Off(kAchive, "_countMain"); oAchGold = Off(kAchive, "_countPrizGold");
        oAchNum = Off(kAchive, "_numberAchive"); oAchLevel = Off(kAchive, "_levelAchive"); oAchTake = Off(kAchive, "_takePrizZad");
    }
    oItemNum = kItem ? Off(kItem, "_numberItem") : -1; oInvAll = kInv ? Off(kInv, "AllItems") : -1;

    fPlayerStatic = Field(kLoadPlayer, "_player"); fPolyObj = Field(kPoly, "_obj"); fPolyEnemy = Field(kPoly, "_enemy");
    fExpH = Field(kPoly, "ExpKill_Head"); fExpB = Field(kPoly, "ExpKill_Body");
    fMonH = Field(kPoly, "MoneyKill_Head"); fMonB = Field(kPoly, "MoneyKill_Body");
    fCntEnemy = Field(kController, "_countEnemy"); fCntMax = Field(kController, "_countEnemyMax");
    fJumpWhile = Field(kPlayer, "m_JumpWhile"); fInvObj = Field(kInv, "_obj");

    Log("bind: find=%p findInc=%p w2s=%p bounds=%p psSet=%p psGet=%p loadMoney=%p takePriz=%p", mFindAll, mFindAllInc, mW2S, mBounds, mPsSetInt, mPsGetInt, mLoadMoney, mTakePriz);
    Log("bind: cam@%d charRot@%d camRot@%d jump@%d ctrl@%d wall@%d health@%d | intCodec=%d floatCodec=%d", oCam, oCharRot, oCamRot, oJumpFlag, oControl, oWall, oHealth, cInt.mode, cFloat.mode);
    bool crit = mFindAll && mGetTransform && mGetPos && mW2S && mPsGetInt && mPsSetInt;
    if (!crit) Log("Bind: не найден критичный метод");
    return crit;
}

// ---------------------------------------------------------------- хелперы Unity
inline bool Alive(Il2CppObject* o) { return o != nullptr; }
inline Il2CppObject* TrOf(void* comp) { return comp ? Call(mGetTransform, comp) : nullptr; }
inline bool PosOf(void* comp, V3& out) {
    auto tr = TrOf(comp); if (!tr) return false;
    auto r = Call(mGetPos, tr); if (!r) return false;
    out = Unbox<V3>(r); return true;
}
inline std::vector<void*> FindAll(Il2CppClass* k, bool inactive = false) {
    std::vector<void*> res; if (!k) return res;
    auto t = TypeObj(k);
    Il2CppObject* arr = nullptr;
    if (inactive && mFindAllInc) { bool b = true; arr = Call(mFindAllInc, nullptr, { t, &b }); }
    else arr = Call(mFindAll, nullptr, { t });
    int n = ArrLen(arr);
    for (int i = 0; i < n; i++) { void* o = ArrAt<void*>(arr, i); if (o) res.push_back(o); }
    return res;
}
inline bool KeyDown(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }
inline bool GameFocused() {
    DWORD pid = 0; GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}

// ---------------------------------------------------------------- награды
inline void ApplyRewardFields() {
    auto poly = Sf(fPolyObj);
    if (poly) {
        Wr<int>(poly, oPExpH, g_cfg.rewExp); Wr<int>(poly, oPExpB, g_cfg.rewExp);
        Wr<int>(poly, oPMonH, g_cfg.rewGold); Wr<int>(poly, oPMonB, g_cfg.rewGold);
    }
    SetStaticInt(fExpH, g_cfg.rewExp); SetStaticInt(fExpB, g_cfg.rewExp);
    SetStaticInt(fMonH, g_cfg.rewGold); SetStaticInt(fMonB, g_cfg.rewGold);
}
struct Pending { int g0, e0, start, changedAt; };
inline std::vector<Pending> g_pending;
inline int g_frame = 0;

// вызывается из хука HitEnemy (игровой поток)
inline void OnHit() {
    if (!g_cfg.topUp || g_pending.size() > 8) return;
    g_pending.push_back({ PsGet("GoldCount"), PsGet("LevelProgress"), g_frame, -1 });
}
inline void TickPending() {
    if (g_pending.empty()) return;
    int g = PsGet("GoldCount"), e = PsGet("LevelProgress");
    for (size_t i = 0; i < g_pending.size();) {
        auto& p = g_pending[i]; bool done = false;
        if (p.changedAt < 0 && (g != p.g0 || e != p.e0)) p.changedAt = g_frame;
        if (p.changedAt >= 0 && g_frame - p.changedAt >= 3) {
            int missG = g_cfg.rewGold - (g - p.g0), missE = g_cfg.rewExp - (e - p.e0);
            if (missG > 0 || missE > 0) {
                if (missG > 0) PsSet("GoldCount", g + missG);
                if (missE > 0) PsSet("LevelProgress", e + missE);
                Log("top-up: gold +%d (game gave %d), exp +%d (game gave %d)", std::max(missG, 0), g - p.g0, std::max(missE, 0), e - p.e0);
                RefreshMoney();
                g = PsGet("GoldCount"); e = PsGet("LevelProgress");
            }
            done = true;
        } else if (p.changedAt < 0 && g_frame - p.start > 20) done = true;
        if (done) g_pending.erase(g_pending.begin() + i); else i++;
    }
}

// ---------------------------------------------------------------- ачивки
inline const char* CounterKey(int type) {
    switch (type) {
    case 0: return "CountDeadKnife"; case 1: return "CountDeadDummyHead"; case 2: return "CountDeadOther2";
    case 3: return "CountDeadOnTimer"; case 5: return "CountFinishRounds"; case 6: return "LevelProgress";
    case 7: return "CountDeadWeapon"; }
    return nullptr;
}
// steps: 1 - закрыть только текущий уровень каждой ачивки (следующий откроется), 1000 - пройти все уровни
inline void DoAchievements(int steps) {
    if (!kAchive || oAchMain < 0) { Say("Достижения: класс не найден"); return; }
    auto list = FindAll(kAchive, true);
    if (list.empty()) { Say("Открой экран достижений в игре и нажми ещё раз"); return; }
    int done = 0, paid = 0;
    for (void* a : list) {
        int type = Rd<int>(a, oAchType), id = Rd<int>(a, oAchNum);
        void* mainArr = Rd<void*>(a, oAchMain); void* goldArr = Rd<void*>(a, oAchGold);
        int levels = ArrLen(mainArr); if (levels <= 0) continue;
        char key[64]; snprintf(key, sizeof key, "AchiveSaveLevel_%d", id);
        int cur = Rd<int>(a, oAchLevel);
        Log("achive #%d (type %d): levels=%d cur=%d", id, type, levels, cur);
        for (int s = 0, L = cur; s < steps && L < levels; s++, L++) {
            if (auto ck = CounterKey(type)) { int need = ArrAt<int>(mainArr, L); if (PsGet(ck) < need) PsSet(ck, need); }
            Wr<bool>(a, oAchTake, false);
            int g0 = PsGet("GoldCount");
            Call(mTakePriz, a);
            int g1 = PsGet("GoldCount");
            int lv = Rd<int>(a, oAchLevel);
            if (g1 == g0 || lv <= L) { // игра не выдала сама - выдаём вручную и двигаем уровень
                int prize = (goldArr && L < ArrLen(goldArr)) ? ArrAt<int>(goldArr, L) : 0;
                if (g1 == g0 && prize > 0) { PsSet("GoldCount", g1 + prize); paid += prize; }
                if (lv <= L) { Wr<int>(a, oAchLevel, L + 1); PsSet(key, L + 1); }
            } else paid += g1 - g0;
            done++;
        }
        if (mLoadAchive) Call(mLoadAchive, a);
    }
    PrefsSave(); RefreshMoney();
    Say("Достижения: обработано уровней " + std::to_string(done) + ", выдано голды " + std::to_string(paid));
}

// ---------------------------------------------------------------- предметы (экспериментально)
inline void DoGiveItems() {
    if (!mCreateItem) { Say("Предметы: ControllerInventory.CreateItem не найден"); return; }
    auto items = FindAll(kItem, true);
    if (items.empty()) { Say("Открой инвентарь в меню игры и нажми ещё раз"); return; }
    std::unordered_set<int> seen; int n = 0;
    for (void* it : items) {
        int id = Rd<int>(it, oItemNum, -1);
        if (id < 0 || !seen.insert(id).second) continue;
        Call(mCreateItem, nullptr, { &id }); n++;
    }
    PrefsSave();
    Say("Предметов обработано: " + std::to_string(n) + " (из " + std::to_string(items.size()) + "). Перезайди в инвентарь");
}

// ---------------------------------------------------------------- валюта / опыт
inline void SetGold(int v) { PsSet("GoldCount", v); PrefsSave(); RefreshMoney(); Say("Голда установлена: " + std::to_string(v)); }
inline void AddExp(int v) {
    int cur = PsGet("LevelProgress"); PsSet("LevelProgress", cur + v); PrefsSave(); RefreshMoney();
    for (void* a : FindAll(kAchive, true)) if (Rd<int>(a, oAchType) == 6 && mLoadAchive) Call(mLoadAchive, a);
    Say("Опыт: LevelProgress " + std::to_string(cur) + " -> " + std::to_string(cur + v) + " (перезайди в инвентарь, чтобы обновилось)");
}
inline void SetLevel(int v) { PsSet("LevelCount", v); PrefsSave(); Say("LevelCount = " + std::to_string(v) + " (перезайди в инвентарь)"); }

// ---------------------------------------------------------------- игрок / аим / ESP
struct EnemyCache { void *head = nullptr, *body = nullptr, *legs = nullptr; bool built = false; };
inline std::unordered_map<void*, EnemyCache> g_ec;
inline std::unordered_set<void*> g_chams;
inline void* g_player = nullptr;
inline float g_baseWalk, g_baseAccel, g_baseAccelMax, g_baseJump;
inline float g_baseF[6]; inline bool g_baseFok = false, g_baseOk = false;
inline bool g_wasNoclip = false, g_wasMenu = false, g_jumpHeld = false;
inline bool g_speedMod = false;                       // скорость/прыжок сейчас изменены нами
inline bool g_menuApplied = false;                    // мы перехватили курсор/управление из-за меню
inline int  g_savedLock = 0; inline bool g_savedVis = true, g_savedCtl = true; // состояние игры до открытия меню
inline void* g_bossCopy = nullptr; inline bool g_f6 = false;
inline int g_seenEnemies = 0;

inline void BuildCache(void* en, EnemyCache& c) {
    c.built = true;
    if (!mCompsChild || !mGetTag) return;
    auto arr = Call(mCompsChild, en, { TypeObj(kCollider) });
    int n = ArrLen(arr);
    for (int i = 0; i < n; i++) {
        void* col = ArrAt<void*>(arr, i); if (!col) continue;
        std::string t = ToStd(Call(mGetTag, col));
        if (t == "EnemyHead") c.head = col; else if (t == "EnemyBody") c.body = col; else if (t == "EnemyLegs") c.legs = col;
    }
}
inline bool PointOf(void* col, V3& out) {
    if (!col || !mBounds) return false;
    auto r = Call(mBounds, col); if (!r) return false;
    out = Unbox<Bnds>(r).center; return true;
}
inline bool W2S(void* cam, V3 w, float& sx, float& sy) {
    auto r = Call(mW2S, cam, { &w }); if (!r) return false;
    V3 s = Unbox<V3>(r); if (s.z <= 0.01f) return false;
    sx = s.x; sy = g_scrH - s.y; return true;
}
inline void ForwardFromAngles(float yaw, float pitch, V3& f) {
    const float d = 3.14159265f / 180.f;
    f = { cosf(pitch * d) * sinf(yaw * d), -sinf(pitch * d), cosf(pitch * d) * cosf(yaw * d) };
}
inline float WrapDeg(float a) { while (a > 180) a -= 360; while (a < -180) a += 360; return a; }

inline void Teleport(V3 p) {
    auto tr = TrOf(g_player); if (!tr) return;
    bool cc = false;
    // CharacterController перезаписывает позицию, поэтому на момент телепорта его выключаем
    auto ccComp = kCC ? Call(mGetComp, g_player, { TypeObj(kCC) }) : nullptr;
    if (ccComp && mSetEnC) { bool f = false; Call(mSetEnC, ccComp, { &f }); cc = true; }
    Call(mSetPos, tr, { &p });
    if (cc) { bool t = true; Call(mSetEnC, ccComp, { &t }); }
}

inline void SceneRefresh() {
    std::vector<SceneEnt> out;
    { std::lock_guard<std::mutex> l(g_mx); for (auto& e : g_scene) il2cpp_gchandle_free(e.h); g_scene.clear(); }
    auto trs = FindAll(kTransform, true);
    for (void* t : trs) {
        SceneEnt e{}; e.name = ToStd(Call(mGetName, t));
        auto p = Call(mGetPos, t); if (!p) continue; e.pos = Unbox<V3>(p);
        auto go = Call(mGetGO, t); e.active = go ? Unbox<bool>(Call(mActiveSelf, go), true) : true;
        e.h = il2cpp_gchandle_new((Il2CppObject*)t, 0);
        out.push_back(std::move(e));
        if (out.size() >= 4000) break;
    }
    std::lock_guard<std::mutex> l(g_mx); g_scene = std::move(out); g_sceneVer++;
}

inline void SpawnBoss() {
    auto poly = Sf(fPolyObj);
    void* prefab = poly ? Rd<void*>(poly, oPolyEnemy2) : nullptr;
    if (prefab && !g_bossCopy && mInstantiate) { // сохраняем копию, чтобы вызывать босса на других картах
        Q4 q0{ 0, 0, 0, 1 }; V3 p0 = g_playerPos;
        auto c = Call(mInstantiate, nullptr, { prefab, &p0, &q0 });
        if (c) {
            bool f = false; auto go = c; Call(mSetActive, go, { &f });
            if (mDontDestroy) Call(mDontDestroy, nullptr, { c });
            g_bossCopy = c; il2cpp_gchandle_new(c, 1);
        }
    }
    void* src = prefab ? prefab : g_bossCopy;
    if (!src) { Say("Босс: префаб не найден. Один раз вызови босса в полигоне, потом можно на любой карте"); return; }
    V3 pp; if (!PosOf(g_player, pp)) { Say("Босс: нет игрока"); return; }
    V3 pos{ pp.x + 4, pp.y + 1, pp.z + 4 }; Q4 rot{ 0, 0, 0, 1 };
    auto o = Call(mInstantiate, nullptr, { src, &pos, &rot });
    if (!o) { Say("Босс: Instantiate не удался"); return; }
    bool t = true; Call(mSetActive, o, { &t });
    Say("Босс вызван");
}

inline void RemoveBots() {
    auto list = FindAll(kEnemy); int n = 0;
    void* boss = Sf(fPolyEnemy);
    for (void* e : list) {
        if (e == boss) continue;
        auto go = Call(mGetGO, e); if (go) { Call(mDestroy, nullptr, { go }); n++; }
    }
    SetStaticInt(fCntEnemy, 0);
    Say("Ботов убрано: " + std::to_string(n));
}

inline void RestoreCursor(void* pl) {
    if (!g_menuApplied) return;
    if (pl) Wr<bool>(pl, oControl, g_savedCtl);
    int lock = g_savedLock; if (mCurSet) Call(mCurSet, nullptr, { &lock });
    bool v = g_savedVis; if (mCurVis) Call(mCurVis, nullptr, { &v });
    g_menuApplied = false;
}

// ---------------------------------------------------------------- размер объектов / ботов
inline std::unordered_map<void*, V3> g_origScale; inline bool g_globalApplied = false;
inline V3 GetScaleOf(void* comp) {
    auto tr = TrOf(comp); if (tr && mGetScale) { auto r = Call(mGetScale, tr); if (r) return Unbox<V3>(r); }
    return { 1, 1, 1 };
}
inline bool SetScaleOf(void* comp, V3 sc) {
    auto tr = TrOf(comp); if (!tr || !mSetScale) return false;
    Call(mSetScale, tr, { &sc }); return true;
}
inline void SetBotScale(void* e, V3 sc) { if (!g_origScale.count(e)) g_origScale[e] = GetScaleOf(e); SetScaleOf(e, sc); }
inline void ResetBots() {
    auto list = FindAll(kEnemy);
    for (void* e : list) { auto it = g_origScale.find(e); if (it != g_origScale.end()) SetScaleOf(e, it->second); }
    g_origScale.clear(); g_globalApplied = false;
}
inline void TickBots() {
    if (g_frame % 10 != 0) return;
    bool wantList = g_wantBots.load();
    if (!g_cfg.botScaleOn && !g_globalApplied && !wantList && g_origScale.empty()) return;
    if (!g_cfg.botScaleOn && g_globalApplied) ResetBots();
    auto list = FindAll(kEnemy);
    { std::unordered_set<void*> now(list.begin(), list.end()); for (auto it = g_origScale.begin(); it != g_origScale.end();) it = now.count(it->first) ? ++it : g_origScale.erase(it); }
    if (g_cfg.botScaleOn) {
        V3 t = g_cfg.botScale;
        for (void* e : list) { V3 c = GetScaleOf(e); if (fabsf(c.x - t.x) > 0.001f || fabsf(c.y - t.y) > 0.001f || fabsf(c.z - t.z) > 0.001f) SetBotScale(e, t); }
        g_globalApplied = true;
    }
    if (wantList) {
        g_wantBots = false; std::vector<BotEnt> out; int n = 0;
        for (void* e : list) {
            BotEnt b{}; b.id = (uintptr_t)e; b.name = ToStd(Call(mGetName, e)); b.hp = Rd<int>(e, oHealth, 0); PosOf(e, b.pos); b.scale = GetScaleOf(e);
            out.push_back(std::move(b)); if (++n >= 60) break;
        }
        std::lock_guard<std::mutex> l(g_mx); g_bots = std::move(out);
    }
}

// ---------------------------------------------------------------- выбор объекта мышкой
// Регистрирует Transform в списке инспектора (если его там нет) и просит UI выделить его.
inline void SelectInInspector(void* t) {
    if (!t) return;
    uint32_t selH = 0; std::string nm = ToStd(Call(mGetName, t));
    {
        std::lock_guard<std::mutex> l(g_mx);
        for (auto& e : g_scene) if (il2cpp_gchandle_get_target(e.h) == (Il2CppObject*)t) { selH = e.h; break; }
        if (!selH) {
            SceneEnt e{}; e.name = nm; auto r = Call(mGetPos, t); if (r) e.pos = Unbox<V3>(r);
            auto go = Call(mGetGO, t); e.active = go ? Unbox<bool>(Call(mActiveSelf, go), true) : true;
            e.h = il2cpp_gchandle_new((Il2CppObject*)t, 0); g_scene.push_back(e); selH = e.h;
        }
    }
    g_pickedH = selH; g_gotoScene = true; g_menuOpen = true;
    Say("Выбран объект: " + nm);
}
inline void DoPick(void* pl) {
    g_pickReq = false;
    void* cam = pl ? Rd<void*>(pl, oCam) : nullptr;
    if (!cam && mCamMain) cam = Call(mCamMain, nullptr);
    float sw = Unbox<int>(Call(mScrW, nullptr), 1920), sh = Unbox<int>(Call(mScrH, nullptr), 1080);
    V3 sp{ g_pickFx.load() * sw, (1.f - g_pickFy.load()) * sh, 0.f };
    void* hit = nullptr;
    if (cam && mScreenRay && mRaycast && kRayHit && mHitTr) { // точный способ: луч из камеры через точку клика
        auto rr = Call(mScreenRay, cam, { &sp });
        if (rr) {
            Ray3 ray = Unbox<Ray3>(rr); float maxd = 2000.f;
            auto ho = il2cpp_object_new(kRayHit); void* hp = ho ? il2cpp_object_unbox(ho) : nullptr;
            if (hp) { auto b = Call(mRaycast, nullptr, { &ray, hp, &maxd }); if (b && Unbox<bool>(b)) hit = Call(mHitTr, ho); }
        }
    }
    if (!hit && cam && mW2S) { // запасной: ближайший к клику объект списка инспектора (по экранной проекции)
        { bool empty; { std::lock_guard<std::mutex> l(g_mx); empty = g_scene.empty(); } if (empty) SceneRefresh(); }
        std::vector<uint32_t> hs; { std::lock_guard<std::mutex> l(g_mx); for (auto& e : g_scene) hs.push_back(e.h); }
        float bestD = 60.f * 60.f;
        for (uint32_t h : hs) {
            void* t = il2cpp_gchandle_get_target(h); if (!t) continue;
            V3 p; if (!PosOf(t, p)) continue;
            auto r = Call(mW2S, cam, { &p }); if (!r) continue; V3 s = Unbox<V3>(r); if (s.z <= 0.01f) continue;
            float dx = s.x - sp.x, dy = s.y - sp.y, d2 = dx * dx + dy * dy; if (d2 < bestD) { bestD = d2; hit = t; }
        }
    }
    if (!hit) { Say("Выбор: по этой точке ничего не найдено, кликни ещё раз (Esc - отмена)"); return; }
    g_picking = false;
    SelectInInspector(hit);
}

// подписи с названиями объектов рядом с ними (включённые, в радиусе, по фильтру инспектора)
inline void UpdateLabels(void* pl, const V3& ppos) {
    static std::vector<std::pair<uint32_t, std::string>> cache; static unsigned ver = ~0u; static std::string lastF;
    if (!g_cfg.sceneLabels) { if (!g_labels.empty()) { std::lock_guard<std::mutex> l(g_mx); g_labels.clear(); } return; }
    if (g_frame % 5) return;
    std::string flt; unsigned curVer;
    { std::lock_guard<std::mutex> l(g_mx); flt = g_labelFilter; curVer = g_sceneVer; }
    if (curVer != ver || flt != lastF) {
        std::lock_guard<std::mutex> l(g_mx); cache.clear();
        for (auto& e : g_scene) {
            if (!flt.empty()) { std::string n = e.name; std::transform(n.begin(), n.end(), n.begin(), [](unsigned char c) { return (char)tolower(c); }); if (n.find(flt) == std::string::npos) continue; }
            cache.emplace_back(e.h, e.name); if (cache.size() >= 3000) break;
        }
        ver = curVer; lastF = flt;
    }
    void* cam = Rd<void*>(pl, oCam);
    if (!cam || !mW2S) { std::lock_guard<std::mutex> l(g_mx); g_labels.clear(); return; }
    float sw = Unbox<int>(Call(mScrW, nullptr), 1920), sh = Unbox<int>(Call(mScrH, nullptr), 1080);
    V3 cp = ppos; PosOf(cam, cp);
    std::vector<LabelEnt> out; float maxD2 = g_cfg.labelDist * g_cfg.labelDist;
    for (auto& c : cache) {
        void* t = il2cpp_gchandle_get_target(c.first); if (!t) continue;
        V3 p; if (!PosOf(t, p)) continue;
        float dx = p.x - cp.x, dy = p.y - cp.y, dz = p.z - cp.z, d2 = dx * dx + dy * dy + dz * dz;
        if (d2 > maxD2) continue;
        auto go = Call(mGetGO, t); if (!go || !Unbox<bool>(Call(mActiveSelf, go), true)) continue;
        auto r = Call(mW2S, cam, { &p }); if (!r) continue;
        V3 sc = Unbox<V3>(r); if (sc.z <= 0.01f || sc.x < 0 || sc.x > sw || sc.y < 0 || sc.y > sh) continue;
        out.push_back({ sc.x, sh - sc.y, sqrtf(d2), c.second });
    }
    std::sort(out.begin(), out.end(), [](const LabelEnt& a, const LabelEnt& b) { return a.dist < b.dist; });
    if ((int)out.size() > g_cfg.labelMax) out.resize(g_cfg.labelMax);
    std::lock_guard<std::mutex> l(g_mx); g_labels = std::move(out); g_labW = sw; g_labH = sh;
}

inline void Tick() {
    g_frame++;
    // --- очередь команд из UI
    std::vector<std::function<void()>> q;
    { std::lock_guard<std::mutex> l(g_mx); q.swap(g_queue); }
    for (auto& f : q) f();

    // --- игрок
    void* pl = Sf(fPlayerStatic);
    if (pl && !TrOf(pl)) pl = nullptr;
    if (pl != g_player) { g_player = pl; g_baseOk = false; g_speedMod = false; g_wasNoclip = false; g_ec.clear(); g_chams.clear(); }
    V3 ppos{};
    bool have = pl && PosOf(pl, ppos);
    { std::lock_guard<std::mutex> l(g_mx); g_playerFound = have; if (have) g_playerPos = ppos; }
    if (have) g_playerPos = ppos;

    // F6 - вызов босса
    bool f6 = KeyDown(VK_F6) && GameFocused();
    if (f6 && !g_f6 && have) SpawnBoss();
    g_f6 = f6;

    // --- меню открыто: курсор + блок управления.
    // Состояние игры запоминаем ОДИН раз при открытии и возвращаем в точности таким же при закрытии
    // (раньше принудительно ставили Locked/управление=true, из-за чего курсор пропадал и игра ломалась).
    bool menu = g_menuOpen.load() || g_picking.load();
    if (menu && (g_cfg.blockInput || g_picking.load())) {
        if (!g_menuApplied) {
            g_savedLock = mCurGet ? Unbox<int>(Call(mCurGet, nullptr), 0) : 0;
            g_savedVis = mCurVisGet ? Unbox<bool>(Call(mCurVisGet, nullptr), true) : true;
            g_savedCtl = have ? Rd<bool>(pl, oControl, true) : true;
            g_menuApplied = true;
        }
        int none = 0; if (mCurSet) Call(mCurSet, nullptr, { &none });
        bool v = true; if (mCurVis) Call(mCurVis, nullptr, { &v });
        if (have) Wr<bool>(pl, oControl, false);
    } else if (g_menuApplied) {
        RestoreCursor(have ? pl : nullptr);
    }
    g_wasMenu = menu;
    if (g_pickReq.load()) DoPick(have ? pl : nullptr);

    if (g_cfg.rewHold && (g_frame % 30 == 0)) ApplyRewardFields();
    if (g_cfg.noLimit) SetStaticInt(fCntMax, 9999);
    TickPending();
    if (g_frame % 30 == 0) {
        std::lock_guard<std::mutex> l(g_mx);
        g_goldNow = std::to_string(PsGet("GoldCount")); g_expNow = std::to_string(PsGet("LevelProgress")); g_lvlNow = std::to_string(PsGet("LevelCount"));
    }
    if (!have) { std::lock_guard<std::mutex> l(g_mx); g_esp.clear(); return; }

    // --- высокий прыжок: меняем ТОЛЬКО поля прыжка и только пока функция включена (значения проверяем на адекватность).
    // Быстрая ходьба сделана иначе (см. ниже, через CharacterController.Move) - поля скорости игры мы больше не трогаем.
    {
        bool want = g_cfg.highJump;
        if (want && !g_speedMod) { // запоминаем родные значения в момент включения
            g_baseJump = Rd<float>(pl, oJump, 5);
            g_baseFok = cFloat.mode >= 0;
            g_baseF[5] = (g_baseFok && oJumpF >= 0) ? cFloat.DecF((int*)((char*)pl + oJumpF)) : 0;
            g_baseOk = true; g_speedMod = true;
            Log("player %p: jump=%.2f jumpEnc=%.2f", pl, g_baseJump, g_baseF[5]);
        }
        if (want || g_speedMod) {
            float jm = want ? g_cfg.jumpMul : 1.f;
            if (oJump >= 0 && g_baseJump > 0.05f && g_baseJump < 200.f) Wr<float>(pl, oJump, g_baseJump * jm);
            if (oJumpF >= 0 && g_baseFok && g_baseF[5] > 0.05f && g_baseF[5] < 2000.f) SetFieldFloatEnc(pl, oJumpF, g_baseF[5] * jm);
            if (!want) { g_speedMod = false; g_baseOk = false; }
        }
    }

    // --- bhop
    bool space = KeyDown(VK_SPACE) && GameFocused() && !menu;
    if (g_cfg.bhop && space) {
        auto cc = kCC ? Call(mGetComp, pl, { TypeObj(kCC) }) : nullptr;
        bool grounded = cc ? Unbox<bool>(Call(mGrounded, cc), true) : true;
        bool t = true; if (fJumpWhile) il2cpp_field_static_set_value(fJumpWhile, &t);
        if (grounded) Wr<bool>(pl, oJumpFlag, true);
        g_jumpHeld = true;
    } else if (g_jumpHeld) { bool f = false; if (fJumpWhile) il2cpp_field_static_set_value(fJumpWhile, &f); g_jumpHeld = false; }

    // --- углы взгляда
    float yaw = 0, pitch = 0;
    if (oCharRot >= 0 && oCamRot >= 0) {
        Q4 qc = Rd<Q4>(pl, oCharRot), qm = Rd<Q4>(pl, oCamRot);
        yaw = WrapDeg(2.f * atan2f(qc.y, qc.w) * 57.29578f); pitch = WrapDeg(2.f * atan2f(qm.x, qm.w) * 57.29578f);
    }

    // --- быстрая ходьба: добавочное смещение в сторону движения через CharacterController.Move
    if (g_cfg.fastWalk && !menu && !g_cfg.noclip && mMove && oCharRot >= 0 && GameFocused()) {
        auto cc = kCC ? Call(mGetComp, pl, { TypeObj(kCC) }) : nullptr;
        if (cc) {
            V3 f{ sinf(yaw * 0.0174533f), 0, cosf(yaw * 0.0174533f) }, r{ cosf(yaw * 0.0174533f), 0, -sinf(yaw * 0.0174533f) };
            V3 mv{ 0, 0, 0 };
            if (KeyDown('W')) { mv.x += f.x; mv.z += f.z; }
            if (KeyDown('S')) { mv.x -= f.x; mv.z -= f.z; }
            if (KeyDown('D')) { mv.x += r.x; mv.z += r.z; }
            if (KeyDown('A')) { mv.x -= r.x; mv.z -= r.z; }
            float len = sqrtf(mv.x * mv.x + mv.z * mv.z);
            if (len > 0.01f) {
                float base = Rd<float>(pl, oWalk, 5.f); if (!(base > 0.5f && base < 100.f)) base = 5.f;
                float dt = Unbox<float>(Call(mDelta, nullptr), 0.016f);
                float k = std::max(0.f, g_cfg.walkMul - 1.f) * base * dt / len;
                V3 d{ mv.x * k, 0, mv.z * k };
                Call(mMove, cc, { &d });
            }
        }
    }

    // --- ноклип
    if (g_cfg.noclip && !menu) {
        auto cc = kCC ? Call(mGetComp, pl, { TypeObj(kCC) }) : nullptr;
        if (cc && mSetEnC) { bool f = false; Call(mSetEnC, cc, { &f }); }
        V3 f; ForwardFromAngles(yaw, pitch, f); V3 r{ cosf(yaw * 0.0174533f), 0, -sinf(yaw * 0.0174533f) };
        float dt = Unbox<float>(Call(mDelta, nullptr), 0.016f), sp = g_cfg.flySpeed * (KeyDown(VK_SHIFT) ? 3.f : 1.f) * dt;
        V3 mv{ 0, 0, 0 };
        if (KeyDown('W')) { mv.x += f.x; mv.y += f.y; mv.z += f.z; }
        if (KeyDown('S')) { mv.x -= f.x; mv.y -= f.y; mv.z -= f.z; }
        if (KeyDown('D')) { mv.x += r.x; mv.z += r.z; }
        if (KeyDown('A')) { mv.x -= r.x; mv.z -= r.z; }
        if (KeyDown(VK_SPACE)) mv.y += 1; if (KeyDown(VK_CONTROL)) mv.y -= 1;
        V3 np{ ppos.x + mv.x * sp, ppos.y + mv.y * sp, ppos.z + mv.z * sp };
        Call(mSetPos, TrOf(pl), { &np });
        g_wasNoclip = true;
    } else if (g_wasNoclip) {
        auto cc = kCC ? Call(mGetComp, pl, { TypeObj(kCC) }) : nullptr;
        if (cc && mSetEnC) { bool t = true; Call(mSetEnC, cc, { &t }); }
        g_wasNoclip = false;
    }

    UpdateLabels(pl, ppos);
    TickBots();

    // --- враги: ESP / чамсы / аим
    bool need = g_cfg.wh || g_cfg.aim;
    if (!need && g_frame % 20 != 0 && !g_cfg.wh) {
        if (!g_chams.empty()) { for (void* e : g_chams) { void* o = Rd<void*>(e, oWall); if (o) { bool f = false; Call(mSetEnB, o, { &f }); } } g_chams.clear(); }
        std::lock_guard<std::mutex> l(g_mx); g_esp.clear(); return;
    }
    auto enemies = FindAll(kEnemy);
    void* cam = Rd<void*>(pl, oCam);
    { std::lock_guard<std::mutex> l(g_mx); g_enemyCount = (int)enemies.size(); }
    if (!need) return;
    { // чистим кэш мёртвых
        std::unordered_set<void*> now(enemies.begin(), enemies.end());
        for (auto it = g_ec.begin(); it != g_ec.end();) it = now.count(it->first) ? ++it : g_ec.erase(it);
    }
    Il2CppObject* scrw = Call(mScrW, nullptr); Il2CppObject* scrh = Call(mScrH, nullptr);
    float sw = Unbox<int>(scrw, 1920), sh = Unbox<int>(scrh, 1080);

    std::vector<EspEnt> esp;
    bool boxes = g_cfg.wh && g_cfg.whMode != 0, chams = g_cfg.wh && g_cfg.whMode != 1;
    V3 camPos = ppos; if (cam) PosOf(cam, camPos);
    V3 fwd; ForwardFromAngles(yaw, pitch, fwd);
    if (g_cfg.aim && mSyncTr) Call(mSyncTr, nullptr); // физика обновляет коллайдеры анимированных ботов - иначе цель "отстаёт" от модели
    void* best = nullptr; V3 bestPt{}; float bestAng = g_cfg.aimFov;

    for (void* e : enemies) {
        int hp = Rd<int>(e, oHealth, 1);
        float hpAll = Rd<float>(e, oHealthAll, 0.f);
        if (hp <= 0 && oHealth >= 0 && hpAll > 0.f) continue; // мёртвый
        V3 feet; if (!PosOf(e, feet)) continue;
        auto& c = g_ec[e]; if (!c.built) BuildCache(e, c);
        // чамсы
        void* ol = Rd<void*>(e, oWall);
        if (ol && mSetEnB) {
            if (chams && !g_chams.count(e)) {
                int mode = 0; Col4 col{ 1.f, 0.15f, 0.15f, 1.f }; float w = 5.f; bool t = true;
                if (mOutMode) Call(mOutMode, ol, { &mode }); if (mOutColor) Call(mOutColor, ol, { &col });
                if (mOutWidth) Call(mOutWidth, ol, { &w }); Call(mSetEnB, ol, { &t }); g_chams.insert(e);
            } else if (!chams && g_chams.count(e)) { bool f = false; Call(mSetEnB, ol, { &f }); g_chams.erase(e); }
        }
        // боксы
        if (boxes && cam) {
            V3 top{ feet.x, feet.y + g_cfg.enemyH, feet.z }; float x1, y1, x2, y2;
            if (W2S(cam, feet, x1, y1) && W2S(cam, top, x2, y2)) {
                float h = fabsf(y1 - y2), w = h * 0.5f; EspEnt en{};
                en.x1 = x1 - w / 2; en.x2 = x1 + w / 2; en.y1 = std::min(y1, y2); en.y2 = std::max(y1, y2);
                en.hp = hp; en.hasHp = g_cfg.espHealth && oHealth >= 0 && hp > 0; en.sx = x1; en.sy = y1; esp.push_back(en);
            }
        }
        // аим: точка цели
        if (g_cfg.aim) {
            V3 pt{}; bool got = false;
            void* col = g_cfg.aimPart == 0 ? c.head : g_cfg.aimPart == 1 ? c.body : c.legs;
            got = PointOf(col, pt);
            if (got && g_cfg.aimPart == 0) pt.y += g_cfg.headUp;
            if (!got) { // запасной вариант - по росту врага
                float k = g_cfg.aimPart == 0 ? (g_cfg.enemyH - g_cfg.headFix) : g_cfg.aimPart == 1 ? g_cfg.enemyH * 0.6f : g_cfg.enemyH * 0.2f;
                pt = { feet.x, feet.y + k, feet.z };
            }
            V3 d{ pt.x - camPos.x, pt.y - camPos.y, pt.z - camPos.z };
            float len = sqrtf(d.x * d.x + d.y * d.y + d.z * d.z); if (len < 0.01f) continue;
            float dot = (d.x * fwd.x + d.y * fwd.y + d.z * fwd.z) / len;
            float ang = acosf(std::max(-1.f, std::min(1.f, dot))) * 57.29578f;
            if (ang < bestAng) { bestAng = ang; best = e; bestPt = pt; }
        }
    }
    { std::lock_guard<std::mutex> l(g_mx); g_esp = std::move(esp); g_scrW = sw; g_scrH = sh; }

    if (g_cfg.aim && best && !menu && GameFocused() && oCharRot >= 0 && oCamRot >= 0) {
        V3 d{ bestPt.x - camPos.x, bestPt.y - camPos.y, bestPt.z - camPos.z };
        float ty = atan2f(d.x, d.z) * 57.29578f;
        float tp = -atan2f(d.y, sqrtf(d.x * d.x + d.z * d.z)) * 57.29578f;
        float t = std::max(0.02f, 1.f - std::min(0.98f, g_cfg.aimSmooth));
        float ny = yaw + WrapDeg(ty - yaw) * t, np = pitch + WrapDeg(tp - pitch) * t;
        np = std::max(-89.f, std::min(89.f, np));
        const float h = 0.5f * 0.0174533f;
        Q4 qy{ 0, sinf(ny * h), 0, cosf(ny * h) }, qx{ sinf(np * h), 0, 0, cosf(np * h) };
        Wr<Q4>(pl, oCharRot, qy); Wr<Q4>(pl, oCamRot, qx);
    }
}
// Возврат игры в исходное состояние перед выгрузкой DLL (вызывается из игрового потока)
inline void Cleanup() {
    void* pl = g_player; bool ok = pl && TrOf(pl);
    if (ok && g_speedMod) {
        if (oJump >= 0 && g_baseJump > 0.05f && g_baseJump < 200.f) Wr<float>(pl, oJump, g_baseJump);
        if (oJumpF >= 0 && g_baseFok && g_baseF[5] > 0.05f && g_baseF[5] < 2000.f) SetFieldFloatEnc(pl, oJumpF, g_baseF[5]);
    }
    g_speedMod = false;
    if (ok && g_wasNoclip) {
        auto cc = kCC ? Call(mGetComp, pl, { TypeObj(kCC) }) : nullptr;
        if (cc && mSetEnC) { bool t = true; Call(mSetEnC, cc, { &t }); }
    }
    g_wasNoclip = false;
    if (g_jumpHeld) { bool f = false; if (fJumpWhile) il2cpp_field_static_set_value(fJumpWhile, &f); g_jumpHeld = false; }
    RestoreCursor(ok ? pl : nullptr);
    for (void* e : g_chams) { void* o = Rd<void*>(e, oWall); if (o) { bool f = false; Call(mSetEnB, o, { &f }); } }
    g_chams.clear();
    { std::lock_guard<std::mutex> l(g_mx); g_labels.clear(); }
    g_picking = false; g_pickReq = false;
    ResetBots();
}
} // namespace G
