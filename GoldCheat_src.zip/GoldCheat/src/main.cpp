// GoldCheat - оверлей (D3D11 + ImGui), хуки и UI. Игровая логика в game.h.
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <cstdarg>
#include <cstdio>
#include <string>
#include <algorithm>
#include <cctype>
#include <atomic>
#include <set>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "MinHook.h"
#include "game.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

// ------------------------------------------------------------------ лог
static HMODULE g_self; static CRITICAL_SECTION g_logCs; static char g_logPath[MAX_PATH];
void Log(const char* fmt, ...) {
    char buf[1024]; va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    EnterCriticalSection(&g_logCs);
    if (FILE* f = fopen(g_logPath, "ab")) { SYSTEMTIME t; GetLocalTime(&t); fprintf(f, "[%02d:%02d:%02d] %s\r\n", t.wHour, t.wMinute, t.wSecond, buf); fclose(f); }
    LeaveCriticalSection(&g_logCs);
}

// ------------------------------------------------------------------ хуки игры
typedef void(__cdecl* tUpd)(void*, const MethodInfo*);
typedef void(__cdecl* tHit)(void*, float, int, void*, const MethodInfo*);
typedef void(__cdecl* tTrig)(void*, void*, const MethodInfo*);
typedef int(__cdecl* tMove)(void*, V3, const MethodInfo*);
static tUpd oUpd; static tHit oHit; static tTrig oTrig; static tMove oMove;
static bool g_hitHooked = false;
static int g_moveErrors = 0;
static int g_tickErrors = 0;
static std::atomic<bool> g_unload{ false }, g_gameClean{ false }, g_overlayDown{ false };

// MSVC: вызовы обёрнуты в SEH, чтобы исключение в моде не роняло игру. MinGW/clang-gnu SEH не умеют - там вызываем напрямую.
#ifdef _MSC_VER
#define GC_TRY __try
#define GC_EXCEPT(...) __except (EXCEPTION_EXECUTE_HANDLER) { __VA_ARGS__ }
#else
#define GC_TRY
#define GC_EXCEPT(...)
#endif
static void SafeTick() {
    GC_TRY { G::Tick(); }
    GC_EXCEPT(g_tickErrors++; Log("Tick exception #%d", g_tickErrors);)
}
static void SafeCleanup() {
    GC_TRY { G::Cleanup(); }
    GC_EXCEPT(Log("Cleanup exception");)
}
static void __cdecl hkUpd(void* self, const MethodInfo* mi) {
    oUpd(self, mi);
    if (g_unload) { if (!g_gameClean) { SafeCleanup(); g_gameClean = true; } return; } // выгрузка: возвращаем игру как было
    if (g_ready && g_tickErrors < 50) SafeTick();
}
static void __cdecl hkHit(void* self, float dmg, int part, void* enemy, const MethodInfo* mi) {
    G::OnHit();   // награда за килл: дозачисление
    // урон по боссу с любого оружия: если игра сама удар по боссу не засчитала - засчитываем (см. G::BossHit)
    if (!g_unload && g_ready && G::BossHit(self, dmg, part, enemy, [&] { oHit(self, dmg, part, enemy, mi); })) return;
    oHit(self, dmg, part, enemy, mi);
}
// хуки Time.set_timeScale / get_timeScale (см. G::TickTime)
static void __cdecl hkSetTS(float v, const MethodInfo* mi) {
    G::g_tsGame = v;                                                 // что игра хочет видеть
    float eff = v;
    if (!g_unload && g_cfg.timeOn && v > 0.0001f) eff = v * G::TsMul();   // пауза (0) остаётся паузой
    G::oSetTS(eff, mi);
}
static float __cdecl hkGetTS(const MethodInfo* mi) {
    if (!g_unload && g_cfg.timeOn) return G::g_tsGame;               // игра читает своё значение, а не ускоренное
    return G::oGetTS(mi);
}
static void SafeMove(void* self, V3& mv) {
    GC_TRY { G::OnMove(self, mv); }
    GC_EXCEPT(g_moveErrors++; if (g_moveErrors <= 5) Log("OnMove exception #%d", g_moveErrors);)
}
static int __cdecl hkMove(void* self, V3 mv, const MethodInfo* mi) {   // CharacterController.Move(Vector3): вектор движения подменяем здесь
    if (g_ready && !g_unload && g_moveErrors < 50) SafeMove(self, mv);
    return oMove(self, mv, mi);
}
static void __cdecl hkTrig(void* self, void* col, const MethodInfo* mi) {
    if (g_cfg.god && !g_unload) return; // бессмертие: триггер поражения не срабатывает
    oTrig(self, col, mi);
}
static bool HookMethod(const MethodInfo* m, void* detour, void** orig, const char* name) {
    if (!m) { Log("hook %s: метод не найден", name); return false; }
    void* target = *(void**)m; // methodPointer - первое поле MethodInfo
    bool ok = MH_CreateHook(target, detour, orig) == MH_OK && MH_EnableHook(target) == MH_OK;
    Log("hook %s @ %p: %s", name, target, ok ? "ok" : "FAIL");
    return ok;
}

// ------------------------------------------------------------------ выгрузка
static DWORD WINAPI UnloadThread(LPVOID) {
    Log("unload: старт");
    for (int i = 0; i < 80 && !(g_gameClean && g_overlayDown); i++) Sleep(50); // ждём, пока игровой и рендер-потоки всё вернут
    MH_DisableHook(MH_ALL_HOOKS);
    Sleep(500);                       // даём доработать потокам, которые ещё внутри наших хуков
    MH_Uninitialize();
    Log("unload: готово");
    FreeLibraryAndExitThread(g_self, 0);
    return 0;
}
static void RequestUnload() {
    if (g_unload.exchange(true)) return;
    g_menuOpen = false; g_ready = false; g_picking = false;
    CreateThread(nullptr, 0, UnloadThread, nullptr, 0, nullptr);
}

// ------------------------------------------------------------------ UI
static void Style() {
    ImGui::StyleColorsDark();
    auto& s = ImGui::GetStyle(); auto* c = s.Colors;
    s.WindowRounding = 4; s.FrameRounding = 2; s.GrabRounding = 2; s.TabRounding = 2;
    c[ImGuiCol_WindowBg] = ImVec4(0.04f, 0.05f, 0.08f, 0.96f);
    c[ImGuiCol_TitleBg] = c[ImGuiCol_TitleBgActive] = ImVec4(0.14f, 0.27f, 0.50f, 1);
    c[ImGuiCol_FrameBg] = ImVec4(0.10f, 0.16f, 0.30f, 1);
    c[ImGuiCol_Button] = ImVec4(0.14f, 0.27f, 0.50f, 1);
    c[ImGuiCol_ButtonHovered] = ImVec4(0.20f, 0.36f, 0.65f, 1);
    c[ImGuiCol_Tab] = ImVec4(0.14f, 0.27f, 0.50f, 1);
    c[ImGuiCol_TabHovered] = ImVec4(0.22f, 0.40f, 0.72f, 1);
    c[ImGuiCol_TabActive] = ImVec4(0.20f, 0.36f, 0.65f, 1);
    c[ImGuiCol_CheckMark] = c[ImGuiCol_SliderGrab] = ImVec4(0.26f, 0.55f, 0.98f, 1);
}

static char g_filter[64] = ""; static char g_key[96] = "GoldCount"; static char g_strVal[128] = ""; static int g_keyVal = 0;
static int g_sel = -1; static uint32_t g_selH = 0; static std::string g_selName; static V3 g_selPos{}; static V3 g_tgt{ 0, 0, 0 };
static bool g_wipeOk = false;
static V3 g_selScale{ 1, 1, 1 }, g_selScaleIn{ 1, 1, 1 }; static bool g_selScaleFresh = false; static int g_scrollTo = -1; static float g_uniScale = 1.f;
static void QueueReadScale(uint32_t h) { // читаем текущий размер выбранного объекта в игровом потоке
    Enqueue([h] { void* t = il2::il2cpp_gchandle_get_target(h); if (!t) return; V3 sc = G::GetScaleOf(t); std::lock_guard<std::mutex> l(g_mx); g_selScaleIn = sc; g_selScaleFresh = true; });
}
static std::set<uint32_t> g_multi; static int g_lastClick = -1; static unsigned g_seenVer = 0; static bool g_cmdAll = false, g_cmdCopy = false;

static void* Tgt(uint32_t h) { return il2::il2cpp_gchandle_get_target(h); }

static void TabCurrency() {
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Голда", &g_cfg.goldSet, 0, 0);
    if (ImGui::Button("Установить")) { int v = g_cfg.goldSet; Enqueue([v] { G::SetGold(v); }); }
    { std::lock_guard<std::mutex> l(g_mx); ImGui::Text("Сейчас: %s", g_goldNow.c_str()); }
    ImGui::Separator();
    ImGui::TextUnformatted("Награда за убийство (режим полигона) — голова и тело:");
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Голда за килл", &g_cfg.rewGold, 100, 1000);
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Опыт за килл", &g_cfg.rewExp, 100, 1000);
    if (ImGui::Button("Применить")) { g_cfg.rewHold = true; Enqueue([] { G::ApplyRewardFields(); Say("Награда применена и будет удерживаться"); }); }
    ImGui::Checkbox("Дозачислять, если игра не дала награду (ограничения, например 999 опыта)", &g_cfg.topUp);
    ImGui::Separator();
    ImGui::TextUnformatted("Опыт:");
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Добавить опыт", &g_cfg.expAdd, 1000, 10000);
    ImGui::SameLine(); if (ImGui::Button("Накрутить")) { int v = g_cfg.expAdd; Enqueue([v] { G::AddExp(v); }); }
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Уровень", &g_cfg.levelSet, 1, 10);
    ImGui::SameLine(); if (ImGui::Button("Задать уровень")) { int v = g_cfg.levelSet; Enqueue([v] { G::SetLevel(v); }); }
    { std::lock_guard<std::mutex> l(g_mx); ImGui::Text("Опыт (LevelProgress): %s   Уровень (LevelCount): %s", g_expNow.c_str(), g_lvlNow.c_str()); }
    ImGui::Separator();
    ImGui::TextUnformatted("Достижения (открой экран достижений в игре):");
    if (ImGui::Button("Выполнить текущий уровень всех")) Enqueue([] { G::DoAchievements(1); });
    ImGui::SameLine(); if (ImGui::Button("Пройти все уровни до конца")) Enqueue([] { G::DoAchievements(1000); });
}
static void TabPlayer() {
    { std::lock_guard<std::mutex> l(g_mx); ImGui::TextColored(g_playerFound ? ImVec4(0.4f, 1, 0.4f, 1) : ImVec4(1, 0.5f, 0.4f, 1), g_playerFound ? "PlayerController найден" : "PlayerController не найден (зайди в игровую сцену)"); }
    ImGui::TextDisabled("Хук движения: %s  (вызовов Move игрока: %d)", G::g_moveHooked ? "активен" : "НЕ встал, работает запасной режим", G::g_moveHits.load());
    ImGui::Checkbox("Быстрый бхоп (держи пробел)", &g_cfg.bhop);
    if (g_cfg.bhop) { ImGui::SameLine(); ImGui::TextDisabled("проверок %d, прыжков %d", G::g_bhopSeen.load(), G::g_bhopFired.load()); }
    ImGui::Checkbox("Ускоренная ходьба", &g_cfg.fastWalk); ImGui::SameLine(); ImGui::SetNextItemWidth(200); ImGui::SliderFloat("Скорость (x)", &g_cfg.walkMul, 1.f, 10.f);
    ImGui::Checkbox("Высокий прыжок", &g_cfg.highJump); ImGui::SameLine(); ImGui::SetNextItemWidth(200); ImGui::SliderFloat("Высота прыжка (x)", &g_cfg.jumpMul, 1.f, 10.f);
    ImGui::Checkbox("Бессмертие (босс/поражение не убивает)", &g_cfg.god);
    ImGui::Checkbox("Ноуклип / полёт (WASD, Пробел вверх, Ctrl вниз, Shift быстрее)", &g_cfg.noclip);
    ImGui::SetNextItemWidth(260); ImGui::SliderFloat("Скорость полёта (м/с)", &g_cfg.flySpeed, 2.f, 60.f);
    ImGui::Separator();
    ImGui::Checkbox("Скорость времени", &g_cfg.timeOn); ImGui::SameLine(); ImGui::SetNextItemWidth(220);
    ImGui::SliderFloat("Время (x)", &g_cfg.timeMul, 0.1f, 10.f, "%.2f", ImGuiSliderFlags_Logarithmic);
    ImGui::TextDisabled("1 = обычная скорость, меньше 1 - замедление. Хук времени: %s. Игра не видит подмену, меню Esc работает как обычно.", G::g_tsHooked ? "активен" : "НЕ встал (запасной режим)");
}
static void TabEnemies() {
    ImGui::Checkbox("Задать HP босса Шурика", &g_cfg.bossHpOn);
    ImGui::SetNextItemWidth(300); ImGui::SliderInt("HP босса", &g_cfg.bossHp, 100, 1000000, "%d", ImGuiSliderFlags_Logarithmic);
    if (ImGui::IsItemDeactivatedAfterEdit() && g_cfg.bossHpOn) Enqueue([] { G::BossHpNow(); });
    ImGui::SameLine(); if (ImGui::Button("Применить к текущему")) Enqueue([] { G::BossHpNow(); });
    ImGui::TextDisabled("По умолчанию 2500. HP ставится при появлении босса.");
    ImGui::Checkbox("Урон по боссу Шурику с ЛЮБОГО оружия", &g_cfg.bossAnyWeapon);
    ImGui::TextDisabled("Хук удара: %s.  Ударов по боссу: %d (родных %d, через тип оружия %d, напрямую %d)", g_hitHooked ? "активен" : "НЕ встал",
        G::g_bossHits.load(), G::g_bossNative.load(), G::g_bossSwap.load(), G::g_bossDirect.load());
    if (ImGui::Button("Вызвать босса (F6) — на любой карте")) Enqueue([] { G::SpawnBoss(); });
    ImGui::SameLine(); if (ImGui::Button("Убрать всех ботов")) Enqueue([] { G::RemoveBots(); });
    ImGui::Checkbox("Снять лимит ботов", &g_cfg.noLimit); ImGui::SameLine(); ImGui::SetNextItemWidth(120);
    ImGui::InputInt("Лимит", &g_cfg.botLimit, 0, 0); g_cfg.botLimit = std::max(1, std::min(g_cfg.botLimit, 100000));
    ImGui::TextDisabled("Лимит ботов пишется родным конвертером игры: %s", G::cInt.conv ? "конвертер найден" : (G::cInt.ctor ? "только конструктор (запасной)" : "НЕ найден - лимит не снимется"));
    { std::lock_guard<std::mutex> l(g_mx); ImGui::Text("Врагов на сцене: %d", g_enemyCount); }
    ImGui::Separator();
    ImGui::TextUnformatted("Размер ботов (1 = обычный; влево - меньше, ниже 0 - зеркально; вправо до 100):");
    const ImGuiSliderFlags lf = ImGuiSliderFlags_Logarithmic;
    ImGui::Checkbox("Менять размер ВСЕХ ботов", &g_cfg.botScaleOn);
    static bool uni = true; ImGui::SameLine(); ImGui::Checkbox("Единый размер", &uni);
    ImGui::SetNextItemWidth(320);
    if (uni) { float u = g_cfg.botScale.x; if (ImGui::SliderFloat("Размер (x)", &u, -100.f, 100.f, "%.2f", lf)) g_cfg.botScale = { u, u, u }; }
    else ImGui::SliderFloat3("Размер X  Y  Z", &g_cfg.botScale.x, -100.f, 100.f, "%.2f", lf);
    ImGui::SameLine(); if (ImGui::Button("Сбросить")) { g_cfg.botScaleOn = false; g_cfg.botScale = { 1, 1, 1 }; }
    ImGui::TextDisabled("Широкий бот: X и Z больше, Y = 1. Ползунки идут и влево (меньше 1, ниже 0 - бот зеркально). Ctrl+клик по ползунку - ввод числа.");
    g_wantBots = true; // пока вкладка открыта, игровой поток обновляет список ботов
    std::vector<BotEnt> bots; { std::lock_guard<std::mutex> l(g_mx); bots = g_bots; }
    ImGui::Text("Боты на сцене: %d", (int)bots.size());
    ImGui::BeginChild("bots", ImVec2(0, 230), true);
    for (size_t i = 0; i < bots.size(); i++) {
        auto& b = bots[i]; ImGui::PushID((int)i); uintptr_t id = b.id;
        ImGui::Text("#%d  %s   HP: %d   (%.1f, %.1f, %.1f)", (int)i + 1, b.name.c_str(), b.hp, b.pos.x, b.pos.y, b.pos.z);
        V3 sc = b.scale; ImGui::SetNextItemWidth(300);
        if (ImGui::SliderFloat3("##sc", &sc.x, -100.f, 100.f, "%.2f", lf)) Enqueue([id, sc] { void* p = (void*)id; auto L = G::FindAll(G::kEnemy); if (std::find(L.begin(), L.end(), p) != L.end()) G::SetBotScale(p, sc); });
        ImGui::SameLine(); if (ImGui::Button("x1")) Enqueue([id] { void* p = (void*)id; auto L = G::FindAll(G::kEnemy); if (std::find(L.begin(), L.end(), p) != L.end()) G::SetBotScale(p, { 1, 1, 1 }); });
        ImGui::SameLine(); if (ImGui::Button("В инспектор")) Enqueue([id] { void* p = (void*)id; auto L = G::FindAll(G::kEnemy); if (std::find(L.begin(), L.end(), p) != L.end()) G::SelectInInspector(G::TrOf(p)); });
        ImGui::Separator(); ImGui::PopID();
    }
    ImGui::EndChild();
}
static void TabEsp() {
    ImGui::Checkbox("WallHack", &g_cfg.wh);
    ImGui::RadioButton("Чамсы", &g_cfg.whMode, 0); ImGui::SameLine(); ImGui::RadioButton("Боксы", &g_cfg.whMode, 1); ImGui::SameLine(); ImGui::RadioButton("Оба", &g_cfg.whMode, 2);
    ImGui::Checkbox("Здоровье", &g_cfg.espHealth); ImGui::SameLine(); ImGui::Checkbox("Линии", &g_cfg.espLines);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Высота врага (боксы/аим)", &g_cfg.enemyH, 1.0f, 3.0f);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Поправка по голове (м)", &g_cfg.headFix, 0.0f, 0.5f);
    { std::lock_guard<std::mutex> l(g_mx); ImGui::Text("Врагов на сцене: %d", g_enemyCount); }
    ImGui::Separator();
    ImGui::Checkbox("Аим", &g_cfg.aim);
    ImGui::RadioButton("Голова", &g_cfg.aimPart, 0); ImGui::SameLine(); ImGui::RadioButton("Тело", &g_cfg.aimPart, 1); ImGui::SameLine(); ImGui::RadioButton("Ноги", &g_cfg.aimPart, 2);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Смещение по голове (вверх, м)", &g_cfg.headUp, -0.3f, 0.3f);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Плавность", &g_cfg.aimSmooth, 0.0f, 0.95f);
    ImGui::SetNextItemWidth(300); ImGui::SliderFloat("Угол захвата", &g_cfg.aimFov, 5.f, 180.f);
}
static void TabItems() {
    ImGui::TextWrapped("Скинченджер (экспериментально): добавить в инвентарь предметы из каталога игры. Открой инвентарь в меню игры.");
    if (ImGui::Button("Выдать все предметы")) Enqueue([] { G::DoGiveItems(); });
}
static void TabScene() {
    V3 me; { std::lock_guard<std::mutex> l(g_mx); me = g_playerPos; }
    ImGui::Text("Игрок: %.2f  %.2f  %.2f", me.x, me.y, me.z);
    ImGui::SetNextItemWidth(330); ImGui::DragFloat3("XYZ", &g_tgt.x, 0.1f);
    ImGui::SameLine(); if (ImGui::Button("Моя позиция")) g_tgt = me;
    if (ImGui::Button("Телепорт игрока в XYZ")) { V3 p = g_tgt; Enqueue([p] { G::Teleport(p); Say("Телепорт в заданные координаты"); }); }
    ImGui::SameLine(); if (ImGui::Button("Обновить список объектов")) Enqueue([] { G::SceneRefresh(); g_sel = -1; Say("Объектов в списке: " + std::to_string(g_scene.size())); });
    if (ImGui::Button("Выбрать объект мышкой")) { g_picking = true; g_menuOpen = false; Say("Выбор: кликни ЛКМ по объекту в игре (Esc - отмена)"); }
    ImGui::SameLine(); ImGui::TextDisabled("меню скроется, кликни по объекту - он выделится здесь");
    { // результат выбора мышкой
        uint32_t ph = g_pickedH.exchange(0);
        if (ph) {
            g_filter[0] = 0;
            std::lock_guard<std::mutex> l(g_mx);
            for (int i = 0; i < (int)g_scene.size(); i++) if (g_scene[i].h == ph) {
                auto& e = g_scene[i]; g_multi.clear(); g_multi.insert(ph); g_sel = i; g_selH = ph; g_selName = e.name; g_selPos = e.pos; g_lastClick = i; g_scrollTo = i;
                if (!e.active) g_cfg.sceneOnlyActive = false;
                break;
            }
            g_seenVer = g_sceneVer;
        }
        if (ph) QueueReadScale(ph);
    }
    { std::lock_guard<std::mutex> l(g_mx); if (g_selScaleFresh) { g_selScale = g_selScaleIn; g_uniScale = g_selScaleIn.x; g_selScaleFresh = false; } }
    ImGui::SetNextItemWidth(250); ImGui::InputText("Фильтр", g_filter, sizeof g_filter);
    ImGui::SameLine(); ImGui::Checkbox("Только включённые", &g_cfg.sceneOnlyActive);
    std::string flt = g_filter; std::transform(flt.begin(), flt.end(), flt.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    { std::lock_guard<std::mutex> l(g_mx); g_labelFilter = flt; }
    ImGui::Checkbox("Показывать названия возле объектов", &g_cfg.sceneLabels);
    if (g_cfg.sceneLabels) {
        ImGui::SameLine(); ImGui::SetNextItemWidth(130); ImGui::SliderFloat("Радиус (м)", &g_cfg.labelDist, 5.f, 200.f);
        ImGui::SameLine(); ImGui::SetNextItemWidth(110); ImGui::SliderInt("Макс.", &g_cfg.labelMax, 10, 300);
        ImGui::TextDisabled("Подписи берутся из списка (нажми «Обновить список объектов»). Фильтр выше сужает подписи.");
    }
    ImGuiIO& sio = ImGui::GetIO();
    { std::lock_guard<std::mutex> l(g_mx); if (g_sceneVer != g_seenVer) { g_seenVer = g_sceneVer; g_multi.clear(); g_sel = -1; g_lastClick = -1; } }
    ImGui::Text("Выбрано: %d", (int)g_multi.size());
    ImGui::SameLine(); if (ImGui::Button("Выбрать все (Ctrl+A)")) g_cmdAll = true;
    ImGui::SameLine(); if (ImGui::Button("Снять выделение")) { g_multi.clear(); g_sel = -1; }
    ImGui::SameLine(); if (ImGui::Button("Копировать (Ctrl+C)")) g_cmdCopy = true;
    uint32_t readH = 0;
    ImGui::BeginChild("objs", ImVec2(0, 190), true);
    {
        std::lock_guard<std::mutex> l(g_mx); int shown = 0; std::vector<int> vis; int clicked = -1; readH = 0;
        for (int i = 0; i < (int)g_scene.size(); i++) {
            auto& e = g_scene[i];
            if (shown >= 500 && i != g_scrollTo && !g_multi.count(e.h)) continue;
            if (g_cfg.sceneOnlyActive && !e.active) continue;
            if (!flt.empty()) { std::string n = e.name; std::transform(n.begin(), n.end(), n.begin(), [](unsigned char c) { return (char)std::tolower(c); }); if (n.find(flt) == std::string::npos) continue; }
            shown++; vis.push_back(i);
            char lab[256]; snprintf(lab, sizeof lab, "%s%s  (%.1f, %.1f, %.1f)###o%d", e.active ? "" : "[выкл] ", e.name.c_str(), e.pos.x, e.pos.y, e.pos.z, i);
            if (ImGui::Selectable(lab, g_multi.count(e.h) > 0)) {
                if (sio.KeyShift && g_lastClick >= 0) clicked = i;
                else {
                    if (sio.KeyCtrl) { if (!g_multi.erase(e.h)) g_multi.insert(e.h); } else { g_multi.clear(); g_multi.insert(e.h); }
                    g_lastClick = i;
                }
                g_sel = i; g_selH = e.h; g_selName = e.name; g_selPos = e.pos; readH = e.h; // читать размер будем после снятия блокировки
            }
            if (i == g_scrollTo) { ImGui::SetScrollHereY(0.5f); g_scrollTo = -1; }
        }
        if (clicked >= 0) { // Shift+клик: диапазон от прошлого клика
            int lo = std::min(clicked, g_lastClick), hi = std::max(clicked, g_lastClick);
            if (!sio.KeyCtrl) g_multi.clear();
            for (int i : vis) if (i >= lo && i <= hi) g_multi.insert(g_scene[i].h);
        }
        bool active = (ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows) || ImGui::IsWindowFocused(ImGuiFocusedFlags_ChildWindows)) && !sio.WantTextInput;
        if (active && sio.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_A, false)) g_cmdAll = true;
        if (active && sio.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_C, false)) g_cmdCopy = true;
        if (g_cmdAll) { for (int i : vis) g_multi.insert(g_scene[i].h); g_cmdAll = false; }
        if (g_cmdCopy) { // копируем выбранные (в порядке списка): "имя (x, y, z)"
            std::string txt; int n = 0;
            for (auto& e : g_scene) if (g_multi.count(e.h)) { char ln[320]; snprintf(ln, sizeof ln, "%s (%.2f, %.2f, %.2f)\n", e.name.c_str(), e.pos.x, e.pos.y, e.pos.z); txt += ln; n++; }
            if (n) { ImGui::SetClipboardText(txt.c_str()); g_status = "Скопировано в буфер: " + std::to_string(n) + " объектов"; }
            else g_status = "Нечего копировать: ничего не выбрано";
            g_cmdCopy = false;
        }
    }
    ImGui::EndChild();
    if (readH) QueueReadScale(readH);
    if (g_sel >= 0) {
        ImGui::Text("Выбран: %s", g_selName.c_str());
        ImGui::SetNextItemWidth(330); ImGui::DragFloat3("Позиция объекта", &g_selPos.x, 0.1f);
        uint32_t h = g_selH; V3 sp = g_selPos;
        if (ImGui::Button("ТП к объекту")) Enqueue([h] { void* t = Tgt(h); V3 p; if (t && G::PosOf(t, p)) { G::Teleport({ p.x, p.y + 1.2f, p.z }); Say("Телепорт к объекту"); } else Say("Объект уже недоступен"); });
        ImGui::SameLine(); if (ImGui::Button("Объект ко мне")) Enqueue([h] { void* t = Tgt(h); V3 p = g_playerPos; p.y += 1; if (t && G::TrOf(t)) { G::Call(G::mSetPos, G::TrOf(t), { &p }); Say("Объект перемещён к игроку"); } });
        ImGui::SameLine(); if (ImGui::Button("Применить позицию")) Enqueue([h, sp] { void* t = Tgt(h); V3 p = sp; if (t && G::TrOf(t)) { G::Call(G::mSetPos, G::TrOf(t), { &p }); Say("Позиция объекта изменена"); } });
        if (ImGui::Button("Вкл/выкл объект")) Enqueue([h] { void* t = Tgt(h); auto go = t ? G::Call(G::mGetGO, t) : nullptr; if (go) { bool a = il2::Unbox<bool>(G::Call(G::mActiveSelf, go), true); bool n = !a; G::Call(G::mSetActive, go, { &n }); Say(n ? "Объект включён" : "Объект выключен"); } });
        ImGui::SameLine(); if (ImGui::Button("Удалить объект")) Enqueue([h] { void* t = Tgt(h); auto go = t ? G::Call(G::mGetGO, t) : nullptr; if (go) { G::Call(G::mDestroy, nullptr, { go }); Say("Объект удалён"); } });
        ImGui::SameLine(); if (ImGui::Button("Скопировать в XYZ")) g_tgt = g_selPos;
        ImGui::Separator();
        ImGui::SetNextItemWidth(330); ImGui::DragFloat3("Размер XYZ", &g_selScale.x, 0.05f, -1000.f, 1000.f);
        ImGui::SameLine(); if (ImGui::Button("Применить размер")) { V3 s2 = g_selScale; Enqueue([h, s2] { void* t = Tgt(h); if (t && G::SetScaleOf(t, s2)) Say("Размер объекта изменён"); else Say("Объект уже недоступен"); }); }
        ImGui::SetNextItemWidth(330);
        if (ImGui::SliderFloat("Общий размер", &g_uniScale, -100.f, 100.f, "%.2f", ImGuiSliderFlags_Logarithmic)) { g_selScale = { g_uniScale, g_uniScale, g_uniScale }; V3 s2 = g_selScale; Enqueue([h, s2] { void* t = Tgt(h); if (t) G::SetScaleOf(t, s2); }); }
        ImGui::SameLine(); if (ImGui::Button("Размер = 1")) { g_selScale = { 1, 1, 1 }; g_uniScale = 1.f; Enqueue([h] { void* t = Tgt(h); if (t) G::SetScaleOf(t, { 1, 1, 1 }); }); }
    }
}
static void TabKey() {
    ImGui::InputText("Ключ", g_key, sizeof g_key);
    ImGui::SetNextItemWidth(220); ImGui::InputInt("Значение", &g_keyVal, 1, 1000);
    ImGui::InputText("Строка", g_strVal, sizeof g_strVal);
    std::string k = g_key; int v = g_keyVal; std::string sv = g_strVal;
    if (ImGui::Button("Прочитать (защищённое)")) Enqueue([k] { Say(k + " = " + std::to_string(G::PsGet(k.c_str()))); });
    ImGui::SameLine(); if (ImGui::Button("Записать число (защищённое)")) Enqueue([k, v] { G::PsSet(k.c_str(), v); G::PrefsSave(); G::RefreshMoney(); Say("Записано: " + k + " = " + std::to_string(v)); });
    if (ImGui::Button("Записать число (обычное)")) Enqueue([k, v] { auto ks = il2::Str(k.c_str()); int vv = v; G::Call(G::mPrefsSetInt, nullptr, { ks, &vv }); G::PrefsSave(); Say("Записано (обычное): " + k); });
    ImGui::SameLine(); if (ImGui::Button("Записать строку")) Enqueue([k, sv] { G::Call(G::mPrefsSetStr, nullptr, { il2::Str(k.c_str()), il2::Str(sv.c_str()) }); G::PrefsSave(); Say("Строка записана: " + k); });
}
static void TabOptions() {
    ImGui::Checkbox("Блокировать управление, пока меню открыто", &g_cfg.blockInput);
    ImGui::Checkbox("Показывать надпись GoldCheat", &g_cfg.watermark);
    ImGui::TextUnformatted("Клавиша меню: Home");
    ImGui::Separator();
    if (ImGui::Button("Выгрузить чит из игры")) RequestUnload();
    ImGui::SameLine(); ImGui::TextDisabled("(вернёт настройки игры и отключит все хуки)");
    ImGui::Separator();
    ImGui::TextUnformatted("Жёсткая очистка: удаляет ВСЕ сохранения игры (PlayerPrefs)");
    ImGui::Checkbox("Я понимаю, что прогресс пропадёт", &g_wipeOk);
    if (g_wipeOk && ImGui::Button("Очистить всё")) { g_wipeOk = false; Enqueue([] { G::Call(G::mPrefsDelAll, nullptr); G::PrefsSave(); Say("Все сохранения PlayerPrefs удалены. Перезапусти игру."); }); }
}

static void DrawUi() {
    ImGuiIO& io = ImGui::GetIO();
    // ESP
    std::vector<EspEnt> esp; float sw, sh;
    { std::lock_guard<std::mutex> l(g_mx); esp = g_esp; sw = g_scrW; sh = g_scrH; }
    if (g_cfg.wh && g_cfg.whMode != 0) {
        auto* dl = ImGui::GetBackgroundDrawList(); float kx = io.DisplaySize.x / sw, ky = io.DisplaySize.y / sh;
        for (auto& e : esp) {
            ImVec2 a(e.x1 * kx, e.y1 * ky), b(e.x2 * kx, e.y2 * ky);
            dl->AddRect(ImVec2(a.x - 1, a.y - 1), ImVec2(b.x + 1, b.y + 1), IM_COL32(0, 0, 0, 255));
            dl->AddRect(a, b, IM_COL32(255, 60, 60, 255), 0, 0, 1.6f);
            if (e.hasHp) { char t[16]; snprintf(t, sizeof t, "%d", e.hp); dl->AddText(ImVec2(a.x, a.y - 14), IM_COL32(120, 255, 120, 255), t); }
            if (g_cfg.espLines) dl->AddLine(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y), ImVec2(e.sx * kx, e.sy * ky), IM_COL32(255, 220, 60, 160));
        }
    }
    // названия объектов рядом с ними
    if (g_cfg.sceneLabels) {
        std::vector<LabelEnt> labs; float lw, lh;
        { std::lock_guard<std::mutex> l(g_mx); labs = g_labels; lw = g_labW; lh = g_labH; }
        auto* dl = ImGui::GetBackgroundDrawList(); float kx = io.DisplaySize.x / lw, ky = io.DisplaySize.y / lh;
        for (auto& e : labs) {
            char t[200]; snprintf(t, sizeof t, "%s [%.0fм]", e.name.c_str(), e.dist);
            ImVec2 p(e.x * kx, e.y * ky);
            dl->AddText(ImVec2(p.x + 1, p.y + 1), IM_COL32(0, 0, 0, 255), t);
            dl->AddText(p, IM_COL32(120, 220, 255, 255), t);
        }
    }
    // надпись (жёлтая, снизу слева)
    if (g_cfg.watermark) {
        auto* dl = ImGui::GetForegroundDrawList(); ImFont* f = ImGui::GetFont(); float sz = 44.f; ImVec2 p(18, io.DisplaySize.y - 70);
        dl->AddText(f, sz, ImVec2(p.x + 2, p.y + 2), IM_COL32(0, 0, 0, 220), "GoldCheat");
        dl->AddText(f, sz, p, IM_COL32(255, 205, 20, 255), "GoldCheat");
    }
    if (g_picking) {
        auto* dl = ImGui::GetForegroundDrawList(); const char* t = "ВЫБОР ОБЪЕКТА:  ЛКМ - выбрать,  Esc - отмена";
        ImVec2 sz = ImGui::CalcTextSize(t); ImVec2 p((io.DisplaySize.x - sz.x) * 0.5f, 70.f);
        dl->AddRectFilled(ImVec2(p.x - 12, p.y - 8), ImVec2(p.x + sz.x + 12, p.y + sz.y + 8), IM_COL32(0, 0, 0, 190), 4.f);
        dl->AddText(p, IM_COL32(255, 220, 60, 255), t);
    }
    if (!g_menuOpen) return;
    ImGui::SetNextWindowSize(ImVec2(620, 520), ImGuiCond_FirstUseEver); ImGui::SetNextWindowPos(ImVec2(30, 40), ImGuiCond_FirstUseEver);
    bool open = true;
    if (ImGui::Begin("GoldCheat  [Home]", &open)) {
        if (ImGui::BeginTabBar("tabs")) {
            if (ImGui::BeginTabItem("Валюта")) { TabCurrency(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Игрок")) { TabPlayer(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Враги")) { TabEnemies(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("ESP")) { TabEsp(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Предметы")) { TabItems(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Сцена", nullptr, g_gotoScene.exchange(false) ? ImGuiTabItemFlags_SetSelected : 0)) { TabScene(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Ключ")) { TabKey(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Опции")) { TabOptions(); ImGui::EndTabItem(); }
            ImGui::EndTabBar();
        }
        ImGui::Separator();
        std::lock_guard<std::mutex> l(g_mx);
        ImGui::TextWrapped("%s", g_status.c_str());
    }
    ImGui::End();
    if (!open) g_menuOpen = false;
}

// ------------------------------------------------------------------ D3D11 Present hook
typedef HRESULT(__stdcall* tPresent)(IDXGISwapChain*, UINT, UINT);
static tPresent oPresent; static WNDPROC oWndProc; static HWND g_hwnd;
static ID3D11Device* g_dev; static ID3D11DeviceContext* g_ctx; static bool g_imInit = false;

static LRESULT CALLBACK hkWndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (g_unload) return CallWindowProcW(oWndProc, h, m, w, l);
    if (g_picking) { // режим выбора объекта мышкой: игра ввод не получает
        if (m == WM_LBUTTONDOWN) {
            RECT rc; GetClientRect(h, &rc);
            g_pickFx = (float)(short)LOWORD(l) / (float)std::max<LONG>(1, rc.right); g_pickFy = (float)(short)HIWORD(l) / (float)std::max<LONG>(1, rc.bottom);
            g_pickReq = true; return TRUE;
        }
        if (m == WM_KEYDOWN && (w == VK_ESCAPE || w == VK_HOME)) { g_picking = false; g_menuOpen = true; return TRUE; }
        bool mouse = (m >= WM_MOUSEFIRST && m <= WM_MOUSELAST) || m == WM_INPUT;
        bool key = m == WM_KEYDOWN || m == WM_CHAR || m == WM_SYSKEYDOWN;
        if (mouse || key) return TRUE;
        return CallWindowProcW(oWndProc, h, m, w, l);
    }
    if (m == WM_KEYDOWN && w == VK_HOME && !(l & (1 << 30))) g_menuOpen = !g_menuOpen;
    if (g_menuOpen) {
        ImGui_ImplWin32_WndProcHandler(h, m, w, l);
        ImGuiIO& io = ImGui::GetIO();
        // WM_SETCURSOR и отпускание клавиш НЕ глушим: игра сама рисует свой курсор и не "залипает" на клавишах
        bool mouse = (m >= WM_MOUSEFIRST && m <= WM_MOUSELAST) || m == WM_INPUT;
        bool key = m == WM_KEYDOWN || m == WM_CHAR || m == WM_SYSKEYDOWN;
        if (g_cfg.blockInput ? (mouse || key) : ((mouse && io.WantCaptureMouse) || (key && io.WantCaptureKeyboard))) return TRUE;
    }
    return CallWindowProcW(oWndProc, h, m, w, l);
}
static HRESULT __stdcall hkPresent(IDXGISwapChain* sc, UINT si, UINT fl) {
    if (!g_imInit && !g_unload) {
        if (SUCCEEDED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_dev))) {
            g_dev->GetImmediateContext(&g_ctx);
            DXGI_SWAP_CHAIN_DESC d; sc->GetDesc(&d); g_hwnd = d.OutputWindow;
            ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO(); io.IniFilename = nullptr; io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange; // не подменяем системный курсор
            const char* fonts[] = { "C:\\Windows\\Fonts\\segoeui.ttf", "C:\\Windows\\Fonts\\arial.ttf", "C:\\Windows\\Fonts\\tahoma.ttf" };
            for (auto f : fonts) if (GetFileAttributesA(f) != INVALID_FILE_ATTRIBUTES) { io.Fonts->AddFontFromFileTTF(f, 16.f, nullptr, io.Fonts->GetGlyphRangesCyrillic()); break; }
            Style();
            ImGui_ImplWin32_Init(g_hwnd); ImGui_ImplDX11_Init(g_dev, g_ctx);
            oWndProc = (WNDPROC)SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)hkWndProc);
            g_imInit = true; Log("overlay: D3D11 ready (hwnd=%p)", g_hwnd);
        }
    }
    if (g_unload && g_imInit) { // выгрузка: гасим оверлей в рендер-потоке
        if (oWndProc && GetWindowLongPtrW(g_hwnd, GWLP_WNDPROC) == (LONG_PTR)hkWndProc) SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)oWndProc);
        ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
        if (g_ctx) { g_ctx->Release(); g_ctx = nullptr; } if (g_dev) { g_dev->Release(); g_dev = nullptr; }
        g_imInit = false; g_overlayDown = true; Log("overlay: выключен");
    }
    if (g_unload && !g_imInit) { g_overlayDown = true; return oPresent(sc, si, fl); }
    if (g_imInit) {
        ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
        ImGui::GetIO().MouseDrawCursor = false; // курсор рисует сама игра (свой кастомный), ImGui его не дублирует
        DrawUi();
        ImGui::Render();
        ID3D11Texture2D* bb = nullptr; ID3D11RenderTargetView* rtv = nullptr;
        if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb))) {
            g_dev->CreateRenderTargetView(bb, nullptr, &rtv); bb->Release();
            g_ctx->OMSetRenderTargets(1, &rtv, nullptr);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
            rtv->Release();
        }
    }
    return oPresent(sc, si, fl);
}
static bool HookPresent() {
    WNDCLASSEXA wc = { sizeof wc, CS_CLASSDC, DefWindowProcA, 0, 0, GetModuleHandleA(nullptr), 0, 0, 0, 0, "GoldModDummy", 0 };
    RegisterClassExA(&wc);
    HWND w = CreateWindowA("GoldModDummy", "d", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, 0, 0, wc.hInstance, 0);
    DXGI_SWAP_CHAIN_DESC sd = {}; sd.BufferCount = 1; sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = w; sd.SampleDesc.Count = 1; sd.Windowed = TRUE; sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    IDXGISwapChain* sc = nullptr; ID3D11Device* dev = nullptr; ID3D11DeviceContext* ctx = nullptr; D3D_FEATURE_LEVEL fl;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &sd, &sc, &dev, &fl, &ctx);
    if (FAILED(hr)) { Log("D3D11 dummy failed: 0x%08lx", hr); DestroyWindow(w); UnregisterClassA("GoldModDummy", wc.hInstance); return false; }
    void* present = (*(void***)sc)[8];
    bool ok = MH_CreateHook(present, (void*)hkPresent, (void**)&oPresent) == MH_OK && MH_EnableHook(present) == MH_OK;
    Log("D3D11 Present hook @ %p: %s", present, ok ? "ok" : "FAIL");
    sc->Release(); dev->Release(); ctx->Release(); DestroyWindow(w); UnregisterClassA("GoldModDummy", wc.hInstance);
    return ok;
}

// ------------------------------------------------------------------ инициализация
static DWORD WINAPI InitThread(LPVOID) {
    Log("GoldCheat start");
    while (!GetModuleHandleA("GameAssembly.dll")) Sleep(300);
    bool exportsOk = il2::Init();
    if (!exportsOk) { Say("il2cpp exports not available - abort"); return 0; }
    for (int i = 0; i < 240; i++) { // ждём домен и Assembly-CSharp (до ~2 минут)
        if (il2::il2cpp_domain_get() && il2::il2cpp_domain_get()) {
            il2::Attach();
            if (il2::FindClassIn("Assembly-CSharp.dll", "", "PlayerController")) break;
        }
        Sleep(500);
    }
    il2::Attach();
    if (!G::Bind()) { Say("Привязка к игре не выполнена (см. GoldCheat.log). Игра обновилась? Пришли GoldCheat.log и новый dump.cs"); }
    MH_Initialize();
    HookPresent();
    HookMethod(il2::Method(il2::FindClass("FMODUnity", "RuntimeManager"), "Update", 0), (void*)hkUpd, (void**)&oUpd, "RuntimeManager.Update");
    g_hitHooked = HookMethod(il2::Method(G::kPlayer, "HitEnemy", 3), (void*)hkHit, (void**)&oHit, "PlayerController.HitEnemy");
    { // для диагностики: другие методы PlayerController с той же формой (float, int, EnemyController)
        void* it = nullptr; while (auto m = il2::il2cpp_class_get_methods(G::kPlayer, &it)) {
            if (il2::il2cpp_method_get_param_count(m) != 3 || il2::IsStatic(m)) continue;
            if (il2::TypeName(il2::il2cpp_method_get_param(m, 0)) != "System.Single" || il2::TypeName(il2::il2cpp_method_get_param(m, 1)) != "System.Int32") continue;
            if (il2::TypeName(il2::il2cpp_method_get_param(m, 2)) != "EnemyController") continue;
            Log("метод удара: %s @ %p", il2::il2cpp_method_get_name(m), *(void**)m);
        }
    }
    if (G::mGetTimeScale && G::mSetTimeScale) { // скорость времени: подменяем timeScale так, чтобы игра этого не видела
        G::g_tsGame = il2::Unbox<float>(il2::Call(G::mGetTimeScale, nullptr), 1.f);
        bool gOk = HookMethod(G::mGetTimeScale, (void*)hkGetTS, (void**)&G::oGetTS, "Time.get_timeScale");
        bool sOk = gOk && HookMethod(G::mSetTimeScale, (void*)hkSetTS, (void**)&G::oSetTS, "Time.set_timeScale");
        if (gOk && !sOk) { void* t = *(void**)G::mGetTimeScale; MH_DisableHook(t); MH_RemoveHook(t); G::oGetTS = nullptr; }
        G::g_tsHooked = gOk && sOk;
    }
    G::g_moveHooked = HookMethod(G::mMove, (void*)hkMove, (void**)&oMove, "CharacterController.Move");
    HookMethod(il2::Method(il2::FindClassIn("Assembly-CSharp.dll", "", "TriggerLose"), "OnTriggerEnter", 1), (void*)hkTrig, (void**)&oTrig, "TriggerLose.OnTriggerEnter");
    g_ready = true; Say("GoldCheat загружен. Home - меню");
    return 0;
}

BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h; DisableThreadLibraryCalls(h); InitializeCriticalSection(&g_logCs);
        GetModuleFileNameA(h, g_logPath, MAX_PATH); char* s = strrchr(g_logPath, '\\'); if (s) *(s + 1) = 0; strcat(g_logPath, "GoldCheat.log");
        CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
    }
    return TRUE;
}
